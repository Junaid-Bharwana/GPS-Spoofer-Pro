# Add project specific ProGuard rules here.
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# Preserve line numbers for debugging stack traces
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Keep WebView JavaScript interfaces
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Xposed framework
-keep class com.gpsspoofer.pro.xposed.XposedHook{*;}
-keep class com.gpsspoofer.pro.xposed.Xshare{ *;}
-keepnames class com.gpsspoofer.pro.selfhook.XposedSelfHooks{*;}
-keep class de.robv.android.xposed.**{*;}
-keepnames class de.robv.android.xposed.**

# Retrofit + Gson
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.gpsspoofer.pro.network.** { *; }
-dontwarn retrofit2.**
-keep class retrofit2.** { *; }
-dontwarn okhttp3.**
-keep class okhttp3.** { *; }
-dontwarn okio.**

# Keep Hilt generated code
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }
-keep class * extends dagger.hilt.android.internal.managers.ViewComponentManager$FragmentContextWrapper { *; }

-repackageclasses
-allowaccessmodification
-overloadaggressively
