package com.gpsspoofer.pro.features

import android.os.Handler
import android.os.Looper
import kotlin.math.*

/**
 * Teleport Animation - Gradually moves from current location to target
 * instead of instant teleportation, making movement appear more natural.
 */
class TeleportAnimator(private val onLocationUpdate: (Double, Double) -> Unit) {

    private val handler = Handler(Looper.getMainLooper())
    private var isAnimating = false
    private var startLat = 0.0
    private var startLon = 0.0
    private var targetLat = 0.0
    private var targetLon = 0.0
    private var currentStep = 0
    private var totalSteps = 0
    private var onComplete: (() -> Unit)? = null

    companion object {
        private const val STEP_INTERVAL_MS = 100L // 100ms between steps
        private const val MIN_STEPS = 10
        private const val MAX_STEPS = 100
        private const val EARTH_RADIUS_KM = 6371.0
    }

    /**
     * Animate movement from current position to target position.
     * Duration adapts to distance - longer distances take more steps.
     */
    fun animateTo(fromLat: Double, fromLon: Double, toLat: Double, toLon: Double, onDone: (() -> Unit)? = null) {
        if (isAnimating) cancel()

        startLat = fromLat
        startLon = fromLon
        targetLat = toLat
        targetLon = toLon
        onComplete = onDone

        val distance = haversineDistance(fromLat, fromLon, toLat, toLon)
        // Scale steps based on distance: ~1 step per 10m for short, ~1 step per 100m for long
        totalSteps = when {
            distance < 0.1 -> MIN_STEPS           // < 100m
            distance < 1.0 -> 20                   // < 1km
            distance < 10.0 -> 50                  // < 10km
            else -> MAX_STEPS                       // > 10km
        }
        currentStep = 0
        isAnimating = true

        handler.post(stepRunnable)
    }

    private val stepRunnable = object : Runnable {
        override fun run() {
            if (!isAnimating) return

            currentStep++
            val progress = currentStep.toDouble() / totalSteps

            // Use ease-in-out interpolation for natural movement
            val t = easeInOutCubic(progress)

            val lat = startLat + (targetLat - startLat) * t
            val lon = startLon + (targetLon - startLon) * t

            onLocationUpdate(lat, lon)

            if (currentStep < totalSteps) {
                handler.postDelayed(this, STEP_INTERVAL_MS)
            } else {
                isAnimating = false
                onComplete?.invoke()
            }
        }
    }

    fun cancel() {
        isAnimating = false
        handler.removeCallbacks(stepRunnable)
    }

    fun isRunning() = isAnimating

    /**
     * Ease-in-out cubic interpolation for smooth start and end.
     */
    private fun easeInOutCubic(t: Double): Double {
        return if (t < 0.5) {
            4 * t * t * t
        } else {
            1 - (-2 * t + 2).pow(3) / 2
        }
    }

    /**
     * Calculate distance between two points in km using Haversine formula.
     */
    private fun haversineDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return EARTH_RADIUS_KM * c
    }

    fun destroy() {
        cancel()
        handler.removeCallbacksAndMessages(null)
    }
}
