package com.gpsspoofer.pro.module.util

import javax.inject.Qualifier


@Retention(AnnotationRetention.RUNTIME)
@Qualifier
annotation class ApplicationScope
