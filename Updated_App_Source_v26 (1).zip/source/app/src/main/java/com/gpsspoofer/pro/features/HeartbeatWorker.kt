package com.gpsspoofer.pro.features

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.gpsspoofer.pro.network.ApiService
import com.gpsspoofer.pro.utils.PrefManager
import java.util.concurrent.TimeUnit

/**
 * WorkManager-based heartbeat that replaces polling-based heartbeat.
 * Battery-efficient periodic check that runs even when app is backgrounded.
 */
class HeartbeatWorker(
    context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    companion object {
        private const val WORK_NAME = "heartbeat_work"
        private const val INTERVAL_MINUTES = 15L // WorkManager minimum is 15 min

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<HeartbeatWorker>(
                INTERVAL_MINUTES, TimeUnit.MINUTES
            ).build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }

    override suspend fun doWork(): Result {
        val userId = PrefManager.getUserId()
        if (userId == -1) return Result.success()

        return try {
            val deviceToken = PrefManager.getOrCreateDeviceToken()
            val response = ApiService.post("heartbeat.php", mapOf(
                "user_id" to userId.toString(),
                "device_token" to deviceToken
            ))

            if (response != null) {
                val status = response.optString("status", "")
                if (status == "inactive" || status == "expired") {
                    // Account issue - will be handled when app opens
                    PrefManager.logout()
                }
                PrefManager.saveLastHeartbeat(System.currentTimeMillis())
            }

            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
