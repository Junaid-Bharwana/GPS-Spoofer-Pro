package com.gpsspoofer.pro.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.gpsspoofer.pro.R
import com.gpsspoofer.pro.network.ApiService
import com.gpsspoofer.pro.utils.AccountStatusChecker
import com.gpsspoofer.pro.utils.PrefManager
import com.gpsspoofer.pro.update.AppUpdateManager
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

class SubscriptionActivity : AppCompatActivity() {

    private lateinit var loadingProgress: ProgressBar
    private lateinit var contentScroll: ScrollView
    private lateinit var errorText: TextView
    private lateinit var usernameText: TextView
    private lateinit var statusText: TextView
    private lateinit var expirationText: TextView
    private lateinit var remainingDaysText: TextView
    private lateinit var contactSupportBtn: Button
    private lateinit var retryBtn: Button
    private var heartbeatJob: Job? = null
    private var contactSupportUrl: String = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_subscription)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        loadingProgress = findViewById(R.id.loading_progress)
        contentScroll = findViewById(R.id.content_scroll)
        errorText = findViewById(R.id.error_text)
        usernameText = findViewById(R.id.username_text)
        statusText = findViewById(R.id.status_text)
        expirationText = findViewById(R.id.expiration_text)
        remainingDaysText = findViewById(R.id.remaining_days_text)
        contactSupportBtn = findViewById(R.id.contact_support_btn)
        retryBtn = findViewById(R.id.retry_btn)

        contactSupportBtn.setOnClickListener {
            if (contactSupportUrl.isNotEmpty()) {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(contactSupportUrl))
                    startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(this, "Unable to open support link", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Support link not available. Please try again.", Toast.LENGTH_SHORT).show()
            }
        }

        retryBtn.setOnClickListener {
            loadSubscriptionDetails()
        }

        loadSubscriptionDetails()
    }

    private fun loadSubscriptionDetails() {
        val userId = PrefManager.getUserId()
        if (userId == -1) {
            showCachedDataOrError("User not logged in. Please log in again.")
            return
        }

        loadingProgress.visibility = View.VISIBLE
        contentScroll.visibility = View.GONE
        errorText.visibility = View.GONE
        retryBtn.visibility = View.GONE

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val jsonResponse = ApiService.post("subscription_status.php", mapOf(
                    "user_id" to userId.toString()
                ))

                withContext(Dispatchers.Main) {
                    if (jsonResponse == null) {
                        showCachedDataOrError("Connection error. Please try again.")
                        return@withContext
                    }

                    if (jsonResponse.optString("status") == "success") {
                        val username = jsonResponse.optString("username", "Unknown")
                        val subscriptionStatus = jsonResponse.optString("subscription_status", "inactive")
                        val expirationDate = jsonResponse.optString("expiration_date", "N/A")
                        val remainingDays = jsonResponse.optInt("remaining_days", 0)
                        contactSupportUrl = jsonResponse.optString("contact_support_url", "")

                        displaySubscriptionData(username, subscriptionStatus, expirationDate, remainingDays)
                    } else {
                        val message = jsonResponse.optString("message", "Unknown error from server")
                        showCachedDataOrError("Server error: $message")
                    }
                }
            } catch (e: java.net.SocketTimeoutException) {
                withContext(Dispatchers.Main) {
                    showCachedDataOrError("Connection timed out. Please check your internet connection.")
                }
            } catch (e: java.net.UnknownHostException) {
                withContext(Dispatchers.Main) {
                    showCachedDataOrError("No internet connection. Please check your network.")
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    showCachedDataOrError("Connection error: ${e.message ?: "Unknown error"}")
                }
            }
        }
    }

    private fun displaySubscriptionData(username: String, status: String, expirationDate: String, remainingDays: Int) {
        usernameText.text = username
        statusText.text = status.replaceFirstChar { it.uppercase() }
        expirationText.text = expirationDate
        remainingDaysText.text = if (status == "active") "$remainingDays days" else "N/A"

        val statusColor = when (status) {
            "active" -> getColor(R.color.success)
            "expired" -> getColor(R.color.error)
            else -> getColor(R.color.warning)
        }
        statusText.setTextColor(statusColor)

        loadingProgress.visibility = View.GONE
        contentScroll.visibility = View.VISIBLE
        errorText.visibility = View.GONE
        retryBtn.visibility = View.GONE
    }

    private fun showCachedDataOrError(errorMessage: String) {
        val cachedUsername = PrefManager.getUsername()
        val cachedExpiration = PrefManager.getExpirationDate()

        if (cachedUsername.isNotEmpty() && cachedExpiration.isNotEmpty()) {
            val isActive = PrefManager.isUserLoggedIn()
            val status = if (isActive) "active" else "unknown"
            val remainingDays = try {
                val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
                val expDate = sdf.parse(cachedExpiration)
                val currentDate = java.util.Calendar.getInstance().time
                if (expDate != null && expDate.after(currentDate)) {
                    ((expDate.time - currentDate.time) / (1000 * 60 * 60 * 24)).toInt()
                } else {
                    0
                }
            } catch (e: Exception) {
                0
            }

            displaySubscriptionData(cachedUsername, status, cachedExpiration, remainingDays)
            Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
        } else {
            loadingProgress.visibility = View.GONE
            contentScroll.visibility = View.GONE
            errorText.visibility = View.VISIBLE
            errorText.text = errorMessage
            retryBtn.visibility = View.VISIBLE
        }
    }

    override fun onResume() {
        super.onResume()
        startHeartbeatCheck()
        AppUpdateManager.checkForUpdate(this)
    }

    override fun onPause() {
        super.onPause()
        heartbeatJob?.cancel()
        AppUpdateManager.dismissDialog()
    }

    private fun startHeartbeatCheck() {
        heartbeatJob?.cancel()
        heartbeatJob = lifecycleScope.launch(Dispatchers.IO) {
            while (isActive) {
                val userId = PrefManager.getUserId()
                if (userId != -1) {
                    val status = AccountStatusChecker.checkAccountStatus(userId)
                    if (status is AccountStatusChecker.AccountStatus.Inactive) {
                        withContext(Dispatchers.Main) {
                            AccountStatusChecker.forceLogout(this@SubscriptionActivity, status.message)
                        }
                        return@launch
                    }
                    if (status is AccountStatusChecker.AccountStatus.Maintenance) {
                        withContext(Dispatchers.Main) {
                            AccountStatusChecker.showMaintenance(this@SubscriptionActivity, status.title, status.message)
                        }
                        return@launch
                    }
                }
                delay(10_000L)
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
