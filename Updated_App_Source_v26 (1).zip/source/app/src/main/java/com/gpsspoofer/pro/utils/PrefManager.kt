package com.gpsspoofer.pro.utils

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import com.gpsspoofer.pro.BuildConfig
import com.gpsspoofer.pro.gsApp
import com.gpsspoofer.pro.selfhook.XposedSelfHooks
import dagger.Reusable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import rikka.material.app.DayNightDelegate
import java.io.File


@SuppressLint("WorldReadableFiles")

object PrefManager   {

    private const val START = "start"
    private const val LATITUDE = "latitude"
    private const val LONGITUDE = "longitude"
    private const val HOOKED_SYSTEM = "isHookedSystem"
    private const val RANDOM_POSITION = "random_position"
    private const val ACCURACY_SETTING = "accuracy_settings"
    private const val MAP_TYPE = "map_type"
    private const val DARK_THEME = "dark_theme"
    private const val DISABLE_UPDATE = "disable_update"
    private const val KEY_USER_ID = "user_id"
    private const val KEY_USERNAME = "username"
    private const val KEY_EXPIRATION_DATE = "expiration_date"
    private const val KEY_LOGGED_IN = "logged_in"
    private const val KEY_LAST_HEARTBEAT = "last_heartbeat"
    private const val KEY_DEVICE_TOKEN = "device_token"
    private const val KEY_SPOOFING_MODE = "spoofing_mode"
    private const val KEY_TELEPORT_ANIMATION = "teleport_animation"
    private const val KEY_ENHANCED_NOTIFICATIONS = "enhanced_notifications"
    private const val KEY_SAVE_LOGIN = "save_login"
    private const val KEY_ENABLE_FINGERPRINT = "enable_fingerprint"

    // Spoofing modes
    const val MODE_LSPOSED = 0
    const val MODE_MOCK_LOCATION = 1


    private val pref: SharedPreferences by lazy {
         try {
             val prefsFile = "${BuildConfig.APPLICATION_ID}_prefs"
             gsApp.getSharedPreferences(
                 prefsFile,
                 Context.MODE_WORLD_READABLE
             )
         }catch (e:SecurityException){
             val prefsFile = "${BuildConfig.APPLICATION_ID}_prefs"
             gsApp.getSharedPreferences(
                 prefsFile,
                 Context.MODE_PRIVATE
             )
         }

    }


    val isStarted : Boolean
    get() = pref.getBoolean(START, false)

    val getLat : Double
    get() = pref.getFloat(LATITUDE, 40.7128F).toDouble()

    val getLng : Double
    get() = pref.getFloat(LONGITUDE, -74.0060F).toDouble()

    var isHookSystem : Boolean
    get() = pref.getBoolean(HOOKED_SYSTEM, false)
    set(value) { pref.edit().putBoolean(HOOKED_SYSTEM,value).apply() }

    var isRandomPosition :Boolean
    get() = pref.getBoolean(RANDOM_POSITION, false)
    set(value) { pref.edit().putBoolean(RANDOM_POSITION, value).apply() }

    var accuracy : String?
    get() = pref.getString(ACCURACY_SETTING,"10")
    set(value) { pref.edit().putString(ACCURACY_SETTING,value).apply()}

    var mapType : Int
    get() = pref.getInt(MAP_TYPE,1)
    set(value) { pref.edit().putInt(MAP_TYPE,value).apply()}

    var darkTheme: Int
        get() = pref.getInt(DARK_THEME, DayNightDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        set(value) = pref.edit().putInt(DARK_THEME, value).apply()

    var disableUpdate: Boolean
        get() = pref.getBoolean(DISABLE_UPDATE, false)
        set(value) = pref.edit().putBoolean(DISABLE_UPDATE, value).apply()

    fun saveLoginData(userId: Int, username: String, expirationDate: String) {
        pref.edit().apply {
            putInt(KEY_USER_ID, userId)
            putString(KEY_USERNAME, username)
            putString(KEY_EXPIRATION_DATE, expirationDate)
            putBoolean(KEY_LOGGED_IN, true)
            apply()
        }
    }

    fun saveDeviceToken(token: String) {
        pref.edit().putString(KEY_DEVICE_TOKEN, token).apply()
    }

    fun getDeviceToken(): String = pref.getString(KEY_DEVICE_TOKEN, "") ?: ""

    fun isUserLoggedIn(): Boolean {
        val isLoggedIn = pref.getBoolean(KEY_LOGGED_IN, false)
        if (!isLoggedIn) return false

        // Check if subscription has expired
        val expirationDate = pref.getString(KEY_EXPIRATION_DATE, null) ?: return false
        return try {
            val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
            val expDate = sdf.parse(expirationDate)
            val currentDate = java.util.Calendar.getInstance().time
            expDate?.after(currentDate) ?: false
        } catch (e: Exception) {
            false
        }
    }

    fun getUserId(): Int = pref.getInt(KEY_USER_ID, -1)

    fun getUsername(): String = pref.getString(KEY_USERNAME, "") ?: ""

    fun getExpirationDate(): String = pref.getString(KEY_EXPIRATION_DATE, "") ?: ""

    /**
     * Returns a persistent device identifier based on hardware properties.
     * Uses ANDROID_ID + device model + manufacturer to create a stable fingerprint
     * that survives app reinstalls and device restarts.
     * Falls back to a stored UUID only if hardware ID generation fails.
     */
    fun getOrCreateDeviceToken(): String {
        // Always try to generate hardware-based ID first
        val hardwareId = generateHardwareDeviceId()
        if (hardwareId.isNotEmpty()) {
            // Store it so heartbeat/logout can use it
            pref.edit().putString(KEY_DEVICE_TOKEN, hardwareId).apply()
            return hardwareId
        }
        // Fallback: use stored token or generate UUID
        var token = pref.getString(KEY_DEVICE_TOKEN, "") ?: ""
        if (token.isEmpty()) {
            token = java.util.UUID.randomUUID().toString()
            pref.edit().putString(KEY_DEVICE_TOKEN, token).apply()
        }
        return token
    }

    /**
     * Generates a stable device ID from hardware properties that persists across
     * reinstalls and reboots. Uses ANDROID_ID + Build info hashed with SHA-256.
     */
    @SuppressLint("HardwareIds")
    private fun generateHardwareDeviceId(): String {
        return try {
            val androidId = android.provider.Settings.Secure.getString(
                gsApp.contentResolver,
                android.provider.Settings.Secure.ANDROID_ID
            ) ?: ""
            val deviceInfo = "${androidId}|${android.os.Build.MODEL}|${android.os.Build.MANUFACTURER}|${android.os.Build.BRAND}|${android.os.Build.DEVICE}|${android.os.Build.PRODUCT}"
            val digest = java.security.MessageDigest.getInstance("SHA-256")
            val hash = digest.digest(deviceInfo.toByteArray(Charsets.UTF_8))
            hash.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            ""
        }
    }

    fun logout() {
        // Keep KEY_DEVICE_TOKEN so the same device can re-login
        pref.edit().apply {
            putBoolean(KEY_LOGGED_IN, false)
            putInt(KEY_USER_ID, -1)
            putString(KEY_USERNAME, "")
            putString(KEY_EXPIRATION_DATE, "")
            putLong(KEY_LAST_HEARTBEAT, 0L)
            apply()
        }
    }

    fun saveLastHeartbeat(timestamp: Long) {
        pref.edit().putLong(KEY_LAST_HEARTBEAT, timestamp).apply()
    }

    fun getLastHeartbeat(): Long = pref.getLong(KEY_LAST_HEARTBEAT, 0L)



    var spoofingMode: Int
        get() = pref.getInt(KEY_SPOOFING_MODE, MODE_LSPOSED)
        set(value) = pref.edit().putInt(KEY_SPOOFING_MODE, value).apply()

    var teleportAnimation: Boolean
        get() = pref.getBoolean(KEY_TELEPORT_ANIMATION, false)
        set(value) = pref.edit().putBoolean(KEY_TELEPORT_ANIMATION, value).apply()

    var enhancedNotifications: Boolean
        get() = pref.getBoolean(KEY_ENHANCED_NOTIFICATIONS, true)
        set(value) = pref.edit().putBoolean(KEY_ENHANCED_NOTIFICATIONS, value).apply()

    var saveLogin: Boolean
        get() = pref.getBoolean(KEY_SAVE_LOGIN, true)
        set(value) = pref.edit().putBoolean(KEY_SAVE_LOGIN, value).apply()

    var enableFingerprint: Boolean
        get() = pref.getBoolean(KEY_ENABLE_FINGERPRINT, false)
        set(value) = pref.edit().putBoolean(KEY_ENABLE_FINGERPRINT, value).apply()

    fun update(start:Boolean, la: Double, ln: Double) {
        runInBackground {
            val prefEditor = pref.edit()
            prefEditor.putFloat(LATITUDE, la.toFloat())
            prefEditor.putFloat(LONGITUDE, ln.toFloat())
            prefEditor.putBoolean(START, start)
            prefEditor.apply()
            makeWorldReadable()
        }

    }


    /**
     *  Make the redirected prefs file world readable ourselves - fixes a bug in Ed/lsposed
     *
     *  This requires the XSharedPreferences file path, which we get via a self hook. It does nothing
     *  when the Xposed module is not enabled.
     */
    @SuppressLint("SetWorldReadable")
    private fun makeWorldReadable(){
        XposedSelfHooks.getXSharedPrefsPath().let {
            if(it.isNotEmpty()){
                File(it).setReadable(true, false)
            }
        }
    }

    private fun runInBackground(method: suspend () -> Unit){
        gsApp.globalScope.launch(Dispatchers.IO) {
            method.invoke()
        }
    }





}
