package com.gpsspoofer.pro.features

import android.content.Context
import android.content.SharedPreferences

/**
 * Manages session expiry - auto-logout after a period of inactivity.
 * Admin-controlled timeout period.
 */
class SessionExpiryManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("session_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_LAST_ACTIVITY = "last_activity_timestamp"
        private const val KEY_SESSION_TIMEOUT = "session_timeout_ms"
        const val DEFAULT_TIMEOUT_MS = 30 * 60 * 1000L // 30 minutes default
    }

    var sessionTimeoutMs: Long
        get() = prefs.getLong(KEY_SESSION_TIMEOUT, DEFAULT_TIMEOUT_MS)
        set(value) = prefs.edit().putLong(KEY_SESSION_TIMEOUT, value).apply()

    /**
     * Update the last activity timestamp. Call this on user interactions.
     */
    fun updateLastActivity() {
        prefs.edit().putLong(KEY_LAST_ACTIVITY, System.currentTimeMillis()).apply()
    }

    /**
     * Check if the session has expired due to inactivity.
     */
    fun isSessionExpired(): Boolean {
        val lastActivity = prefs.getLong(KEY_LAST_ACTIVITY, 0L)
        if (lastActivity == 0L) return false // Never set = fresh session
        val elapsed = System.currentTimeMillis() - lastActivity
        return elapsed > sessionTimeoutMs
    }

    /**
     * Get remaining time in milliseconds before session expires.
     */
    fun getRemainingTime(): Long {
        val lastActivity = prefs.getLong(KEY_LAST_ACTIVITY, System.currentTimeMillis())
        val elapsed = System.currentTimeMillis() - lastActivity
        return (sessionTimeoutMs - elapsed).coerceAtLeast(0L)
    }

    fun reset() {
        prefs.edit().remove(KEY_LAST_ACTIVITY).apply()
    }
}
