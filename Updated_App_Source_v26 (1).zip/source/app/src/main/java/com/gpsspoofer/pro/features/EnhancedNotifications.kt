package com.gpsspoofer.pro.features

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.gpsspoofer.pro.R
import com.gpsspoofer.pro.ui.MapActivity

/**
 * Enhanced notifications with rich location information.
 * Shows ongoing notification with spoofed coordinates, address, and quick actions.
 */
class EnhancedNotifications(private val context: Context) {

    companion object {
        private const val CHANNEL_ID = "gps_spoofer_spoofing"
        private const val CHANNEL_NAME = "Location Spoofing"
        private const val NOTIFICATION_ID = 1001
        private const val TIMER_CHANNEL_ID = "gps_spoofer_timer"
        private const val TIMER_NOTIFICATION_ID = 1002
    }

    init {
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val spoofingChannel = NotificationChannel(
                CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows when location spoofing is active"
                setShowBadge(false)
            }
            manager.createNotificationChannel(spoofingChannel)

            val timerChannel = NotificationChannel(
                TIMER_CHANNEL_ID, "Spoofing Timer", NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows scheduled spoofing timer countdown"
                setShowBadge(false)
            }
            manager.createNotificationChannel(timerChannel)
        }
    }

    /**
     * Show a rich notification with location details.
     */
    fun showSpoofingNotification(lat: Double, lon: Double, address: String, mode: String) {
        val intent = Intent(context, MapActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val coordText = String.format("%.6f, %.6f", lat, lon)
        val contentText = if (address.isNotEmpty() && address != "$lat, $lon") {
            "$address\n$coordText"
        } else {
            coordText
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_play)
            .setContentTitle("Spoofing Active ($mode)")
            .setContentText(contentText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(
                "$contentText\nMode: $mode"
            ))
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification)
    }

    /**
     * Show timer notification with countdown.
     */
    fun showTimerNotification(remainingTime: String) {
        val notification = NotificationCompat.Builder(context, TIMER_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stop)
            .setContentTitle("Spoofing Timer")
            .setContentText("Auto-stop in $remainingTime")
            .setOngoing(true)
            .setAutoCancel(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(TIMER_NOTIFICATION_ID, notification)
    }

    /**
     * Cancel all spoofing notifications.
     */
    fun cancelAll() {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.cancel(NOTIFICATION_ID)
        manager.cancel(TIMER_NOTIFICATION_ID)
    }

    fun cancelTimer() {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.cancel(TIMER_NOTIFICATION_ID)
    }
}
