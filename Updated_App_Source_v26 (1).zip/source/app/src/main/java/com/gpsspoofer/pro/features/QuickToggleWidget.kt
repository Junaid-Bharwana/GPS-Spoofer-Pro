package com.gpsspoofer.pro.features

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.gpsspoofer.pro.R
import com.gpsspoofer.pro.utils.PrefManager
import com.gpsspoofer.pro.service.MockLocationService

/**
 * Home screen widget for quick start/stop of GPS spoofing.
 * One tap to toggle spoofing on/off using the last saved location.
 */
class QuickToggleWidget : AppWidgetProvider() {

    companion object {
        const val ACTION_TOGGLE = "com.gpsspoofer.pro.TOGGLE_SPOOFING"

        fun updateAllWidgets(context: Context) {
            val intent = Intent(context, QuickToggleWidget::class.java).apply {
                action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
            }
            val ids = AppWidgetManager.getInstance(context)
                .getAppWidgetIds(ComponentName(context, QuickToggleWidget::class.java))
            intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            context.sendBroadcast(intent)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)

        if (intent.action == ACTION_TOGGLE) {
            val isStarted = PrefManager.isStarted

            if (isStarted) {
                // Stop spoofing
                if (PrefManager.spoofingMode == PrefManager.MODE_MOCK_LOCATION) {
                    MockLocationService.stop(context)
                }
                PrefManager.update(false, PrefManager.getLat, PrefManager.getLng)
            } else {
                // Start spoofing at last saved location
                if (!PrefManager.isUserLoggedIn()) return // Don't start if not logged in

                val lat = PrefManager.getLat
                val lon = PrefManager.getLng
                if (PrefManager.spoofingMode == PrefManager.MODE_MOCK_LOCATION) {
                    val accuracy = (PrefManager.accuracy ?: "10").toFloat()
                    MockLocationService.start(context, lat, lon, accuracy)
                }
                PrefManager.update(true, lat, lon)
            }

            // Update all widgets to reflect new state
            updateAllWidgets(context)
        }
    }

    private fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
        val isStarted = PrefManager.isStarted
        val views = RemoteViews(context.packageName, R.layout.widget_quick_toggle)

        // Set text based on state
        views.setTextViewText(
            R.id.widget_status_text,
            if (isStarted) "Spoofing ON" else "Spoofing OFF"
        )

        views.setTextViewText(
            R.id.widget_location_text,
            if (isStarted) "${String.format("%.4f", PrefManager.getLat)}, ${String.format("%.4f", PrefManager.getLng)}" else "Tap to start"
        )

        // Set click action
        val toggleIntent = Intent(context, QuickToggleWidget::class.java).apply {
            action = ACTION_TOGGLE
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, 0, toggleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)

        appWidgetManager.updateAppWidget(appWidgetId, views)
    }
}
