package com.gpsspoofer.pro.update

import android.app.Activity
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.appcompat.app.AppCompatActivity
import com.gpsspoofer.pro.BuildConfig
import com.gpsspoofer.pro.R
import com.gpsspoofer.pro.network.ApiService
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

/**
 * Global update manager that can check for updates and show dialogs
 * from ANY activity. Call checkForUpdate() in onResume() of any activity.
 */
object AppUpdateManager {

    private var currentDialog: AlertDialog? = null
    private var downloadRequestId: Long? = null
    private var downloadFile: File? = null
    private var isChecking = false

    /**
     * Check for updates and show dialog if available.
     * Call this from onResume() of any activity that should show update prompts.
     */
    fun checkForUpdate(activity: AppCompatActivity) {
        if (isChecking) return
        isChecking = true

        activity.lifecycleScope.launch(Dispatchers.IO) {
            try {
                val response = ApiService.get(
                    "update_check.php?version_code=${BuildConfig.VERSION_CODE}&platform=android"
                )
                if (response != null && response.optBoolean("update_available", false)) {
                    val versionName = response.optString("version_name", "")
                    val changelog = response.optString("changelog", "")
                    val downloadUrl = response.optString("download_url", "")
                    val forceUpdate = response.optBoolean("force_update", false)

                    withContext(Dispatchers.Main) {
                        if (!activity.isFinishing && !activity.isDestroyed) {
                            if (forceUpdate) {
                                showForceUpdateDialog(activity, versionName, changelog, downloadUrl)
                            } else {
                                showUpdateDialog(activity, versionName, changelog, downloadUrl)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                // Silently fail - update check is non-critical
            } finally {
                isChecking = false
            }
        }
    }

    /**
     * Optional update dialog - user can dismiss
     */
    private fun showUpdateDialog(activity: AppCompatActivity, versionName: String, changelog: String, downloadUrl: String) {
        // Dismiss any existing dialog
        currentDialog?.dismiss()

        val builder = MaterialAlertDialogBuilder(activity)
        builder.setTitle("Update Available - v$versionName")
        builder.setMessage(changelog.ifEmpty { "A new version is available. Please update for the best experience." })
        builder.setCancelable(true)
        builder.setPositiveButton("Update") { _, _ ->
            startDownload(activity, downloadUrl, "GPS_Spoofer_PRO_v${versionName}.apk")
        }
        builder.setNegativeButton("Later", null)

        currentDialog = builder.create()
        currentDialog?.show()
    }

    /**
     * Force update dialog - user CANNOT dismiss, must update to continue
     */
    private fun showForceUpdateDialog(activity: AppCompatActivity, versionName: String, changelog: String, downloadUrl: String) {
        // Dismiss any existing dialog
        currentDialog?.dismiss()

        val builder = MaterialAlertDialogBuilder(activity)
        builder.setTitle("Required Update - v$versionName")
        builder.setMessage(
            (changelog.ifEmpty { "A critical update is available." }) +
            "\n\nYou must update to continue using the app."
        )
        builder.setCancelable(false)
        builder.setPositiveButton("Update Now") { _, _ ->
            startDownload(activity, downloadUrl, "GPS_Spoofer_PRO_v${versionName}.apk")
        }
        // No negative button - force update is mandatory

        currentDialog = builder.create()
        currentDialog?.show()
    }

    /**
     * Download and install the APK update
     */
    private fun startDownload(activity: AppCompatActivity, url: String, fileName: String) {
        try {
            val downloadFolder = File(activity.externalCacheDir, "updates").apply { mkdirs() }
            downloadFile = File(downloadFolder, fileName)

            // Delete old file if exists
            if (downloadFile!!.exists()) downloadFile!!.delete()

            val downloadManager = activity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

            // Show download progress dialog
            val view = activity.layoutInflater.inflate(R.layout.update_dialog, null)
            val progress = view.findViewById<LinearProgressIndicator>(R.id.update_download_progress)
            val cancel = view.findViewById<AppCompatButton>(R.id.update_download_cancel)

            val progressDialog = MaterialAlertDialogBuilder(activity)
                .setView(view)
                .setCancelable(false)
                .create()

            cancel.setOnClickListener {
                downloadRequestId?.let { downloadManager.remove(it) }
                progressDialog.dismiss()
            }

            progressDialog.show()

            // Register download complete receiver
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context, intent: Intent?) {
                    val query = DownloadManager.Query().apply {
                        setFilterById(downloadRequestId ?: return)
                    }
                    val cursor = downloadManager.query(query)
                    var success = false
                    if (cursor.moveToFirst()) {
                        val columnIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
                        if (cursor.getInt(columnIndex) == DownloadManager.STATUS_SUCCESSFUL) {
                            success = true
                        }
                    }
                    cursor.close()

                    if (success && downloadFile != null && downloadFile!!.exists()) {
                        progressDialog.dismiss()
                        try {
                            val outputUri = FileProvider.getUriForFile(
                                context,
                                BuildConfig.APPLICATION_ID + ".provider",
                                downloadFile!!
                            )
                            val installIntent = Intent(Intent.ACTION_VIEW, outputUri).apply {
                                putExtra(Intent.EXTRA_NOT_UNKNOWN_SOURCE, true)
                                setDataAndType(outputUri, "application/vnd.android.package-archive")
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(installIntent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "Failed to open installer", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        progressDialog.dismiss()
                        Toast.makeText(context, "Download failed. Please try again.", Toast.LENGTH_SHORT).show()
                    }

                    try {
                        context.unregisterReceiver(this)
                    } catch (e: Exception) { /* already unregistered */ }
                }
            }

            activity.registerReceiver(receiver, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE))

            // Monitor download progress
            val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
                override fun onChange(selfChange: Boolean, uri: Uri?) {
                    super.onChange(selfChange, uri)
                    try {
                        val query = DownloadManager.Query()
                        query.setFilterById(downloadRequestId ?: return)
                        val c = downloadManager.query(query)
                        if (c.moveToFirst()) {
                            val sizeIndex = c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                            val downloadedIndex = c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                            val size = c.getInt(sizeIndex)
                            val downloaded = c.getInt(downloadedIndex)
                            if (size > 0) {
                                val pct = (downloaded * 100.0 / size).roundToInt()
                                progress.isIndeterminate = false
                                progress.progress = pct
                            }
                        }
                        c.close()
                    } catch (e: Exception) { /* ignore */ }
                }
            }

            activity.contentResolver.registerContentObserver(
                Uri.parse("content://downloads/my_downloads"), true, observer
            )

            // Start the download
            downloadRequestId = DownloadManager.Request(Uri.parse(url)).apply {
                setDescription(activity.getString(R.string.download_manager_description))
                setTitle(activity.getString(R.string.app_name))
                setDestinationUri(Uri.fromFile(downloadFile!!))
            }.run {
                downloadManager.enqueue(this)
            }

        } catch (e: Exception) {
            Toast.makeText(activity, "Failed to start download: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Dismiss any showing update dialog (call from onPause/onDestroy)
     */
    fun dismissDialog() {
        currentDialog?.dismiss()
        currentDialog = null
    }
}
