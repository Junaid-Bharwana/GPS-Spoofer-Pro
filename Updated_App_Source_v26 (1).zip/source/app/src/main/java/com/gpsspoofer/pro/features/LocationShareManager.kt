package com.gpsspoofer.pro.features

import android.content.Context
import android.content.Intent

/**
 * Handles sharing the current spoofed location via other apps (WhatsApp, Telegram, etc.)
 */
object LocationShareManager {

    /**
     * Share location as a Google Maps link via any app.
     */
    fun shareLocation(context: Context, lat: Double, lon: Double, address: String = "") {
        val mapsLink = "https://maps.google.com/?q=$lat,$lon"
        val text = if (address.isNotEmpty()) {
            "My location: $address\n$mapsLink"
        } else {
            "My location: $lat, $lon\n$mapsLink"
        }

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            putExtra(Intent.EXTRA_SUBJECT, "Shared Location")
        }
        context.startActivity(Intent.createChooser(intent, "Share Location"))
    }

    /**
     * Share location as coordinates text only.
     */
    fun shareCoordinates(context: Context, lat: Double, lon: Double, format: CoordinateConverter.Format = CoordinateConverter.Format.DECIMAL) {
        val formatted = CoordinateConverter.format(lat, lon, format)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, formatted)
        }
        context.startActivity(Intent.createChooser(intent, "Share Coordinates"))
    }
}
