package com.gpsspoofer.pro.repository


import androidx.annotation.WorkerThread
import com.gpsspoofer.pro.room.Favourite
import com.gpsspoofer.pro.room.FavouriteDao
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class FavouriteRepository @Inject constructor(private val favouriteDao: FavouriteDao) {

    val getAllFavourites: Flow<List<Favourite>> get() =  favouriteDao.getAllFavourites()

        @Suppress("RedundantSuspendModifier")
        @WorkerThread
        suspend fun addNewFavourite(favourite: Favourite) : Long {
            return favouriteDao.insertToRoomDatabase(favourite)
        }

        suspend fun deleteFavourite(favourite: Favourite) {
          favouriteDao.deleteSingleFavourite(favourite)
       }


       fun getSingleFavourite(id: Long) : Favourite {
       return favouriteDao.getSingleFavourite(id)

    }



}