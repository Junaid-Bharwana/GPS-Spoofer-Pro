package com.gpsspoofer.pro.features

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.gpsspoofer.pro.utils.PrefManager
import kotlin.math.cos
import kotlin.math.sin

/**
 * Manages joystick-based movement simulation.
 * Allows users to move the spoofed location in real-time using directional controls.
 */
class JoystickManager(private val onLocationUpdate: (Double, Double) -> Unit) {

    private val handler = Handler(Looper.getMainLooper())
    private var isMoving = false
    private var currentAngle = 0.0 // degrees
    private var currentSpeed = 1.4 // m/s (default walking speed ~5 km/h)
    private var currentLat = 0.0
    private var currentLon = 0.0
    private val updateIntervalMs = 1000L // update every second

    // Speed presets in m/s
    companion object {
        const val SPEED_WALKING = 1.4      // ~5 km/h
        const val SPEED_RUNNING = 3.0      // ~10.8 km/h
        const val SPEED_CYCLING = 5.6      // ~20 km/h
        const val SPEED_DRIVING = 13.9     // ~50 km/h
        const val SPEED_HIGHWAY = 27.8     // ~100 km/h

        private const val EARTH_RADIUS = 6378137.0 // meters
        private const val DEG_TO_RAD = Math.PI / 180.0
        private const val RAD_TO_DEG = 180.0 / Math.PI
    }

    private val movementRunnable = object : Runnable {
        override fun run() {
            if (isMoving) {
                moveInDirection(currentAngle, currentSpeed)
                handler.postDelayed(this, updateIntervalMs)
            }
        }
    }

    fun initialize(lat: Double, lon: Double) {
        currentLat = lat
        currentLon = lon
    }

    fun startMoving(angleDegrees: Double) {
        currentAngle = angleDegrees
        if (!isMoving) {
            isMoving = true
            handler.post(movementRunnable)
        }
    }

    fun stopMoving() {
        isMoving = false
        handler.removeCallbacks(movementRunnable)
    }

    fun setSpeed(speedMs: Double) {
        currentSpeed = speedMs.coerceIn(0.1, 100.0)
    }

    fun getSpeedKmh(): Double = currentSpeed * 3.6

    fun setSpeedKmh(speedKmh: Double) {
        currentSpeed = (speedKmh / 3.6).coerceIn(0.1, 100.0)
    }

    /**
     * Move the current position in a given direction by the current speed.
     * Uses the Haversine formula for accurate movement on a sphere.
     */
    private fun moveInDirection(angleDegrees: Double, speedMs: Double) {
        val distance = speedMs * (updateIntervalMs / 1000.0) // distance in meters per update
        val angleRad = angleDegrees * DEG_TO_RAD
        val latRad = currentLat * DEG_TO_RAD

        // Calculate displacement
        val dLat = (distance * cos(angleRad)) / EARTH_RADIUS * RAD_TO_DEG
        val dLon = (distance * sin(angleRad)) / (EARTH_RADIUS * cos(latRad)) * RAD_TO_DEG

        currentLat += dLat
        currentLon += dLon

        // Clamp to valid range
        currentLat = currentLat.coerceIn(-90.0, 90.0)
        currentLon = currentLon.coerceIn(-180.0, 180.0)

        onLocationUpdate(currentLat, currentLon)
    }

    /**
     * Single step move in a direction (for tap-based movement).
     */
    fun stepMove(angleDegrees: Double, distanceMeters: Double = currentSpeed) {
        val angleRad = angleDegrees * DEG_TO_RAD
        val latRad = currentLat * DEG_TO_RAD

        val dLat = (distanceMeters * cos(angleRad)) / EARTH_RADIUS * RAD_TO_DEG
        val dLon = (distanceMeters * sin(angleRad)) / (EARTH_RADIUS * cos(latRad)) * RAD_TO_DEG

        currentLat += dLat
        currentLon += dLon
        currentLat = currentLat.coerceIn(-90.0, 90.0)
        currentLon = currentLon.coerceIn(-180.0, 180.0)

        onLocationUpdate(currentLat, currentLon)
    }

    fun getCurrentLat() = currentLat
    fun getCurrentLon() = currentLon
    fun isCurrentlyMoving() = isMoving

    fun destroy() {
        stopMoving()
        handler.removeCallbacksAndMessages(null)
    }
}
