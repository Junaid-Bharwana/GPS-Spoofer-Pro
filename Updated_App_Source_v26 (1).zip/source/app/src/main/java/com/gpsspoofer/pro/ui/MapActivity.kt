package com.gpsspoofer.pro.ui

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.ProgressDialog
import android.content.Intent
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gpsspoofer.pro.BuildConfig
import com.gpsspoofer.pro.R
import com.gpsspoofer.pro.adapter.FavListAdapter
import com.gpsspoofer.pro.databinding.ActivityMapBinding
import com.gpsspoofer.pro.utils.NotificationsChannel
import com.gpsspoofer.pro.utils.ext.*
import com.gpsspoofer.pro.viewmodel.MainViewModel
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow
import java.io.IOException
import java.util.regex.Matcher
import java.util.regex.Pattern
import kotlin.properties.Delegates
import org.json.JSONObject
import com.gpsspoofer.pro.utils.AccountStatusChecker
import com.gpsspoofer.pro.service.MockLocationService
import com.gpsspoofer.pro.features.TeleportAnimator
import com.gpsspoofer.pro.features.ScheduledSpoofing
import com.gpsspoofer.pro.features.LocationHistory
import com.gpsspoofer.pro.features.GpxKmlManager
import com.gpsspoofer.pro.features.RouteSimulator
import com.gpsspoofer.pro.features.EnhancedNotifications
import com.gpsspoofer.pro.features.AltitudeManager
import com.gpsspoofer.pro.features.LocationProfileManager
import com.gpsspoofer.pro.features.LocationShareManager
import com.gpsspoofer.pro.features.ClipboardCoordinateDetector
import com.gpsspoofer.pro.features.CoordinateConverter
import com.gpsspoofer.pro.features.MapTypeSelector
import com.gpsspoofer.pro.features.SearchAutocomplete
import com.gpsspoofer.pro.features.RootDetector
import com.gpsspoofer.pro.features.SessionExpiryManager
import com.gpsspoofer.pro.features.HeartbeatWorker
import com.gpsspoofer.pro.features.BiometricLockManager
import com.gpsspoofer.pro.features.QuickToggleWidget
import com.gpsspoofer.pro.update.AppUpdateManager
import android.app.Activity
import android.net.Uri

@AndroidEntryPoint
class MapActivity : AppCompatActivity() {

    private val binding by lazy { ActivityMapBinding.inflate(layoutInflater) }
    private lateinit var webView: WebView
    private val viewModel by viewModels<MainViewModel>()
    private val update by lazy { viewModel.getAvailableUpdate() }
    private val notificationsChannel by lazy { NotificationsChannel() }
    private var favListAdapter: FavListAdapter = FavListAdapter()
    private var lat by Delegates.notNull<Double>()
    private var lon by Delegates.notNull<Double>()
    private var realLat: Double = 0.0
    private var realLon: Double = 0.0
    private var xposedDialog: AlertDialog? = null
    private lateinit var alertDialog: MaterialAlertDialogBuilder
    private lateinit var dialog: AlertDialog

    // Feature managers
    private lateinit var teleportAnimator: TeleportAnimator
    private lateinit var scheduledSpoofing: ScheduledSpoofing
    private lateinit var locationHistory: LocationHistory
    private lateinit var gpxKmlManager: GpxKmlManager
    private lateinit var routeSimulator: RouteSimulator
    private lateinit var enhancedNotifications: EnhancedNotifications
    private lateinit var altitudeManager: AltitudeManager
    private lateinit var profileManager: LocationProfileManager
    private lateinit var clipboardDetector: ClipboardCoordinateDetector
    private lateinit var sessionExpiryManager: SessionExpiryManager
    private lateinit var biometricLockManager: BiometricLockManager
    private var currentMapType = MapTypeSelector.MapType.STREET
    private var spoofingStartTime = 0L

    companion object {
        private const val REQUEST_IMPORT_FILE = 2001
        private const val REQUEST_EXPORT_FILE = 2002
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Anti-bypass login check
        if (!com.gpsspoofer.pro.utils.PrefManager.isUserLoggedIn()) {
            forceLogout("Please log in to continue.")
            return
        }

        // VPN detection on startup
        if (isVpnActive()) {
            forceLogout("VPN detected. Please disable VPN to use the app.")
            return
        }

        // Proxy detection on startup
        if (isProxyActive()) {
            forceLogout("Proxy detected. Please disable proxy to use the app.")
            return
        }

        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        
        checkAndRequestPermissions()
        initializeMap()
        initializeFeatures()
        setFloatActionButton()
        isModuleEnable()
        updateStatusCard()
        startLocationUpdates()
        binding.saveButton.setOnClickListener {
            addFavouriteDialog()
        }
        
        binding.randomButton.setOnClickListener {
            // Simple random movement within 0.01 degrees
            lat += (Math.random() - 0.5) * 0.02
            lon += (Math.random() - 0.5) * 0.02
            updateInputs()
            loadLeafletMap(lat, lon)
        }
        
        binding.currentLocationFab.setOnClickListener {
            if (viewModel.isStarted) {
                // If spoofing is on, show the spoofed location
                lat = viewModel.getLat
                lon = viewModel.getLng
                showToast("Showing spoofed location")
            } else {
                // If spoofing is off, show the real location
                if (realLat != 0.0 && realLon != 0.0) {
                    lat = realLat
                    lon = realLon
                    showToast("Showing real location")
                } else {
                    lat = viewModel.getLat
                    lon = viewModel.getLng
                    showToast("Real location not available yet")
                }
            }
            updateInputs()
            loadLeafletMap(lat, lon)
        }
    }

    private fun checkAndRequestPermissions() {
        val permissions = mutableListOf<String>()
        if (!checkSinglePermission(Manifest.permission.ACCESS_FINE_LOCATION)) {
            permissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (!checkSinglePermission(Manifest.permission.ACCESS_COARSE_LOCATION)) {
            permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            if (!checkSinglePermission(Manifest.permission.POST_NOTIFICATIONS)) {
                permissions.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        if (permissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissions.toTypedArray(), 1001)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001) {
            if (grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                startLocationUpdates()
            } else {
                showToast("Location permission is required for full functionality")
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startLocationUpdates() {
        val locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        if (checkSinglePermission(Manifest.permission.ACCESS_FINE_LOCATION)) {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                5000L,
                5f,
                object : LocationListener {
                    override fun onLocationChanged(location: Location) {
                        // Only update real coordinates if spoofing is NOT active
                        // Actually, we want to capture the REAL location regardless
                        // But the system might return the spoofed one if the hook is active
                        // For the app to know the REAL location while spoofing, it's tricky
                        // However, when spoofing is OFF, this will definitely be the real one.
                        if (!viewModel.isStarted) {
                            realLat = location.latitude
                            realLon = location.longitude
                        }
                    }
                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                    override fun onProviderEnabled(provider: String) {}
                    override fun onProviderDisabled(provider: String) {}
                }
            )
            
            // Get last known location as fallback
            val lastLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            if (lastLocation != null && !viewModel.isStarted) {
                realLat = lastLocation.latitude
                realLon = lastLocation.longitude
            }
        }
    }

    private fun updateInputs() {
        binding.latitudeInput.setText(String.format("%.6f", lat))
        binding.longitudeInput.setText(String.format("%.6f", lon))
    }

    private fun initializeMap() {
        webView = binding.mapContainer.map as WebView
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        webView.webViewClient = WebViewClient()
        
        // Add JavaScript Interface
        webView.addJavascriptInterface(object {
            @android.webkit.JavascriptInterface
            fun onMapClick(latitude: Double, longitude: Double) {
                runOnUiThread {
                    lat = latitude
                    lon = longitude
                    updateInputs()
                }
            }
        }, "AndroidBridge")
        
        lat = viewModel.getLat
        lon = viewModel.getLng
        updateInputs()
        
        loadLeafletMap(lat, lon)
    }

    private fun loadLeafletMap(latitude: Double, longitude: Double) {
        val htmlContent = """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8" />
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
                <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
                <style>
                    body { margin: 0; padding: 0; }
                    #map { position: absolute; top: 0; bottom: 0; width: 100%; }
                </style>
            </head>
            <body>
                <div id="map"></div>
                <script>
                    var map = L.map('map', {zoomControl: false}).setView([$latitude, $longitude], 13);
                    L.control.zoom({position: 'bottomleft'}).addTo(map);
                    L.tileLayer('https://mt1.google.com/vt/lyrs=m&hl=en&x={x}&y={y}&z={z}', {
                        attribution: '© Google Maps',
                        maxZoom: 20
                    }).addTo(map);
                    
                    var marker = L.marker([$latitude, $longitude], {draggable: false}).addTo(map);
                    var userMarker = L.marker([$latitude, $longitude], {
                        icon: L.icon({
                            iconUrl: 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0Ij48cGF0aCBmaWxsPSIjRkZGRkZGIiBkPSJNMTIgMEMxMi4wNDQgMCAxMi4wODggMCAxMi4xMzIgMEMxNy42NjggMC4wNTIgMjIuMTI4IDQuNTEyIDIyLjE4IDEwLjA0OEMyMi4yMzIgMTUuNTg0IDE4LjAwOCAyMC4wNDggMTIuNDcyIDIwLjEwMEMxMi4zNjggMjAuMTAwIDEyLjI2NCAyMC4xMDAgMTIuMTYgMjAuMTAwQzEyLjExNiAyMC4xMDAgMTIuMDcyIDIwLjEwMCAxMi4wMjggMjAuMTAwQzYuNDkyIDIwLjA0OCAyLjA2OCAxNS41ODQgMi4wMTYgMTAuMDQ4QzEuOTY0IDQuNTEyIDYuNDMyIDAgMTIgMFpNMTIgMTJDMTMuMTA0IDEyIDE0IDE1LjEwNCAxNCAxMEM0IDEyLjg5NiAxMyAxMiAxMiAxMloiLz48L3N2Zz4=',
                            iconSize: [32, 32],
                            iconAnchor: [16, 16]
                        })
                    }).addTo(map);
                    
                    map.on('click', function(e) {
                        marker.setLatLng(e.latlng);
                        window.AndroidBridge.onMapClick(e.latlng.lat, e.latlng.lng);
                    });
                </script>
            </body>
            </html>
        """.trimIndent()
        
        webView.loadDataWithBaseURL(null, htmlContent, "text/html", "UTF-8", null)
    }

    private fun updateStatusCard() {
        if (viewModel.isStarted) {
            binding.mapContainer.statusText.text = "Spoofing active at: ${lat}, ${lon}"
            binding.mapContainer.statusCard.setStrokeColor(android.content.res.ColorStateList.valueOf(getColor(R.color.success)))
        } else {
            binding.mapContainer.statusText.text = "Ready to set location"
            binding.mapContainer.statusCard.setStrokeColor(android.content.res.ColorStateList.valueOf(getColor(R.color.primary)))
        }
    }

    private fun isModuleEnable() {
        // Only show Xposed module check if in LSPosed mode
        if (com.gpsspoofer.pro.utils.PrefManager.spoofingMode == com.gpsspoofer.pro.utils.PrefManager.MODE_LSPOSED) {
            viewModel.isXposed.observe(this) { isXposed ->
                xposedDialog?.dismiss()
                xposedDialog = null
                if (!isXposed) {
                    xposedDialog = MaterialAlertDialogBuilder(this).run {
                        setTitle(R.string.error_xposed_module_missing)
                        setMessage(R.string.error_xposed_module_missing_desc)
                        setCancelable(BuildConfig.DEBUG)
                        show()
                    }
                }
            }
        } else {
            // In Mock Location mode, dismiss any Xposed dialog
            xposedDialog?.dismiss()
            xposedDialog = null
        }
    }

    private fun setFloatActionButton() {
        if (viewModel.isStarted) {
            binding.start.visibility = View.GONE
            binding.stop.visibility = View.VISIBLE
        }

        binding.start.setOnClickListener {
            // Instant security check before starting
            lifecycleScope.launch(Dispatchers.IO) {
                performHeartbeatCheck()
                withContext(Dispatchers.Main) {
                    try {
                        lat = binding.latitudeInput.text.toString().toDouble()
                        lon = binding.longitudeInput.text.toString().toDouble()
                    } catch (e: Exception) {
                        showToast("Invalid coordinates")
                        return@withContext
                    }

                    val spoofingMode = com.gpsspoofer.pro.utils.PrefManager.spoofingMode
                    if (spoofingMode == com.gpsspoofer.pro.utils.PrefManager.MODE_MOCK_LOCATION) {
                        // Mock Location mode
                        if (!MockLocationService.isProviderSetupCorrectly(this@MapActivity)) {
                            showMockLocationSetupDialog()
                            return@withContext
                        }
                        val accuracy = (com.gpsspoofer.pro.utils.PrefManager.accuracy ?: "10").toFloat()
                        MockLocationService.start(this@MapActivity, lat, lon, accuracy)
                        viewModel.update(true, lat, lon)
                    } else {
                        // LSPosed mode
                        viewModel.update(true, lat, lon)
                    }

                    spoofingStartTime = System.currentTimeMillis()
                    binding.start.visibility = View.GONE
                    binding.stop.visibility = View.VISIBLE

                    lifecycleScope.launch {
                        val address = getAddressFromCoordinates(lat, lon)
                        showStartNotification(address)
                        binding.mapContainer.statusText.text = "Spoofing active at: $address"
                        // Track in history
                        locationHistory.addEntry(lat, lon, address)
                        // Enhanced notification
                        val modeStr = if (spoofingMode == com.gpsspoofer.pro.utils.PrefManager.MODE_MOCK_LOCATION) "Mock" else "LSPosed"
                        enhancedNotifications.showSpoofingNotification(lat, lon, address, modeStr)
                    }
                    binding.mapContainer.statusCard.setStrokeColor(android.content.res.ColorStateList.valueOf(getColor(R.color.success)))
                    showToast(getString(R.string.location_set))
                }
            }
        }

        binding.stop.setOnClickListener {
            val spoofingMode = com.gpsspoofer.pro.utils.PrefManager.spoofingMode
            if (spoofingMode == com.gpsspoofer.pro.utils.PrefManager.MODE_MOCK_LOCATION) {
                MockLocationService.stop(this)
            }
            viewModel.update(false, lat, lon)
            binding.stop.visibility = View.GONE
            binding.start.visibility = View.VISIBLE
            routeSimulator.stop()

            // Update history duration
            if (spoofingStartTime > 0) {
                locationHistory.updateLastEntryDuration(System.currentTimeMillis() - spoofingStartTime)
                spoofingStartTime = 0L
            }

            cancelNotification()
            binding.mapContainer.statusText.text = "Ready to set location"
            binding.mapContainer.statusCard.setStrokeColor(android.content.res.ColorStateList.valueOf(getColor(R.color.primary)))
            showToast(getString(R.string.location_unset))
        }
    }

    private suspend fun getAddressFromCoordinates(lat: Double, lon: Double): String {
        return withContext(Dispatchers.IO) {
            try {
                val addresses = Geocoder(this@MapActivity).getFromLocation(lat, lon, 1)
                if (addresses != null && addresses.isNotEmpty()) {
                    addresses[0].getAddressLine(0)
                } else {
                    "$lat, $lon"
                }
            } catch (e: IOException) {
                "$lat, $lon"
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.updateXposedState()
        startHeartbeatCheck()

        // VPN detection on resume
        if (isVpnActive()) {
            forceLogout("VPN detected. Please disable VPN to use the app.")
            return
        }

        // Proxy detection on resume
        if (isProxyActive()) {
            forceLogout("Proxy detected. Please disable proxy to use the app.")
            return
        }

        // Check for app updates from backend
        AppUpdateManager.checkForUpdate(this)
    }

    override fun onPause() {
        super.onPause()
        heartbeatJob?.cancel()
        AppUpdateManager.dismissDialog()
    }


    private var heartbeatJob: Job? = null

    private fun startHeartbeatCheck() {
        heartbeatJob?.cancel()
        heartbeatJob = lifecycleScope.launch(Dispatchers.IO) {
            while (isActive) {
                performHeartbeatCheck()
                delay(10 * 1000L)
            }
        }
    }

    private suspend fun performHeartbeatCheck() {
        val userId = com.gpsspoofer.pro.utils.PrefManager.getUserId()
        if (userId == -1) {
            withContext(Dispatchers.Main) {
                forceLogout("User ID not found. Please log in again.")
            }
            return
        }

        val status = AccountStatusChecker.checkAccountStatus(userId)
        when (status) {
            is AccountStatusChecker.AccountStatus.Inactive -> {
                withContext(Dispatchers.Main) {
                    forceLogout(status.message)
                }
            }
            is AccountStatusChecker.AccountStatus.Maintenance -> {
                withContext(Dispatchers.Main) {
                    heartbeatJob?.cancel()
                    cancelNotification()
                    AccountStatusChecker.showMaintenance(this@MapActivity, status.title, status.message)
                }
            }
            else -> { /* Active or NetworkError - do nothing */ }
        }
    }

    private fun showMockLocationSetupDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.mock_location_setup_title)
            .setMessage(R.string.mock_location_setup_message)
            .setPositiveButton(R.string.dialog_button_ok, null)
            .show()
    }

    private fun forceLogout(message: String) {
        // Stop all ongoing operations before logging out
        heartbeatJob?.cancel()
        // Stop mock location service if running
        if (com.gpsspoofer.pro.utils.PrefManager.spoofingMode == com.gpsspoofer.pro.utils.PrefManager.MODE_MOCK_LOCATION) {
            MockLocationService.stop(this)
        }
        viewModel.update(false, lat, lon) // Stop spoofing
        cancelNotification() // Cancel any active notifications

        com.gpsspoofer.pro.utils.PrefManager.logout()
        showToast(message)
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    private fun aboutDialog() {
        alertDialog = MaterialAlertDialogBuilder(this)
        layoutInflater.inflate(R.layout.about, null).apply {
            val title = findViewById<TextView>(R.id.design_about_title)
            val version = findViewById<TextView>(R.id.design_about_version)
            val info = findViewById<TextView>(R.id.design_about_info)
            title.text = getString(R.string.app_name)
            version.text = BuildConfig.VERSION_NAME
            info.text = getString(R.string.about_info)
        }.run {
            alertDialog.setView(this)
            alertDialog.show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Update session activity on any interaction
        if (::sessionExpiryManager.isInitialized) sessionExpiryManager.updateLastActivity()

        when (item.itemId) {
            R.id.search -> searchDialog()
            R.id.get_favourite -> openFavouriteListDialog()
            R.id.location_history -> showLocationHistoryDialog()
            R.id.settings -> startActivity(Intent(this, SettingsActivity::class.java))
            R.id.subscription -> startActivity(Intent(this, SubscriptionActivity::class.java))
            R.id.logout -> {
                HeartbeatWorker.cancel(this)
                com.gpsspoofer.pro.utils.PrefManager.logout()
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }
            else -> super.onOptionsItemSelected(item)
        }
        return true
    }

    private fun searchDialog() {
        alertDialog = MaterialAlertDialogBuilder(this)
        val view = layoutInflater.inflate(R.layout.dialog_layout, null)
        val editText = view.findViewById<EditText>(R.id.search_edittxt)
        val progressBar = ProgressDialog(this)
        progressBar.setMessage("Searching...")
        alertDialog.setTitle("Search")
        alertDialog.setView(view)
        alertDialog.setPositiveButton("Search") { _, _ ->
            if (isNetworkConnected()) {
                lifecycleScope.launch(Dispatchers.Main) {
                    val getInput = editText.text.toString()
                    if (getInput.isNotEmpty()) {
                        getSearchAddress(getInput).let {
                            it.collect { result ->
                                when (result) {
                                    is SearchProgress.Progress -> {
                                        progressBar.show()
                                    }
                                    is SearchProgress.Complete -> {
                                        lat = result.lat
                                        lon = result.lon
                                        progressBar.dismiss()
                                        loadLeafletMap(lat, lon)
                                    }
                                    is SearchProgress.Fail -> {
                                        progressBar.dismiss()
                                        showToast(result.error!!)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                showToast(getString(R.string.no_internet))
            }
        }
        alertDialog.show()
    }

    private fun addFavouriteDialog() {
        alertDialog = MaterialAlertDialogBuilder(this).apply {
            val view = layoutInflater.inflate(R.layout.dialog_layout, null)
            val editText = view.findViewById<EditText>(R.id.search_edittxt)
            setTitle(getString(R.string.add_fav_dialog_title))
            setPositiveButton(getString(R.string.dialog_button_add)) { _, _ ->
                val s = editText.text.toString()
                viewModel.storeFavorite(s, lat, lon)
                viewModel.response.observe(this@MapActivity) {
                    if (it == (-1).toLong()) showToast("Can't save") else showToast("Save")
                }
            }
            setView(view)
            show()
        }
    }

    private fun openFavouriteListDialog() {
        getAllUpdatedFavList()
        alertDialog = MaterialAlertDialogBuilder(this)
        alertDialog.setTitle(getString(R.string.favourites))
        val view = layoutInflater.inflate(R.layout.fav, null)
        val rcv = view.findViewById<RecyclerView>(R.id.favorites_list)
        rcv.layoutManager = LinearLayoutManager(this)
        rcv.adapter = favListAdapter
        favListAdapter.onItemClick = {
            it.let {
                lat = it.lat!!
                lon = it.lng!!
            }
            loadLeafletMap(lat, lon)
            if (dialog.isShowing) dialog.dismiss()
        }
        favListAdapter.onItemDelete = {
            viewModel.deleteFavourite(it)
        }
        alertDialog.setView(view)
        dialog = alertDialog.create()
        dialog.show()
    }

    private fun getAllUpdatedFavList() {
        lifecycleScope.launch {
            lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.doGetUserDetails()
                viewModel.allFavList.collect {
                    favListAdapter.submitList(it)
                }
            }
        }
    }

    private fun updateDialog() {
        alertDialog = MaterialAlertDialogBuilder(this)
        alertDialog.setTitle(R.string.update_available)
        alertDialog.setMessage(update?.changelog)
        alertDialog.setPositiveButton(getString(R.string.update_button)) { _, _ ->
            MaterialAlertDialogBuilder(this).apply {
                val view = layoutInflater.inflate(R.layout.update_dialog, null)
                val progress = view.findViewById<LinearProgressIndicator>(R.id.update_download_progress)
                val cancel = view.findViewById<AppCompatButton>(R.id.update_download_cancel)
                setView(view)
                cancel.setOnClickListener {
                    viewModel.cancelDownload(this@MapActivity)
                    dialog.dismiss()
                }
                lifecycleScope.launch {
                    viewModel.downloadState.collect {
                        when (it) {
                            is MainViewModel.State.Downloading -> {
                                if (it.progress > 0) {
                                    progress.isIndeterminate = false
                                    progress.progress = it.progress
                                }
                            }
                            is MainViewModel.State.Done -> {
                                viewModel.openPackageInstaller(this@MapActivity, it.fileUri)
                                viewModel.clearUpdate()
                                dialog.dismiss()
                            }
                            is MainViewModel.State.Failed -> {
                                Toast.makeText(
                                    this@MapActivity,
                                    R.string.bs_update_download_failed,
                                    Toast.LENGTH_LONG
                                ).show()
                                dialog.dismiss()
                            }
                            else -> {}
                        }
                    }
                }
                update?.let { it ->
                    viewModel.startDownload(this@MapActivity, it)
                } ?: run {
                    dialog.dismiss()
                }
            }.run {
                dialog = create()
                dialog.show()
            }
        }
        dialog = alertDialog.create()
        dialog.show()
    }

    private fun updateChecker() {
        lifecycleScope.launchWhenResumed {
            viewModel.update.collect {
                if (it != null) {
                    if (it.forceUpdate) {
                        showForceUpdateDialog(it)
                    } else {
                        updateDialog()
                    }
                }
            }
        }
    }

    private suspend fun getSearchAddress(address: String) = callbackFlow {
        withContext(Dispatchers.IO) {
            trySend(SearchProgress.Progress)
            val matcher: Matcher =
                Pattern.compile("[-+]?\\d{1,3}([.]\\d+)?, *[-+]?\\d{1,3}([.]\\d+)?").matcher(address)

            if (matcher.matches()) {
                delay(3000)
                trySend(SearchProgress.Complete(matcher.group().split(",")[0].toDouble(), matcher.group().split(",")[1].toDouble()))
            } else {
                try {
                    val list: List<Address>? = Geocoder(this@MapActivity).getFromLocationName(address, 5)
                    list?.let {
                        if (it.size == 1) {
                            trySend(SearchProgress.Complete(list[0].latitude, list[0].longitude))
                        } else {
                            trySend(SearchProgress.Fail(getString(R.string.address_not_found)))
                        }
                    }
                } catch (io: IOException) {
                    trySend(SearchProgress.Fail(getString(R.string.no_internet)))
                }
            }
        }
        awaitClose { this.cancel() }
    }

    private fun showStartNotification(address: String) {
        notificationsChannel.showNotification(this) {
            it.setSmallIcon(R.drawable.ic_stop)
            it.setContentTitle(getString(R.string.location_set))
            it.setContentText(address)
            it.setAutoCancel(true)
            it.setCategory(Notification.CATEGORY_EVENT)
            it.priority = NotificationCompat.PRIORITY_HIGH
        }
    }

    private fun cancelNotification() {
        notificationsChannel.cancelAllNotifications(this)
        if (::enhancedNotifications.isInitialized) {
            enhancedNotifications.cancelAll()
        }
    }

    // ==================== Feature Integration ====================

    private fun initializeFeatures() {
        locationHistory = LocationHistory(this)
        gpxKmlManager = GpxKmlManager(this)
        enhancedNotifications = EnhancedNotifications(this)
        altitudeManager = AltitudeManager(this)
        profileManager = LocationProfileManager(this)
        clipboardDetector = ClipboardCoordinateDetector(this)
        sessionExpiryManager = SessionExpiryManager(this)
        biometricLockManager = BiometricLockManager(this)

        teleportAnimator = TeleportAnimator { newLat, newLon ->
            runOnUiThread {
                lat = newLat
                lon = newLon
                updateInputs()
                loadLeafletMap(lat, lon)
                if (viewModel.isStarted) {
                    applySpoofedLocation(lat, lon)
                }
            }
        }

        routeSimulator = RouteSimulator { newLat, newLon ->
            runOnUiThread {
                lat = newLat
                lon = newLon
                updateInputs()
                loadLeafletMap(lat, lon)
                if (viewModel.isStarted) {
                    applySpoofedLocation(lat, lon)
                }
            }
        }

        scheduledSpoofing = ScheduledSpoofing()

        // Schedule WorkManager heartbeat (battery-efficient)
        HeartbeatWorker.schedule(this)

        // Update session activity
        sessionExpiryManager.updateLastActivity()

        // Root detection on first launch - auto-suggest LSPosed mode
        val rootStatus = RootDetector.detect()
        if (rootStatus.hasLSPosed && com.gpsspoofer.pro.utils.PrefManager.spoofingMode != com.gpsspoofer.pro.utils.PrefManager.MODE_LSPOSED) {
            // LSPosed is available but not selected, suggest it
            MaterialAlertDialogBuilder(this)
                .setTitle(getString(R.string.root_status))
                .setMessage(RootDetector.getRecommendation(rootStatus))
                .setPositiveButton("Use LSPosed") { _, _ ->
                    com.gpsspoofer.pro.utils.PrefManager.spoofingMode = com.gpsspoofer.pro.utils.PrefManager.MODE_LSPOSED
                    showToast("Switched to LSPosed mode")
                }
                .setNegativeButton("Keep Current", null)
                .show()
        }
    }

    private fun applySpoofedLocation(latitude: Double, longitude: Double) {
        val spoofingMode = com.gpsspoofer.pro.utils.PrefManager.spoofingMode
        if (spoofingMode == com.gpsspoofer.pro.utils.PrefManager.MODE_MOCK_LOCATION) {
            val accuracy = (com.gpsspoofer.pro.utils.PrefManager.accuracy ?: "10").toFloat()
            MockLocationService.start(this, latitude, longitude, accuracy)
        }
        viewModel.update(true, latitude, longitude)
    }

    private fun showTimerDialog() {
        val timerOptions = arrayOf(
            getString(R.string.timer_15_min),
            getString(R.string.timer_30_min),
            getString(R.string.timer_1_hour),
            getString(R.string.timer_2_hours),
            getString(R.string.timer_4_hours),
            getString(R.string.timer_8_hours),
            getString(R.string.cancel_timer)
        )
        val timerValues = longArrayOf(
            15 * 60 * 1000L,
            30 * 60 * 1000L,
            60 * 60 * 1000L,
            2 * 60 * 60 * 1000L,
            4 * 60 * 60 * 1000L,
            8 * 60 * 60 * 1000L,
            0L
        )
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.set_timer))
            .setItems(timerOptions) { _, which ->
                if (which == timerOptions.size - 1) {
                    // Cancel timer
                    scheduledSpoofing.cancel()
                    binding.timerLabel.visibility = View.GONE
                    enhancedNotifications.cancelTimer()
                } else {
                    scheduledSpoofing.startTimer(
                        timerValues[which],
                        tickCallback = { remaining ->
                            runOnUiThread {
                                binding.timerLabel.visibility = View.VISIBLE
                                binding.timerLabel.text = getString(R.string.timer_running, scheduledSpoofing.formatRemaining())
                                enhancedNotifications.showTimerNotification(scheduledSpoofing.formatRemaining())
                            }
                        },
                        finishCallback = {
                            runOnUiThread {
                                binding.timerLabel.visibility = View.GONE
                                enhancedNotifications.cancelTimer()
                                if (viewModel.isStarted) {
                                    binding.stop.performClick()
                                    showToast(getString(R.string.timer_expired))
                                }
                            }
                        }
                    )
                }
            }
            .show()
    }

    private fun showLocationHistoryDialog() {
        val entries = locationHistory.getEntries()
        if (entries.isEmpty()) {
            showToast(getString(R.string.no_history))
            return
        }

        val items = entries.map { entry ->
            val addr = if (entry.address.isNotEmpty()) entry.address else "${entry.lat}, ${entry.lon}"
            val time = java.text.SimpleDateFormat("MM/dd HH:mm", java.util.Locale.getDefault())
                .format(java.util.Date(entry.timestamp))
            "$addr\n$time"
        }.toTypedArray()

        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.location_history))
            .setItems(items) { _, which ->
                val entry = entries[which]
                lat = entry.lat
                lon = entry.lon
                updateInputs()
                loadLeafletMap(lat, lon)
            }
            .setNeutralButton(getString(R.string.clear_history)) { _, _ ->
                locationHistory.clearHistory()
                showToast(getString(R.string.history_cleared))
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun openImportFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/gpx+xml", "application/vnd.google-earth.kml+xml",
                "text/xml", "application/xml"
            ))
        }
        startActivityForResult(intent, REQUEST_IMPORT_FILE)
    }

    private fun showExportDialog() {
        val entries = locationHistory.getEntries()
        if (entries.isEmpty()) {
            showToast(getString(R.string.no_history))
            return
        }

        val waypoints = entries.map { GpxKmlManager.Waypoint(it.address, it.lat, it.lon) }
        val formats = arrayOf(getString(R.string.format_gpx), getString(R.string.format_kml))

        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.export_format))
            .setItems(formats) { _, which ->
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    if (which == 0) {
                        type = "application/gpx+xml"
                        putExtra(Intent.EXTRA_TITLE, "spoofed_locations.gpx")
                    } else {
                        type = "application/vnd.google-earth.kml+xml"
                        putExtra(Intent.EXTRA_TITLE, "spoofed_locations.kml")
                    }
                }
                startActivityForResult(intent, REQUEST_EXPORT_FILE)
            }
            .show()
    }

    @Deprecated("Use Activity Result API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data == null) return

        when (requestCode) {
            REQUEST_IMPORT_FILE -> {
                val uri = data.data ?: return
                val waypoints = gpxKmlManager.importFromUri(uri)
                if (waypoints.isNotEmpty()) {
                    showToast(getString(R.string.import_success, waypoints.size))
                    // Navigate to first waypoint
                    lat = waypoints[0].lat
                    lon = waypoints[0].lon
                    updateInputs()
                    loadLeafletMap(lat, lon)

                    // If multiple waypoints, offer route simulation
                    if (waypoints.size > 1) {
                        MaterialAlertDialogBuilder(this)
                            .setTitle(getString(R.string.route_simulation))
                            .setMessage("Imported ${waypoints.size} waypoints. Start route simulation?")
                            .setPositiveButton(getString(R.string.route_start)) { _, _ ->
                                routeSimulator.setWaypoints(waypoints.map {
                                    Pair(it.lat, it.lon)
                                })
                                routeSimulator.start(lat, lon)
                            }
                            .setNegativeButton(android.R.string.cancel, null)
                            .show()
                    }
                } else {
                    showToast(getString(R.string.import_failed))
                }
            }
            REQUEST_EXPORT_FILE -> {
                val uri = data.data ?: return
                val entries = locationHistory.getEntries()
                val waypoints = entries.map { GpxKmlManager.Waypoint(it.address, it.lat, it.lon) }
                val uriStr = uri.toString()
                try {
                    val outputStream = contentResolver.openOutputStream(uri)
                    if (outputStream != null) {
                        if (uriStr.endsWith(".kml")) {
                            gpxKmlManager.exportToKml(waypoints, outputStream)
                        } else {
                            gpxKmlManager.exportToGpx(waypoints, outputStream)
                        }
                        outputStream.close()
                        showToast(getString(R.string.export_success))
                    } else {
                        showToast(getString(R.string.export_failed))
                    }
                } catch (e: Exception) {
                    showToast(getString(R.string.export_failed))
                }
            }
        }
    }

    // ==================== New Feature Dialogs ====================

    private fun showLocationProfilesDialog() {
        val profiles = profileManager.getProfiles()
        val options = mutableListOf("Save Current Location as Profile")
        profiles.forEach { options.add("${it.name} (${String.format("%.4f", it.lat)}, ${String.format("%.4f", it.lon)})") }

        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.location_profiles))
            .setItems(options.toTypedArray()) { _, which ->
                if (which == 0) {
                    // Save current location as profile
                    val input = EditText(this).apply {
                        hint = getString(R.string.profile_name_hint)
                        setPadding(48, 32, 48, 16)
                    }
                    MaterialAlertDialogBuilder(this)
                        .setTitle(getString(R.string.save_profile))
                        .setView(input)
                        .setPositiveButton("Save") { _, _ ->
                            val name = input.text.toString().trim()
                            if (name.isNotEmpty()) {
                                val altitude = if (::altitudeManager.isInitialized) altitudeManager.altitude else 0.0
                                val accuracy = (com.gpsspoofer.pro.utils.PrefManager.accuracy ?: "10").toFloat()
                                profileManager.saveProfile(
                                    LocationProfileManager.Profile(name, lat, lon, altitude, accuracy)
                                )
                                showToast(getString(R.string.profile_saved))
                            }
                        }
                        .setNegativeButton(android.R.string.cancel, null)
                        .show()
                } else {
                    // Load selected profile
                    val profile = profiles[which - 1]
                    lat = profile.lat
                    lon = profile.lon
                    if (::altitudeManager.isInitialized) {
                        altitudeManager.altitude = profile.altitude
                        altitudeManager.isEnabled = profile.altitude != 0.0
                    }
                    updateInputs()
                    loadLeafletMap(lat, lon)
                    showToast("Loaded: ${profile.name}")
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showAltitudeDialog() {
        val input = EditText(this).apply {
            hint = getString(R.string.altitude_hint)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
            setPadding(48, 32, 48, 16)
            if (::altitudeManager.isInitialized && altitudeManager.isEnabled) {
                setText(String.format("%.1f", altitudeManager.altitude))
            }
        }

        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.set_altitude))
            .setView(input)
            .setPositiveButton("Set") { _, _ ->
                val altStr = input.text.toString().trim()
                val alt = altStr.toDoubleOrNull()
                if (alt != null && ::altitudeManager.isInitialized) {
                    altitudeManager.altitude = alt
                    altitudeManager.isEnabled = true
                    showToast(getString(R.string.altitude_set, String.format("%.1f", alt)))
                }
            }
            .setNeutralButton("Reset") { _, _ ->
                if (::altitudeManager.isInitialized) {
                    altitudeManager.isEnabled = false
                    altitudeManager.altitude = 0.0
                    showToast("Altitude reset to default")
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun pasteFromClipboard() {
        if (!::clipboardDetector.isInitialized) return
        val coords = clipboardDetector.detectFromClipboard()
        if (coords != null) {
            lat = coords.first
            lon = coords.second
            updateInputs()
            loadLeafletMap(lat, lon)
            showToast(getString(R.string.clipboard_coordinates_found))
        } else {
            showToast(getString(R.string.clipboard_no_coordinates))
        }
    }

    private fun showCoordinateFormatDialog() {
        val formats = arrayOf(
            getString(R.string.format_decimal),
            getString(R.string.format_dms),
            getString(R.string.format_utm),
            getString(R.string.format_plus_code)
        )
        val formatValues = arrayOf(
            CoordinateConverter.Format.DECIMAL,
            CoordinateConverter.Format.DMS,
            CoordinateConverter.Format.UTM,
            CoordinateConverter.Format.PLUS_CODE
        )

        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.coordinate_format))
            .setItems(formats) { _, which ->
                val formatted = CoordinateConverter.format(lat, lon, formatValues[which])
                MaterialAlertDialogBuilder(this)
                    .setTitle(formats[which])
                    .setMessage(formatted)
                    .setPositiveButton("Copy") { _, _ ->
                        val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("coordinates", formatted))
                        showToast("Copied to clipboard")
                    }
                    .setNeutralButton("Share") { _, _ ->
                        LocationShareManager.shareCoordinates(this, lat, lon, formatValues[which])
                    }
                    .setNegativeButton(android.R.string.cancel, null)
                    .show()
            }
            .show()
    }

    private fun showMapTypeDialog() {
        val types = MapTypeSelector.getDisplayNames()
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.map_type))
            .setItems(types) { _, which ->
                currentMapType = MapTypeSelector.getMapTypes()[which]
                loadLeafletMap(lat, lon)
                showToast("Map: ${currentMapType.displayName}")
            }
            .show()
    }

    private fun showRootStatusDialog() {
        val status = RootDetector.detect()
        val recommendation = RootDetector.getRecommendation(status)
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.root_status))
            .setMessage("${status.details}\n\n$recommendation")
            .setPositiveButton(getString(R.string.dialog_button_ok), null)
            .show()
    }

    // ==================== Force Update Dialog ====================

    private fun showForceUpdateDialog(update: com.gpsspoofer.pro.update.UpdateChecker.Update) {
        val builder = MaterialAlertDialogBuilder(this)
            .setTitle("Update Required")
            .setMessage("A new version (${update.name}) is available.\n\n${update.changelog}\n\nYou must update to continue using the app.")
            .setCancelable(false)
            .setPositiveButton("Update Now") { _, _ ->
                // Start download
                viewModel.startDownload(this, update)
            }

        if (!update.forceUpdate) {
            builder.setNegativeButton("Later", null)
        }

        builder.show()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::teleportAnimator.isInitialized) teleportAnimator.cancel()
        if (::scheduledSpoofing.isInitialized) scheduledSpoofing.cancel()
        if (::routeSimulator.isInitialized) routeSimulator.stop()
        if (::enhancedNotifications.isInitialized) enhancedNotifications.cancelAll()
    }
}

sealed class SearchProgress {
    object Progress : SearchProgress()
    data class Complete(val lat: Double, val lon: Double) : SearchProgress()
    data class Fail(val error: String?) : SearchProgress()
}
