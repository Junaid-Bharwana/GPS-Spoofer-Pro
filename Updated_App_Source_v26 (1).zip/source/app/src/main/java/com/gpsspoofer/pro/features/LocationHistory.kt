package com.gpsspoofer.pro.features

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * Tracks location spoofing history.
 * Stores recent spoofed locations for quick re-use.
 */
class LocationHistory(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        "location_history", Context.MODE_PRIVATE
    )

    companion object {
        private const val KEY_HISTORY = "history_entries"
        private const val MAX_ENTRIES = 50
    }

    data class HistoryEntry(
        val lat: Double,
        val lon: Double,
        val address: String,
        val timestamp: Long,
        val durationMs: Long = 0
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("lat", lat)
            put("lon", lon)
            put("address", address)
            put("timestamp", timestamp)
            put("duration", durationMs)
        }

        companion object {
            fun fromJson(json: JSONObject): HistoryEntry = HistoryEntry(
                lat = json.getDouble("lat"),
                lon = json.getDouble("lon"),
                address = json.optString("address", ""),
                timestamp = json.getLong("timestamp"),
                durationMs = json.optLong("duration", 0)
            )
        }
    }

    /**
     * Add a location to history.
     */
    fun addEntry(lat: Double, lon: Double, address: String) {
        val entries = getEntries().toMutableList()
        entries.add(0, HistoryEntry(lat, lon, address, System.currentTimeMillis()))

        // Keep only the most recent entries
        while (entries.size > MAX_ENTRIES) {
            entries.removeAt(entries.size - 1)
        }

        saveEntries(entries)
    }

    /**
     * Update the duration of the most recent entry.
     */
    fun updateLastEntryDuration(durationMs: Long) {
        val entries = getEntries().toMutableList()
        if (entries.isNotEmpty()) {
            entries[0] = entries[0].copy(durationMs = durationMs)
            saveEntries(entries)
        }
    }

    /**
     * Get all history entries, most recent first.
     */
    fun getEntries(): List<HistoryEntry> {
        val json = prefs.getString(KEY_HISTORY, "[]") ?: "[]"
        return try {
            val array = JSONArray(json)
            (0 until array.length()).map { HistoryEntry.fromJson(array.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * Clear all history entries.
     */
    fun clearHistory() {
        prefs.edit().putString(KEY_HISTORY, "[]").apply()
    }

    /**
     * Delete a specific entry by index.
     */
    fun deleteEntry(index: Int) {
        val entries = getEntries().toMutableList()
        if (index in entries.indices) {
            entries.removeAt(index)
            saveEntries(entries)
        }
    }

    private fun saveEntries(entries: List<HistoryEntry>) {
        val array = JSONArray()
        entries.forEach { array.put(it.toJson()) }
        prefs.edit().putString(KEY_HISTORY, array.toString()).apply()
    }
}
