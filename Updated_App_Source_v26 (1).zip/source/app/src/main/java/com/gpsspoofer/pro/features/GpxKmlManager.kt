package com.gpsspoofer.pro.features

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*
import javax.xml.parsers.DocumentBuilderFactory

/**
 * GPX and KML file import/export for location data.
 * Supports importing waypoints from GPX/KML files and exporting favourites.
 */
class GpxKmlManager(private val context: Context) {

    data class Waypoint(
        val name: String,
        val lat: Double,
        val lon: Double,
        val description: String = ""
    )

    /**
     * Import waypoints from a GPX or KML file URI.
     */
    fun importFromUri(uri: Uri): List<Waypoint> {
        val inputStream = context.contentResolver.openInputStream(uri) ?: return emptyList()
        val content = BufferedReader(InputStreamReader(inputStream)).use { it.readText() }
        inputStream.close()

        return when {
            content.contains("<gpx", ignoreCase = true) -> parseGpx(content)
            content.contains("<kml", ignoreCase = true) -> parseKml(content)
            else -> emptyList()
        }
    }

    /**
     * Parse GPX format waypoints.
     */
    private fun parseGpx(content: String): List<Waypoint> {
        val waypoints = mutableListOf<Waypoint>()
        try {
            val factory = DocumentBuilderFactory.newInstance()
            factory.isNamespaceAware = false
            val builder = factory.newDocumentBuilder()
            val doc = builder.parse(content.byteInputStream())

            // Parse <wpt> elements
            val wptNodes = doc.getElementsByTagName("wpt")
            for (i in 0 until wptNodes.length) {
                val node = wptNodes.item(i)
                val lat = node.attributes.getNamedItem("lat")?.nodeValue?.toDoubleOrNull() ?: continue
                val lon = node.attributes.getNamedItem("lon")?.nodeValue?.toDoubleOrNull() ?: continue
                var name = ""
                var desc = ""

                for (j in 0 until node.childNodes.length) {
                    val child = node.childNodes.item(j)
                    when (child.nodeName) {
                        "name" -> name = child.textContent ?: ""
                        "desc" -> desc = child.textContent ?: ""
                    }
                }
                waypoints.add(Waypoint(name.ifEmpty { "Waypoint ${i + 1}" }, lat, lon, desc))
            }

            // Parse <trkpt> elements from tracks
            val trkptNodes = doc.getElementsByTagName("trkpt")
            for (i in 0 until trkptNodes.length) {
                val node = trkptNodes.item(i)
                val lat = node.attributes.getNamedItem("lat")?.nodeValue?.toDoubleOrNull() ?: continue
                val lon = node.attributes.getNamedItem("lon")?.nodeValue?.toDoubleOrNull() ?: continue
                waypoints.add(Waypoint("Track Point ${i + 1}", lat, lon))
            }
        } catch (e: Exception) {
            // Return whatever was parsed so far
        }
        return waypoints
    }

    /**
     * Parse KML format placemarks.
     */
    private fun parseKml(content: String): List<Waypoint> {
        val waypoints = mutableListOf<Waypoint>()
        try {
            val factory = DocumentBuilderFactory.newInstance()
            factory.isNamespaceAware = false
            val builder = factory.newDocumentBuilder()
            val doc = builder.parse(content.byteInputStream())

            val placemarks = doc.getElementsByTagName("Placemark")
            for (i in 0 until placemarks.length) {
                val placemark = placemarks.item(i)
                var name = ""
                var desc = ""
                var lat = 0.0
                var lon = 0.0
                var hasCoords = false

                for (j in 0 until placemark.childNodes.length) {
                    val child = placemark.childNodes.item(j)
                    when (child.nodeName) {
                        "name" -> name = child.textContent ?: ""
                        "description" -> desc = child.textContent ?: ""
                        "Point" -> {
                            for (k in 0 until child.childNodes.length) {
                                if (child.childNodes.item(k).nodeName == "coordinates") {
                                    val coords = child.childNodes.item(k).textContent.trim().split(",")
                                    if (coords.size >= 2) {
                                        lon = coords[0].trim().toDoubleOrNull() ?: 0.0
                                        lat = coords[1].trim().toDoubleOrNull() ?: 0.0
                                        hasCoords = true
                                    }
                                }
                            }
                        }
                    }
                }

                if (hasCoords) {
                    waypoints.add(Waypoint(name.ifEmpty { "Place ${i + 1}" }, lat, lon, desc))
                }
            }
        } catch (e: Exception) {
            // Return whatever was parsed so far
        }
        return waypoints
    }

    /**
     * Export waypoints to GPX format.
     */
    fun exportToGpx(waypoints: List<Waypoint>, outputStream: OutputStream) {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        dateFormat.timeZone = TimeZone.getTimeZone("UTC")
        val timestamp = dateFormat.format(Date())

        val sb = StringBuilder()
        sb.appendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
        sb.appendLine("<gpx version=\"1.1\" creator=\"GPS Spoofer PRO\"")
        sb.appendLine("  xmlns=\"http://www.topografix.com/GPX/1/1\">")
        sb.appendLine("  <metadata>")
        sb.appendLine("    <name>GPS Spoofer PRO Export</name>")
        sb.appendLine("    <time>$timestamp</time>")
        sb.appendLine("  </metadata>")

        for (wp in waypoints) {
            sb.appendLine("  <wpt lat=\"${wp.lat}\" lon=\"${wp.lon}\">")
            sb.appendLine("    <name>${escapeXml(wp.name)}</name>")
            if (wp.description.isNotEmpty()) {
                sb.appendLine("    <desc>${escapeXml(wp.description)}</desc>")
            }
            sb.appendLine("  </wpt>")
        }

        sb.appendLine("</gpx>")
        outputStream.write(sb.toString().toByteArray(Charsets.UTF_8))
        outputStream.flush()
    }

    /**
     * Export waypoints to KML format.
     */
    fun exportToKml(waypoints: List<Waypoint>, outputStream: OutputStream) {
        val sb = StringBuilder()
        sb.appendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
        sb.appendLine("<kml xmlns=\"http://www.opengis.net/kml/2.2\">")
        sb.appendLine("  <Document>")
        sb.appendLine("    <name>GPS Spoofer PRO Export</name>")

        for (wp in waypoints) {
            sb.appendLine("    <Placemark>")
            sb.appendLine("      <name>${escapeXml(wp.name)}</name>")
            if (wp.description.isNotEmpty()) {
                sb.appendLine("      <description>${escapeXml(wp.description)}</description>")
            }
            sb.appendLine("      <Point>")
            sb.appendLine("        <coordinates>${wp.lon},${wp.lat},0</coordinates>")
            sb.appendLine("      </Point>")
            sb.appendLine("    </Placemark>")
        }

        sb.appendLine("  </Document>")
        sb.appendLine("</kml>")
        outputStream.write(sb.toString().toByteArray(Charsets.UTF_8))
        outputStream.flush()
    }

    private fun escapeXml(text: String): String {
        return text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }
}
