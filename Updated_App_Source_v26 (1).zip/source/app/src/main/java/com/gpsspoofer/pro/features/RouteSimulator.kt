package com.gpsspoofer.pro.features

import android.os.Handler
import android.os.Looper
import kotlin.math.*

/**
 * Route/Path simulation - simulates movement along a series of waypoints.
 * Supports configurable speed, loop mode, and pause/resume.
 */
class RouteSimulator(private val onLocationUpdate: (Double, Double) -> Unit) {

    private val handler = Handler(Looper.getMainLooper())
    private var waypoints = mutableListOf<Pair<Double, Double>>()
    private var currentWaypointIndex = 0
    private var isRunning = false
    private var isPaused = false
    private var speedMs = 1.4 // m/s (walking speed)
    private var loopEnabled = false
    private var currentLat = 0.0
    private var currentLon = 0.0
    private var onRouteComplete: (() -> Unit)? = null

    companion object {
        private const val UPDATE_INTERVAL_MS = 1000L
        private const val EARTH_RADIUS = 6378137.0
        private const val WAYPOINT_THRESHOLD_M = 5.0 // within 5m = reached
    }

    private val updateRunnable = object : Runnable {
        override fun run() {
            if (!isRunning || isPaused) return

            if (currentWaypointIndex >= waypoints.size) {
                if (loopEnabled && waypoints.isNotEmpty()) {
                    currentWaypointIndex = 0
                } else {
                    isRunning = false
                    onRouteComplete?.invoke()
                    return
                }
            }

            val target = waypoints[currentWaypointIndex]
            val distToTarget = haversineDistanceM(currentLat, currentLon, target.first, target.second)

            if (distToTarget <= WAYPOINT_THRESHOLD_M) {
                // Reached waypoint, move to next
                currentLat = target.first
                currentLon = target.second
                currentWaypointIndex++
                onLocationUpdate(currentLat, currentLon)
            } else {
                // Move toward waypoint
                val moveDist = speedMs * (UPDATE_INTERVAL_MS / 1000.0)
                val bearing = calculateBearing(currentLat, currentLon, target.first, target.second)
                val actualMove = minOf(moveDist, distToTarget)

                val latRad = Math.toRadians(currentLat)
                val bearingRad = Math.toRadians(bearing)
                val dLat = (actualMove * cos(bearingRad)) / EARTH_RADIUS * (180.0 / Math.PI)
                val dLon = (actualMove * sin(bearingRad)) / (EARTH_RADIUS * cos(latRad)) * (180.0 / Math.PI)

                currentLat += dLat
                currentLon += dLon
                onLocationUpdate(currentLat, currentLon)
            }

            handler.postDelayed(this, UPDATE_INTERVAL_MS)
        }
    }

    fun setWaypoints(points: List<Pair<Double, Double>>) {
        waypoints = points.toMutableList()
        currentWaypointIndex = 0
    }

    fun addWaypoint(lat: Double, lon: Double) {
        waypoints.add(Pair(lat, lon))
    }

    fun clearWaypoints() {
        waypoints.clear()
        currentWaypointIndex = 0
    }

    fun start(fromLat: Double, fromLon: Double, onComplete: (() -> Unit)? = null) {
        if (waypoints.isEmpty()) return
        currentLat = fromLat
        currentLon = fromLon
        currentWaypointIndex = 0
        isRunning = true
        isPaused = false
        onRouteComplete = onComplete
        handler.post(updateRunnable)
    }

    fun pause() {
        isPaused = true
    }

    fun resume() {
        if (isRunning && isPaused) {
            isPaused = false
            handler.post(updateRunnable)
        }
    }

    fun stop() {
        isRunning = false
        isPaused = false
        handler.removeCallbacks(updateRunnable)
    }

    fun setSpeed(speedMetersPerSecond: Double) {
        speedMs = speedMetersPerSecond.coerceIn(0.1, 100.0)
    }

    fun setLoopEnabled(enabled: Boolean) {
        loopEnabled = enabled
    }

    fun isActive() = isRunning
    fun isPausedState() = isPaused
    fun getWaypointCount() = waypoints.size
    fun getCurrentWaypointIndex() = currentWaypointIndex
    fun getProgress(): Float = if (waypoints.isEmpty()) 0f else currentWaypointIndex.toFloat() / waypoints.size

    private fun haversineDistanceM(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return EARTH_RADIUS * c
    }

    private fun calculateBearing(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val lat1Rad = Math.toRadians(lat1)
        val lat2Rad = Math.toRadians(lat2)
        val dLonRad = Math.toRadians(lon2 - lon1)
        val y = sin(dLonRad) * cos(lat2Rad)
        val x = cos(lat1Rad) * sin(lat2Rad) - sin(lat1Rad) * cos(lat2Rad) * cos(dLonRad)
        return (Math.toDegrees(atan2(y, x)) + 360) % 360
    }

    fun destroy() {
        stop()
        handler.removeCallbacksAndMessages(null)
    }
}
