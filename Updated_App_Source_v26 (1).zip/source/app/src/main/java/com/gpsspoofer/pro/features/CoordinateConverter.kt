package com.gpsspoofer.pro.features

import kotlin.math.*

/**
 * Converts between coordinate formats: Decimal Degrees, DMS, UTM, Plus Codes.
 */
object CoordinateConverter {

    enum class Format {
        DECIMAL,  // 40.748817, -73.985428
        DMS,      // 40°44'55.7"N 73°59'7.5"W
        UTM,      // 18T 583960 4511340
        PLUS_CODE // 87G8Q2JM+QV
    }

    data class DMS(
        val degrees: Int,
        val minutes: Int,
        val seconds: Double,
        val direction: Char
    ) {
        override fun toString(): String {
            return "$degrees°${minutes}'${String.format("%.1f", seconds)}\"$direction"
        }
    }

    data class UTM(
        val zone: Int,
        val letter: Char,
        val easting: Double,
        val northing: Double
    ) {
        override fun toString(): String {
            return "${zone}${letter} ${easting.toLong()} ${northing.toLong()}"
        }
    }

    // ===== Decimal to DMS =====

    fun decimalToDMS(lat: Double, lon: Double): String {
        val latDMS = toDMS(lat, if (lat >= 0) 'N' else 'S')
        val lonDMS = toDMS(lon, if (lon >= 0) 'E' else 'W')
        return "$latDMS $lonDMS"
    }

    private fun toDMS(decimal: Double, direction: Char): DMS {
        val abs = abs(decimal)
        val degrees = abs.toInt()
        val minFull = (abs - degrees) * 60
        val minutes = minFull.toInt()
        val seconds = (minFull - minutes) * 60
        return DMS(degrees, minutes, seconds, direction)
    }

    fun dmsToDecimal(dms: DMS): Double {
        val decimal = dms.degrees + dms.minutes / 60.0 + dms.seconds / 3600.0
        return if (dms.direction == 'S' || dms.direction == 'W') -decimal else decimal
    }

    // ===== Decimal to UTM =====

    fun decimalToUTM(lat: Double, lon: Double): UTM {
        val zone = ((lon + 180) / 6).toInt() + 1
        val letter = getUTMLetter(lat)

        val latRad = Math.toRadians(lat)
        val lonRad = Math.toRadians(lon)

        val a = 6378137.0 // WGS84 semi-major axis
        val f = 1 / 298.257223563
        val e = sqrt(2 * f - f * f)
        val e2 = e * e / (1 - e * e)

        val lonOrigin = (zone - 1) * 6.0 - 180 + 3
        val lonOriginRad = Math.toRadians(lonOrigin)

        val N = a / sqrt(1 - e * e * sin(latRad) * sin(latRad))
        val T = tan(latRad) * tan(latRad)
        val C = e2 * cos(latRad) * cos(latRad)
        val A = cos(latRad) * (lonRad - lonOriginRad)

        val M = a * ((1 - e * e / 4 - 3 * e.pow(4) / 64 - 5 * e.pow(6) / 256) * latRad
                - (3 * e * e / 8 + 3 * e.pow(4) / 32 + 45 * e.pow(6) / 1024) * sin(2 * latRad)
                + (15 * e.pow(4) / 256 + 45 * e.pow(6) / 1024) * sin(4 * latRad)
                - (35 * e.pow(6) / 3072) * sin(6 * latRad))

        val k0 = 0.9996

        val easting = k0 * N * (A + (1 - T + C) * A.pow(3) / 6 + (5 - 18 * T + T * T + 72 * C - 58 * e2) * A.pow(5) / 120) + 500000.0

        var northing = k0 * (M + N * tan(latRad) * (A * A / 2 + (5 - T + 9 * C + 4 * C * C) * A.pow(4) / 24 + (61 - 58 * T + T * T + 600 * C - 330 * e2) * A.pow(6) / 720))
        if (lat < 0) northing += 10000000.0

        return UTM(zone, letter, easting, northing)
    }

    private fun getUTMLetter(lat: Double): Char {
        return when {
            lat >= 72 -> 'X'
            lat >= 64 -> 'W'
            lat >= 56 -> 'V'
            lat >= 48 -> 'U'
            lat >= 40 -> 'T'
            lat >= 32 -> 'S'
            lat >= 24 -> 'R'
            lat >= 16 -> 'Q'
            lat >= 8 -> 'P'
            lat >= 0 -> 'N'
            lat >= -8 -> 'M'
            lat >= -16 -> 'L'
            lat >= -24 -> 'K'
            lat >= -32 -> 'J'
            lat >= -40 -> 'H'
            lat >= -48 -> 'G'
            lat >= -56 -> 'F'
            lat >= -64 -> 'E'
            lat >= -72 -> 'D'
            else -> 'C'
        }
    }

    // ===== Plus Codes (simplified Open Location Code) =====

    private const val CODE_ALPHABET = "23456789CFGHJMPQRVWX"

    fun decimalToPlusCode(lat: Double, lon: Double, codeLength: Int = 10): String {
        var adjLat = lat + 90.0
        var adjLon = lon + 180.0

        adjLat = adjLat.coerceIn(0.0, 180.0)
        adjLon = adjLon.coerceIn(0.0, 360.0)

        val code = StringBuilder()
        var latVal = adjLat
        var lonVal = adjLon
        var latPlaceVal = 20.0
        var lonPlaceVal = 20.0

        for (i in 0 until codeLength) {
            if (i < 10) {
                if (i % 2 == 0) {
                    // Latitude
                    latPlaceVal /= 20.0
                    val digit = (latVal / (latPlaceVal * 20)).toInt().coerceIn(0, 19)
                    latVal -= digit * latPlaceVal * 20
                    code.append(CODE_ALPHABET[digit])
                } else {
                    // Longitude
                    lonPlaceVal /= 20.0
                    val digit = (lonVal / (lonPlaceVal * 20)).toInt().coerceIn(0, 19)
                    lonVal -= digit * lonPlaceVal * 20
                    code.append(CODE_ALPHABET[digit])
                }
            }
            if (i == 7) code.append('+')
        }

        return code.toString()
    }

    /**
     * Format coordinates in the specified format.
     */
    fun format(lat: Double, lon: Double, format: Format): String {
        return when (format) {
            Format.DECIMAL -> "${String.format("%.6f", lat)}, ${String.format("%.6f", lon)}"
            Format.DMS -> decimalToDMS(lat, lon)
            Format.UTM -> decimalToUTM(lat, lon).toString()
            Format.PLUS_CODE -> decimalToPlusCode(lat, lon)
        }
    }

    /**
     * Try to parse coordinates from a string in any supported format.
     * Returns Pair(lat, lon) or null if parsing fails.
     */
    fun parse(input: String): Pair<Double, Double>? {
        // Try decimal format first: "40.7128, -74.0060"
        val decimalRegex = Regex("(-?\\d+\\.\\d+)[,\\s]+(-?\\d+\\.\\d+)")
        decimalRegex.find(input.trim())?.let {
            val lat = it.groupValues[1].toDoubleOrNull() ?: return null
            val lon = it.groupValues[2].toDoubleOrNull() ?: return null
            if (lat in -90.0..90.0 && lon in -180.0..180.0) return Pair(lat, lon)
        }

        // Try DMS format: 40°44'55.7"N 73°59'7.5"W
        val dmsRegex = Regex("(\\d+)°(\\d+)[''](\\d+\\.?\\d*)[\"\"](\\w)\\s+(\\d+)°(\\d+)[''](\\d+\\.?\\d*)[\"\"](\\w)")
        dmsRegex.find(input.trim())?.let {
            val g = it.groupValues
            val latDms = DMS(g[1].toInt(), g[2].toInt(), g[3].toDouble(), g[4][0])
            val lonDms = DMS(g[5].toInt(), g[6].toInt(), g[7].toDouble(), g[8][0])
            return Pair(dmsToDecimal(latDms), dmsToDecimal(lonDms))
        }

        return null
    }
}
