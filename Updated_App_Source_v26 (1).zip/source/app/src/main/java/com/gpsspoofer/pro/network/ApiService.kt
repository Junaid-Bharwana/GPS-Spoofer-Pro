package com.gpsspoofer.pro.network

import com.gpsspoofer.pro.BuildConfig
import okhttp3.CertificatePinner
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody
import okhttp3.logging.HttpLoggingInterceptor
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Centralized API service using OkHttp with SSL certificate pinning.
 * Replaces scattered HttpURLConnection usage throughout the app.
 */
object ApiService {

    private const val SIGNING_KEY = "gps_spoofer_pro_2024_signing_key"

    private val client: OkHttpClient by lazy {
        val builder = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .writeTimeout(10, TimeUnit.SECONDS)

        // SSL Certificate Pinning for the backend domain
        val certificatePinner = CertificatePinner.Builder()
            .add("app.hostverra.com", "sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=") // Replace with actual pin
            .add("app.hostverra.com", "sha256/BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=") // Backup pin
            .build()

        // Only enable pinning in release builds (debug needs flexibility)
        if (!BuildConfig.DEBUG) {
            // Note: Certificate pinning is configured but using placeholder pins.
            // To activate, replace the placeholder pins above with actual SHA-256 pins
            // from your server's certificate chain. You can get them by running:
            //   openssl s_client -connect app.hostverra.com:443 | openssl x509 -pubkey -noout | openssl pkey -pubin -outform der | openssl dgst -sha256 -binary | openssl enc -base64
            // builder.certificatePinner(certificatePinner)
        }

        // Add logging interceptor for debug builds
        if (BuildConfig.DEBUG) {
            val logging = HttpLoggingInterceptor()
            logging.level = HttpLoggingInterceptor.Level.BODY
            builder.addInterceptor(logging)
        }

        // Request signing interceptor
        builder.addInterceptor { chain ->
            val original = chain.request()
            val timestamp = (System.currentTimeMillis() / 1000).toString()
            val signature = generateSignature(original.url.toString(), timestamp)

            val newRequest = original.newBuilder()
                .addHeader("X-App-Version", BuildConfig.VERSION_NAME)
                .addHeader("X-Timestamp", timestamp)
                .addHeader("X-Signature", signature)
                .addHeader("X-Platform", "android")
                .build()

            chain.proceed(newRequest)
        }

        builder.build()
    }

    private fun generateSignature(url: String, timestamp: String): String {
        return try {
            val data = "$url|$timestamp|${BuildConfig.VERSION_NAME}"
            val mac = Mac.getInstance("HmacSHA256")
            val keySpec = SecretKeySpec(SIGNING_KEY.toByteArray(Charsets.UTF_8), "HmacSHA256")
            mac.init(keySpec)
            val hash = mac.doFinal(data.toByteArray(Charsets.UTF_8))
            hash.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            ""
        }
    }

    fun getBaseUrl(): String = BuildConfig.BASE_URL

    /**
     * Perform a POST request with form data.
     * Returns the JSON response or null on error.
     */
    fun post(endpoint: String, params: Map<String, String>): JSONObject? {
        return try {
            val formBuilder = FormBody.Builder()
            for ((key, value) in params) {
                formBuilder.add(key, value)
            }

            val request = Request.Builder()
                .url(getBaseUrl() + endpoint)
                .post(formBuilder.build())
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""
            if (body.isNotEmpty()) JSONObject(body) else null
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Perform a POST request with JSON body.
     */
    fun postJson(endpoint: String, json: JSONObject): JSONObject? {
        return try {
            val body = RequestBody.create(
                "application/json; charset=utf-8".toMediaType(),
                json.toString()
            )

            val request = Request.Builder()
                .url(getBaseUrl() + endpoint)
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""
            if (responseBody.isNotEmpty()) JSONObject(responseBody) else null
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Perform a GET request.
     */
    fun get(endpoint: String): JSONObject? {
        return try {
            val request = Request.Builder()
                .url(getBaseUrl() + endpoint)
                .get()
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""
            if (body.isNotEmpty()) JSONObject(body) else null
        } catch (e: Exception) {
            null
        }
    }
}
