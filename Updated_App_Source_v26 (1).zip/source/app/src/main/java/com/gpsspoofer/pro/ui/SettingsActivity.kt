package com.gpsspoofer.pro.ui


import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.text.method.DigitsKeyListener
import android.view.MenuItem
import android.widget.EditText
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.preference.EditTextPreference
import androidx.preference.PreferenceDataStore
import androidx.preference.PreferenceFragmentCompat
import com.gpsspoofer.pro.R
import com.gpsspoofer.pro.databinding.SettingsActivityBinding
import com.gpsspoofer.pro.utils.AccountStatusChecker
import com.gpsspoofer.pro.utils.PrefManager
import com.gpsspoofer.pro.update.AppUpdateManager
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.preference.SimpleMenuPreference


class SettingsActivity : AppCompatActivity() {

    private val binding by lazy {
        SettingsActivityBinding.inflate(layoutInflater)
    }

    private var heartbeatJob: Job? = null

    class SettingPreferenceDataStore() : PreferenceDataStore() {
        override fun getBoolean(key: String?, defValue: Boolean): Boolean {
            return when (key) {
                "isHookedSystem" -> PrefManager.isHookSystem
                "random_position" -> PrefManager.isRandomPosition
                "disable_update" -> PrefManager.disableUpdate
                "teleport_animation" -> PrefManager.teleportAnimation
                "enhanced_notifications" -> PrefManager.enhancedNotifications
                "save_login" -> PrefManager.saveLogin
                "enable_fingerprint" -> PrefManager.enableFingerprint
                else -> defValue
            }
        }

        override fun putBoolean(key: String?, value: Boolean) {
            return when (key) {
                "isHookedSystem" -> PrefManager.isHookSystem = value
                "random_position" -> PrefManager.isRandomPosition = value
                "disable_update" -> PrefManager.disableUpdate = value
                "teleport_animation" -> PrefManager.teleportAnimation = value
                "enhanced_notifications" -> PrefManager.enhancedNotifications = value
                "save_login" -> PrefManager.saveLogin = value
                "enable_fingerprint" -> PrefManager.enableFingerprint = value
                else -> { /* ignore unknown keys */ }
            }
        }

        override fun getString(key: String?, defValue: String?): String? {
            return when (key) {
                "accuracy_settings" -> PrefManager.accuracy
                "darkTheme" -> PrefManager.darkTheme.toString()
                "spoofing_mode" -> PrefManager.spoofingMode.toString()
                else -> defValue
            }
        }

        override fun putString(key: String?, value: String?) {
            return when (key) {
                "accuracy_settings" -> PrefManager.accuracy = value
                "darkTheme" -> PrefManager.darkTheme = value!!.toInt()
                "spoofing_mode" -> PrefManager.spoofingMode = value!!.toInt()
                else -> { /* ignore unknown keys */ }
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        if (savedInstanceState == null) {
            supportFragmentManager
                .beginTransaction()
                .replace(R.id.settings_container, SettingsPreferenceFragment())
                .commit()
        }
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    finish()
                }
            }
        )

    }

    override fun onResume() {
        super.onResume()
        startHeartbeatCheck()
        AppUpdateManager.checkForUpdate(this)
    }

    override fun onPause() {
        super.onPause()
        heartbeatJob?.cancel()
        AppUpdateManager.dismissDialog()
    }

    private fun startHeartbeatCheck() {
        heartbeatJob?.cancel()
        heartbeatJob = lifecycleScope.launch(Dispatchers.IO) {
            while (isActive) {
                val userId = PrefManager.getUserId()
                if (userId != -1) {
                    val status = AccountStatusChecker.checkAccountStatus(userId)
                    if (status is AccountStatusChecker.AccountStatus.Inactive) {
                        withContext(Dispatchers.Main) {
                            AccountStatusChecker.forceLogout(this@SettingsActivity, status.message)
                        }
                        return@launch
                    }
                    if (status is AccountStatusChecker.AccountStatus.Maintenance) {
                        withContext(Dispatchers.Main) {
                            AccountStatusChecker.showMaintenance(this@SettingsActivity, status.title, status.message)
                        }
                        return@launch
                    }
                }
                delay(10_000L)
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressedDispatcher.onBackPressed()
        }
        return super.onOptionsItemSelected(item)
    }


    class SettingsPreferenceFragment : PreferenceFragmentCompat() {

        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            preferenceManager?.preferenceDataStore = SettingPreferenceDataStore()
            setPreferencesFromResource(R.xml.setting, rootKey)

            findPreference<EditTextPreference>("accuracy_settings")?.let {
                it.summary = "${PrefManager.accuracy} m."
                it.setOnBindEditTextListener { editText ->
                    editText.inputType = InputType.TYPE_CLASS_NUMBER;
                    editText.keyListener = DigitsKeyListener.getInstance("0123456789.,");
                    editText.addTextChangedListener(getCommaReplacerTextWatcher(editText));
                }

                it.setOnPreferenceChangeListener { preference, newValue ->
                    try {
                        newValue as String?
                        preference.summary = "$newValue  m."
                    } catch (n: NumberFormatException) {
                        n.printStackTrace()
                        Toast.makeText(
                            requireContext(),
                            getString(R.string.enter_valid_input),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    true
                }
            }

            findPreference<SimpleMenuPreference>("darkTheme")?.setOnPreferenceChangeListener { _, newValue ->
                val newMode = (newValue as String).toInt()
                if (PrefManager.darkTheme != newMode) {
                    AppCompatDelegate.setDefaultNightMode(newMode)
                    activity?.recreate()
                }
                true
            }

            findPreference<SimpleMenuPreference>("spoofing_mode")?.setOnPreferenceChangeListener { _, newValue ->
                val mode = (newValue as String).toInt()
                if (mode == PrefManager.MODE_MOCK_LOCATION) {
                    // Show setup instructions dialog
                    MaterialAlertDialogBuilder(requireContext())
                        .setTitle(R.string.mock_location_setup_title)
                        .setMessage(R.string.mock_location_setup_message)
                        .setPositiveButton(R.string.dialog_button_ok, null)
                        .show()
                }
                true
            }

        }

        private fun getCommaReplacerTextWatcher(editText: EditText): TextWatcher {
            return object : TextWatcher {
                override fun beforeTextChanged(
                    charSequence: CharSequence,
                    i: Int,
                    i1: Int,
                    i2: Int
                ) {
                }

                override fun onTextChanged(
                    charSequence: CharSequence,
                    i: Int,
                    i1: Int,
                    i2: Int
                ) {
                }

                override fun afterTextChanged(editable: Editable) {
                    val text = editable.toString()
                    if (text.contains(",")) {
                        editText.setText(text.replace(",", "."))
                        editText.setSelection(editText.text.length)
                    }
                }
            }
        }

    }


}
