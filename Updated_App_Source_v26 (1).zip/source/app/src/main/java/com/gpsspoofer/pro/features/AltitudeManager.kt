package com.gpsspoofer.pro.features

import android.content.Context
import android.content.SharedPreferences

/**
 * Manages altitude spoofing alongside lat/lon.
 * Stores a custom altitude value that gets applied to spoofed locations.
 */
class AltitudeManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("altitude_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_ALTITUDE = "custom_altitude"
        private const val KEY_ALTITUDE_ENABLED = "altitude_enabled"
        const val DEFAULT_ALTITUDE = 0.0
    }

    var isEnabled: Boolean
        get() = prefs.getBoolean(KEY_ALTITUDE_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_ALTITUDE_ENABLED, value).apply()

    var altitude: Double
        get() = prefs.getFloat(KEY_ALTITUDE, DEFAULT_ALTITUDE.toFloat()).toDouble()
        set(value) = prefs.edit().putFloat(KEY_ALTITUDE, value.toFloat()).apply()

    /**
     * Returns the altitude to use for spoofing.
     * Returns custom altitude if enabled, otherwise returns the provided real altitude.
     */
    fun getEffectiveAltitude(realAltitude: Double = DEFAULT_ALTITUDE): Double {
        return if (isEnabled) altitude else realAltitude
    }

    fun reset() {
        prefs.edit().clear().apply()
    }
}
