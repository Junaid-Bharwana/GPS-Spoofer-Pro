package com.gpsspoofer.pro.features

import android.os.CountDownTimer

/**
 * Scheduled spoofing with timer support.
 * Allows users to set a duration for spoofing, auto-stopping when time expires.
 */
class ScheduledSpoofing {

    private var timer: CountDownTimer? = null
    private var remainingMs: Long = 0
    private var isRunning = false
    private var onTick: ((Long) -> Unit)? = null
    private var onFinish: (() -> Unit)? = null

    /**
     * Start a spoofing timer that will trigger onFinish when time expires.
     * @param durationMs duration in milliseconds
     * @param tickCallback called every second with remaining ms
     * @param finishCallback called when timer expires
     */
    fun startTimer(durationMs: Long, tickCallback: (Long) -> Unit, finishCallback: () -> Unit) {
        cancel()
        onTick = tickCallback
        onFinish = finishCallback
        remainingMs = durationMs
        isRunning = true

        timer = object : CountDownTimer(durationMs, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                remainingMs = millisUntilFinished
                tickCallback(millisUntilFinished)
            }

            override fun onFinish() {
                isRunning = false
                remainingMs = 0
                finishCallback()
            }
        }.start()
    }

    fun cancel() {
        timer?.cancel()
        timer = null
        isRunning = false
        remainingMs = 0
    }

    fun isTimerRunning() = isRunning

    fun getRemainingMs() = remainingMs

    /**
     * Format remaining time as HH:MM:SS string.
     */
    fun formatRemaining(): String {
        val totalSeconds = remainingMs / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format("%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%02d:%02d", minutes, seconds)
        }
    }

    companion object {
        // Timer presets in milliseconds
        val PRESET_15_MIN = 15 * 60 * 1000L
        val PRESET_30_MIN = 30 * 60 * 1000L
        val PRESET_1_HOUR = 60 * 60 * 1000L
        val PRESET_2_HOURS = 2 * 60 * 60 * 1000L
        val PRESET_4_HOURS = 4 * 60 * 60 * 1000L
        val PRESET_8_HOURS = 8 * 60 * 60 * 1000L
    }

    fun destroy() {
        cancel()
    }
}
