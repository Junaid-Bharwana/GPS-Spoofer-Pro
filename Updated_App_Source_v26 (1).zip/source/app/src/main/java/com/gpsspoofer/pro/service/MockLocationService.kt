package com.gpsspoofer.pro.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.location.provider.ProviderProperties
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import androidx.core.app.NotificationCompat
import com.gpsspoofer.pro.R
import com.gpsspoofer.pro.utils.PrefManager
import java.util.Timer
import java.util.TimerTask

class MockLocationService : Service() {

    companion object {
        private const val TAG = "MockLocationService"
        private const val NOTIFICATION_ID = 2001
        private const val CHANNEL_ID = "mock_location_channel"
        private const val UPDATE_INTERVAL = 1000L // 1 second

        private const val EXTRA_LATITUDE = "latitude"
        private const val EXTRA_LONGITUDE = "longitude"
        private const val EXTRA_ACCURACY = "accuracy"

        fun start(context: Context, lat: Double, lng: Double, accuracy: Float) {
            val intent = Intent(context, MockLocationService::class.java).apply {
                putExtra(EXTRA_LATITUDE, lat)
                putExtra(EXTRA_LONGITUDE, lng)
                putExtra(EXTRA_ACCURACY, accuracy)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, MockLocationService::class.java))
        }

        fun isProviderSetupCorrectly(context: Context): Boolean {
            return try {
                val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                locationManager.addTestProvider(
                    LocationManager.GPS_PROVIDER,
                    false, false, false, false, false,
                    true, true,
                    android.location.Criteria.POWER_LOW,
                    android.location.Criteria.ACCURACY_FINE
                )
                locationManager.removeTestProvider(LocationManager.GPS_PROVIDER)
                true
            } catch (e: SecurityException) {
                false
            } catch (e: IllegalArgumentException) {
                // Provider already exists as test provider - that's fine
                true
            } catch (e: Exception) {
                false
            }
        }
    }

    private var timer: Timer? = null
    private var latitude: Double = 0.0
    private var longitude: Double = 0.0
    private var accuracy: Float = 10f
    private var isRunning = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        latitude = intent.getDoubleExtra(EXTRA_LATITUDE, 0.0)
        longitude = intent.getDoubleExtra(EXTRA_LONGITUDE, 0.0)
        accuracy = intent.getFloatExtra(EXTRA_ACCURACY, 10f)

        startForeground(NOTIFICATION_ID, createNotification())

        if (!isRunning) {
            startMocking()
        } else {
            // Update coordinates if already running
            updateMockLocation()
        }

        return START_STICKY
    }

    private fun startMocking() {
        val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        try {
            // Remove existing test provider if any
            try {
                locationManager.removeTestProvider(LocationManager.GPS_PROVIDER)
            } catch (e: Exception) {
                // Ignore - provider might not exist as test provider
            }

            // Add GPS as test provider
            locationManager.addTestProvider(
                LocationManager.GPS_PROVIDER,
                false, // requiresNetwork
                false, // requiresSatellite
                false, // requiresCell
                false, // hasMonetaryCost
                false, // supportsAltitude
                true,  // supportsSpeed
                true,  // supportsBearing
                android.location.Criteria.POWER_LOW,
                android.location.Criteria.ACCURACY_FINE
            )
            locationManager.setTestProviderEnabled(LocationManager.GPS_PROVIDER, true)

            // Also add network provider
            try {
                try {
                    locationManager.removeTestProvider(LocationManager.NETWORK_PROVIDER)
                } catch (e: Exception) { }

                locationManager.addTestProvider(
                    LocationManager.NETWORK_PROVIDER,
                    false, false, false, false, false,
                    true, true,
                    android.location.Criteria.POWER_LOW,
                    android.location.Criteria.ACCURACY_FINE
                )
                locationManager.setTestProviderEnabled(LocationManager.NETWORK_PROVIDER, true)
            } catch (e: Exception) {
                Log.w(TAG, "Could not add network test provider: ${e.message}")
            }

            isRunning = true

            // Start periodic location updates
            timer = Timer()
            timer?.scheduleAtFixedRate(object : TimerTask() {
                override fun run() {
                    updateMockLocation()
                }
            }, 0, UPDATE_INTERVAL)

            Log.i(TAG, "Mock location started at $latitude, $longitude")

        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException: App is not set as mock location provider. ${e.message}")
            stopSelf()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start mock location: ${e.message}")
            stopSelf()
        }
    }

    private fun updateMockLocation() {
        val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        try {
            // Apply random position offset if enabled
            var mockLat = latitude
            var mockLng = longitude
            if (PrefManager.isRandomPosition) {
                val rand = java.util.Random()
                val earth = 6378137.0
                val pi = 3.14159265359
                val x = (rand.nextInt(50) - 25).toDouble()
                val y = (rand.nextInt(50) - 25).toDouble()
                val dlat = x / earth
                val dlng = y / (earth * kotlin.math.cos(pi * latitude / 180.0))
                mockLat = latitude + (dlat * 180.0 / pi)
                mockLng = longitude + (dlng * 180.0 / pi)
            }

            val gpsLocation = createMockLocation(LocationManager.GPS_PROVIDER, mockLat, mockLng)
            locationManager.setTestProviderLocation(LocationManager.GPS_PROVIDER, gpsLocation)

            // Also set network provider location
            try {
                val networkLocation = createMockLocation(LocationManager.NETWORK_PROVIDER, mockLat, mockLng)
                locationManager.setTestProviderLocation(LocationManager.NETWORK_PROVIDER, networkLocation)
            } catch (e: Exception) {
                // Network provider might not be set up
            }

        } catch (e: Exception) {
            Log.e(TAG, "Failed to update mock location: ${e.message}")
        }
    }

    private fun createMockLocation(provider: String, lat: Double, lng: Double): Location {
        val location = Location(provider)
        location.latitude = lat
        location.longitude = lng
        location.altitude = 0.0
        location.accuracy = accuracy
        location.speed = 0f
        location.bearing = 0f
        location.time = System.currentTimeMillis()
        location.elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()

        // Required for API 31+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            location.isMock = true
        }

        return location
    }

    private fun stopMocking() {
        timer?.cancel()
        timer = null

        val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        try {
            locationManager.setTestProviderEnabled(LocationManager.GPS_PROVIDER, false)
            locationManager.removeTestProvider(LocationManager.GPS_PROVIDER)
        } catch (e: Exception) {
            Log.w(TAG, "Error removing GPS test provider: ${e.message}")
        }

        try {
            locationManager.setTestProviderEnabled(LocationManager.NETWORK_PROVIDER, false)
            locationManager.removeTestProvider(LocationManager.NETWORK_PROVIDER)
        } catch (e: Exception) {
            Log.w(TAG, "Error removing network test provider: ${e.message}")
        }

        isRunning = false
        Log.i(TAG, "Mock location stopped")
    }

    override fun onDestroy() {
        stopMocking()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Mock Location Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows when mock location spoofing is active"
                setShowBadge(false)
            }
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("GPS Spoofer PRO")
            .setContentText("Mock location active at: $latitude, $longitude")
            .setSmallIcon(R.drawable.ic_play)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}
