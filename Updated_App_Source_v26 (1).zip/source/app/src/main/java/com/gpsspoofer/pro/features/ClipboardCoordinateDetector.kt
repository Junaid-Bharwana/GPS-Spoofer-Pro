package com.gpsspoofer.pro.features

import android.content.ClipboardManager
import android.content.Context

/**
 * Detects coordinates from the clipboard and offers to set them as the spoofed location.
 */
class ClipboardCoordinateDetector(private val context: Context) {

    /**
     * Check clipboard for coordinates. Returns Pair(lat, lon) or null.
     */
    fun detectFromClipboard(): Pair<Double, Double>? {
        return try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = clipboard.primaryClip ?: return null
            if (clip.itemCount == 0) return null

            val text = clip.getItemAt(0).text?.toString() ?: return null
            CoordinateConverter.parse(text)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Check if clipboard has valid coordinates.
     */
    fun hasCoordinates(): Boolean = detectFromClipboard() != null
}
