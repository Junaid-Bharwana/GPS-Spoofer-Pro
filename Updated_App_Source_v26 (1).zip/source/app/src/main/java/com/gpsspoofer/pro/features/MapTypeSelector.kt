package com.gpsspoofer.pro.features

/**
 * Map type selector for switching between different tile sources in the Leaflet WebView.
 * Supports Street, Satellite, Terrain, and Dark modes.
 */
object MapTypeSelector {

    enum class MapType(val displayName: String, val tileUrl: String, val attribution: String) {
        STREET(
            "Street",
            "https://mt1.google.com/vt/lyrs=m&hl=en&x={x}&y={y}&z={z}",
            "Google Maps"
        ),
        SATELLITE(
            "Satellite",
            "https://mt1.google.com/vt/lyrs=s&hl=en&x={x}&y={y}&z={z}",
            "Google Satellite"
        ),
        TERRAIN(
            "Terrain",
            "https://mt1.google.com/vt/lyrs=p&hl=en&x={x}&y={y}&z={z}",
            "Google Terrain"
        ),
        DARK(
            "Dark",
            "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
            "CartoDB Dark"
        );
    }

    fun getMapTypes(): Array<MapType> = MapType.values()

    fun getDisplayNames(): Array<String> = MapType.values().map { it.displayName }.toTypedArray()
}
