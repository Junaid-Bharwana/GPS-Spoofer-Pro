package com.gpsspoofer.pro.features

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * Location Profiles - save/load named location + settings combos.
 * e.g., "Work", "Home", "Gym" with lat/lon/accuracy/altitude.
 */
class LocationProfileManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("location_profiles", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_PROFILES = "saved_profiles"
    }

    data class Profile(
        val name: String,
        val lat: Double,
        val lon: Double,
        val altitude: Double = 0.0,
        val accuracy: Float = 10f,
        val timestamp: Long = System.currentTimeMillis()
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("name", name)
                put("lat", lat)
                put("lon", lon)
                put("altitude", altitude)
                put("accuracy", accuracy.toDouble())
                put("timestamp", timestamp)
            }
        }

        companion object {
            fun fromJson(json: JSONObject): Profile {
                return Profile(
                    name = json.optString("name", ""),
                    lat = json.optDouble("lat", 0.0),
                    lon = json.optDouble("lon", 0.0),
                    altitude = json.optDouble("altitude", 0.0),
                    accuracy = json.optDouble("accuracy", 10.0).toFloat(),
                    timestamp = json.optLong("timestamp", System.currentTimeMillis())
                )
            }
        }
    }

    /**
     * Get all saved profiles.
     */
    fun getProfiles(): List<Profile> {
        val json = prefs.getString(KEY_PROFILES, "[]") ?: "[]"
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { Profile.fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * Save a new profile or update existing one with the same name.
     */
    fun saveProfile(profile: Profile) {
        val profiles = getProfiles().toMutableList()
        // Remove existing with same name
        profiles.removeAll { it.name.equals(profile.name, ignoreCase = true) }
        profiles.add(0, profile)
        saveAll(profiles)
    }

    /**
     * Delete a profile by name.
     */
    fun deleteProfile(name: String) {
        val profiles = getProfiles().toMutableList()
        profiles.removeAll { it.name.equals(name, ignoreCase = true) }
        saveAll(profiles)
    }

    /**
     * Get a profile by name.
     */
    fun getProfile(name: String): Profile? {
        return getProfiles().find { it.name.equals(name, ignoreCase = true) }
    }

    private fun saveAll(profiles: List<Profile>) {
        val arr = JSONArray()
        profiles.forEach { arr.put(it.toJson()) }
        prefs.edit().putString(KEY_PROFILES, arr.toString()).apply()
    }

    fun clear() {
        prefs.edit().remove(KEY_PROFILES).apply()
    }
}
