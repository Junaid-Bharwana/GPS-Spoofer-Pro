package com.gpsspoofer.pro.utils.ext

import android.content.Context
import android.location.Geocoder
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow
import java.util.*

data class LatLng(val latitude: Double, val longitude: Double)

suspend fun LatLng.getAddress(context: Context) = callbackFlow {
    withContext(Dispatchers.IO){
        try {
            val addresses = Geocoder(context, Locale.getDefault()).getFromLocation(latitude, longitude, 1)
            val sb = StringBuilder()
            if (addresses != null && addresses.size > 0) {
                val address = addresses[0].getAddressLine(0)
                val strs = address.split(",".toRegex()).toTypedArray()
                if (strs.size > 1) {
                    sb.append(strs[0])
                    val index = address.indexOf(",") + 2
                    if (index > 1 && address.length > index) {
                        sb.append("\n").append(address.substring(index))
                    }
                } else {
                    sb.append(address)
                }
            }
            trySend(sb.toString())
        } catch (e: Exception) {
            trySend("${latitude}, ${longitude}")
        }
    }
    awaitClose { this.cancel() }
}
