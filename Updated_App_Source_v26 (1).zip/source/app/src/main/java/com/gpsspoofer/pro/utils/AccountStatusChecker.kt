package com.gpsspoofer.pro.utils

import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import com.gpsspoofer.pro.network.ApiService
import com.gpsspoofer.pro.ui.LoginActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

object AccountStatusChecker {

    private const val TAG = "AccountStatusChecker"
    private const val MAX_CONSECUTIVE_FAILURES = 3

    private var consecutiveFailures = 0

    fun resetFailureCounter() {
        consecutiveFailures = 0
    }

    /**
     * Checks account status with the server.
     * Returns Active if subscription is active.
     * Returns Inactive if subscription is not active or server explicitly says so.
     * On network errors, allows up to MAX_CONSECUTIVE_FAILURES before forcing logout
     * to avoid locking out users due to brief connectivity issues.
     */
    suspend fun checkAccountStatus(userId: Int): AccountStatus {
        return withContext(Dispatchers.IO) {
            try {
                val deviceToken = PrefManager.getDeviceToken()
                val jsonResponse = ApiService.post("heartbeat.php", mapOf(
                    "user_id" to userId.toString(),
                    "device_token" to deviceToken
                ))

                if (jsonResponse == null) {
                    Log.e(TAG, "Empty response from server")
                    consecutiveFailures++
                    return@withContext if (consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
                        AccountStatus.Inactive("Unable to verify account. Please log in again.")
                    } else {
                        AccountStatus.NetworkError
                    }
                }

                if (jsonResponse.getString("status") == "success") {
                    val maintenanceEnabled = jsonResponse.optBoolean("maintenance_enabled", false)
                    if (maintenanceEnabled) {
                        val maintenanceTitle = jsonResponse.optString("maintenance_title", "")
                        val maintenanceMessage = jsonResponse.optString("maintenance_message", "")
                        consecutiveFailures = 0
                        return@withContext AccountStatus.Maintenance(maintenanceTitle, maintenanceMessage)
                    }

                    val subscriptionStatus = jsonResponse.getString("subscription_status")
                    val expirationDate = jsonResponse.getString("expiration_date")
                    if (subscriptionStatus == "active") {
                        consecutiveFailures = 0
                        PrefManager.saveLoginData(userId, PrefManager.getUsername(), expirationDate)
                        AccountStatus.Active
                    } else {
                        consecutiveFailures = 0
                        AccountStatus.Inactive("Your subscription is $subscriptionStatus. Please renew.")
                    }
                } else {
                    val message = jsonResponse.optString("message", "Account verification failed")
                    val errorCode = jsonResponse.optString("error_code", "")
                    if (errorCode == "DEVICE_CONFLICT" ||
                        message.contains("logged in on another device", ignoreCase = true) ||
                        message.contains("User not found", ignoreCase = true) ||
                        message.contains("Account verification failed", ignoreCase = true)) {
                        consecutiveFailures = 0
                        AccountStatus.Inactive(message)
                    } else {
                        Log.e(TAG, "Server error: $message")
                        consecutiveFailures++
                        if (consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
                            AccountStatus.Inactive("Unable to verify account. Please log in again.")
                        } else {
                            AccountStatus.NetworkError
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Status check failed: ${e.message}")
                consecutiveFailures++
                if (consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
                    AccountStatus.Inactive("Unable to verify account. Please log in again.")
                } else {
                    AccountStatus.NetworkError
                }
            }
        }
    }

    /**
     * Force logout the user and redirect to LoginActivity.
     * Stops spoofing first, calls server to clear device token, then logs out and redirects.
     * Call this from any Activity when account is found to be inactive.
     */
    fun forceLogout(context: Context, message: String) {
        if (PrefManager.isStarted) {
            PrefManager.update(false, PrefManager.getLat, PrefManager.getLng)
        }
        PrefManager.logout()
        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
        val intent = Intent(context, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        context.startActivity(intent)
    }

    /**
     * Redirect user to LoginActivity with maintenance mode info.
     * Stops spoofing first, does NOT clear login data (user stays logged in for when maintenance ends).
     */
    fun showMaintenance(context: Context, title: String, message: String) {
        // Stop spoofing before redirecting
        if (PrefManager.isStarted) {
            PrefManager.update(false, PrefManager.getLat, PrefManager.getLng)
        }
        val intent = Intent(context, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        intent.putExtra("maintenance_mode", true)
        intent.putExtra("maintenance_title", title)
        intent.putExtra("maintenance_message", message)
        context.startActivity(intent)
    }

    /**
     * Call server to clear device token so account can login on another device.
     */
    fun serverLogout(userId: Int, deviceToken: String) {
        try {
            ApiService.post("logout.php", mapOf(
                "user_id" to userId.toString(),
                "device_token" to deviceToken
            ))
        } catch (e: Exception) {
            Log.e(TAG, "Server logout failed: ${e.message}")
        }
    }

    sealed class AccountStatus {
        object Active : AccountStatus()
        data class Inactive(val message: String) : AccountStatus()
        data class Maintenance(val title: String, val message: String) : AccountStatus()
        object NetworkError : AccountStatus()
    }
}
