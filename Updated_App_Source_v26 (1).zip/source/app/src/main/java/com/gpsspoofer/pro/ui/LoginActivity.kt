package com.gpsspoofer.pro.ui

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.gpsspoofer.pro.databinding.ActivityLoginBinding
import com.gpsspoofer.pro.features.BiometricLockManager
import com.gpsspoofer.pro.network.ApiService
import com.gpsspoofer.pro.utils.PrefManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import com.gpsspoofer.pro.utils.AccountStatusChecker

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private var contactSupportUrl: String = ""
    private lateinit var biometricLockManager: BiometricLockManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Load app settings (contact support URL + maintenance mode)
        fetchAppSettings()

        // Contact Support button (login screen)
        binding.contactSupportBtn.setOnClickListener {
            openSupportLink()
        }

        // Contact Support button (maintenance screen)
        binding.maintenanceContactBtn.setOnClickListener {
            openSupportLink()
        }

        // Check if redirected here due to maintenance mode from another activity
        if (intent.getBooleanExtra("maintenance_mode", false)) {
            val mTitle = intent.getStringExtra("maintenance_title") ?: ""
            val mMessage = intent.getStringExtra("maintenance_message") ?: ""
            showMaintenanceScreen(mTitle, mMessage)
            return
        }

        // Initialize biometric manager
        biometricLockManager = BiometricLockManager(this)

        // Check if user is already logged in
        if (PrefManager.isUserLoggedIn()) {
            // If fingerprint is enabled in settings, require biometric auth first
            if (PrefManager.enableFingerprint && biometricLockManager.isBiometricAvailable()) {
                showBiometricPrompt()
            } else {
                // Verify with server that account is still active
                verifyAccountAndNavigate()
            }
            return
        }

        binding.loginButton.setOnClickListener {
            val username = binding.usernameInput.text.toString().trim()
            val password = binding.passwordInput.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
            } else {
                performLogin(username, password)
            }
        }
    }

    private fun performLogin(username: String, password: String) {
        binding.loginButton.isEnabled = false
        binding.loginButton.text = "Logging in..."

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val deviceToken = PrefManager.getOrCreateDeviceToken()
                val jsonResponse = ApiService.post("login.php", mapOf(
                    "username" to username,
                    "password" to password,
                    "device_token" to deviceToken
                ))

                withContext(Dispatchers.Main) {
                    if (jsonResponse == null) {
                        Toast.makeText(this@LoginActivity, "Connection error. Please try again.", Toast.LENGTH_SHORT).show()
                        binding.loginButton.isEnabled = true
                        binding.loginButton.text = "Login"
                        return@withContext
                    }

                    // Update contact support URL from login response
                    val serverSupportUrl = jsonResponse.optString("contact_support_url", "")
                    if (serverSupportUrl.isNotEmpty()) {
                        contactSupportUrl = serverSupportUrl
                    }

                    if (jsonResponse.getString("status") == "success") {
                        val userId = jsonResponse.getInt("user_id")
                        val expirationDate = jsonResponse.getString("expiration_date")
                        val subscriptionStatus = jsonResponse.optString("subscription_status", "active")
                        val serverDeviceToken = jsonResponse.optString("device_token", deviceToken)

                        if (subscriptionStatus != "active") {
                            Toast.makeText(this@LoginActivity, "Account is $subscriptionStatus. Please contact support.", Toast.LENGTH_SHORT).show()
                            binding.loginButton.isEnabled = true
                            binding.loginButton.text = "Login"
                        } else {
                            PrefManager.saveLoginData(userId, username, expirationDate)
                            PrefManager.saveDeviceToken(serverDeviceToken)
                            AccountStatusChecker.resetFailureCounter()
                            Toast.makeText(this@LoginActivity, "Login successful", Toast.LENGTH_SHORT).show()
                            navigateToMainActivity()
                        }
                    } else {
                        val message = jsonResponse.getString("message")
                        Toast.makeText(this@LoginActivity, message, Toast.LENGTH_SHORT).show()
                        binding.loginButton.isEnabled = true
                        binding.loginButton.text = "Login"
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@LoginActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                    binding.loginButton.isEnabled = true
                    binding.loginButton.text = "Login"
                }
            }
        }
    }

    private fun verifyAccountAndNavigate() {
        val userId = PrefManager.getUserId()
        if (userId == -1) {
            return
        }

        binding.loginButton.isEnabled = false
        binding.loginButton.text = "Verifying..."

        lifecycleScope.launch(Dispatchers.IO) {
            val status = AccountStatusChecker.checkAccountStatus(userId)
            withContext(Dispatchers.Main) {
                when (status) {
                    is AccountStatusChecker.AccountStatus.Active -> {
                        navigateToMainActivity()
                    }
                    is AccountStatusChecker.AccountStatus.Inactive -> {
                        PrefManager.logout()
                        Toast.makeText(this@LoginActivity, status.message, Toast.LENGTH_LONG).show()
                        binding.loginButton.isEnabled = true
                        binding.loginButton.text = "Login"
                    }
                    is AccountStatusChecker.AccountStatus.Maintenance -> {
                        showMaintenanceScreen(status.title, status.message)
                    }
                    is AccountStatusChecker.AccountStatus.NetworkError -> {
                        // On network error, allow login with cached data
                        navigateToMainActivity()
                    }
                }
            }
        }
    }

    private fun openSupportLink() {
        if (contactSupportUrl.isNotEmpty()) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(contactSupportUrl))
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "Unable to open support link", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Support link not available", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showMaintenanceScreen(title: String, message: String) {
        binding.loginContainer.visibility = View.GONE
        binding.maintenanceOverlay.visibility = View.VISIBLE

        // Set custom title or default
        binding.maintenanceTitle.text = if (title.isNotEmpty()) title else "Under Maintenance"

        // Set custom message or default
        binding.maintenanceMessage.text = if (message.isNotEmpty()) message else
            "We're currently performing scheduled maintenance to improve your experience. Please check back shortly."

        // Rotate gear icon animation
        val rotateAnimator = ObjectAnimator.ofFloat(binding.maintenanceIcon, "rotation", 0f, 360f)
        rotateAnimator.duration = 8000
        rotateAnimator.repeatCount = ValueAnimator.INFINITE
        rotateAnimator.interpolator = LinearInterpolator()
        rotateAnimator.start()

        // Pulse glow animation
        val pulseAnimator = ObjectAnimator.ofFloat(binding.maintenanceGlow, "alpha", 0.3f, 1f)
        pulseAnimator.duration = 2000
        pulseAnimator.repeatCount = ValueAnimator.INFINITE
        pulseAnimator.repeatMode = ValueAnimator.REVERSE
        pulseAnimator.start()
    }

    private fun fetchAppSettings() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val jsonResponse = ApiService.get("get_app_settings.php")
                if (jsonResponse != null && jsonResponse.optString("status") == "success") {
                    val supportUrl = jsonResponse.optString("contact_support_url", "")
                    val maintenanceEnabled = jsonResponse.optBoolean("maintenance_enabled", false)
                    val maintenanceTitle = jsonResponse.optString("maintenance_title", "")
                    val maintenanceMessage = jsonResponse.optString("maintenance_message", "")

                    withContext(Dispatchers.Main) {
                        if (supportUrl.isNotEmpty()) {
                            contactSupportUrl = supportUrl
                        }
                        if (maintenanceEnabled) {
                            showMaintenanceScreen(maintenanceTitle, maintenanceMessage)
                        }
                    }
                }
            } catch (e: Exception) {
                // Silently fail - settings are optional
            }
        }
    }

    private fun showBiometricPrompt() {
        binding.loginButton.isEnabled = false
        binding.loginButton.text = "Authenticating..."

        biometricLockManager.authenticate(
            activity = this,
            onSuccess = {
                // Biometric auth passed, now verify account
                verifyAccountAndNavigate()
            },
            onFailure = { errorMsg ->
                // Auth failed or cancelled - show login form
                binding.loginButton.isEnabled = true
                binding.loginButton.text = "Login"
                Toast.makeText(this, "Biometric authentication failed: $errorMsg", Toast.LENGTH_SHORT).show()
            }
        )
    }

    private fun navigateToMainActivity() {
        val intent = Intent(this, MapActivity::class.java)
        startActivity(intent)
        finish()
    }
}
