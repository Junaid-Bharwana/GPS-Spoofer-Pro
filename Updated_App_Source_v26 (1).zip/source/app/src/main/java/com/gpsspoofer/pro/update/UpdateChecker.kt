package com.gpsspoofer.pro.update

import android.content.Context
import android.os.Parcelable
import com.gpsspoofer.pro.BuildConfig
import com.gpsspoofer.pro.network.ApiService
import com.gpsspoofer.pro.utils.PrefManager
import kotlinx.android.parcel.Parcelize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject


class UpdateChecker @Inject constructor(private val apiResponse : GitHubService) {


    fun getLatestRelease() = callbackFlow {
        withContext(Dispatchers.IO){
            // Use backend update check instead of GitHub
            val backendUpdate = checkBackendUpdate()
            if (backendUpdate != null) {
                this@callbackFlow.trySend(backendUpdate).isSuccess
            } else {
                this@callbackFlow.trySend(null).isSuccess
            }
        }
        awaitClose {  }
    }

    /**
     * Check the backend for available updates.
     * Calls update_check.php with current version code.
     */
    private fun checkBackendUpdate(): Update? {
        return try {
            val response = ApiService.get(
                "update_check.php?version_code=${BuildConfig.VERSION_CODE}&platform=android"
            )
            if (response != null && response.optBoolean("update_available", false)) {
                val versionName = response.optString("version_name", "")
                val changelog = response.optString("changelog", "")
                val downloadUrl = response.optString("download_url", "")
                val publishedAt = response.optString("published_at", "")
                val forceUpdate = response.optBoolean("force_update", false)
                val fileName = downloadUrl.substringAfterLast("/").ifEmpty { "app-release.apk" }

                Update(
                    name = "v$versionName",
                    changelog = changelog,
                    timestamp = publishedAt,
                    assetUrl = downloadUrl,
                    assetName = fileName,
                    releaseUrl = downloadUrl,
                    forceUpdate = forceUpdate
                )
            } else {
                null
            }
        } catch (e: Exception) {
            // Fallback: if backend fails, no update shown
            null
        }
    }

    fun clearCachedDownloads(context: Context){
        File(context.externalCacheDir, "updates").deleteRecursively()
    }


    @Parcelize
    data class Update(
        val name: String,
        val changelog: String,
        val timestamp: String,
        val assetUrl: String,
        val assetName: String,
        val releaseUrl: String,
        val forceUpdate: Boolean = false
    ) : Parcelable
}

