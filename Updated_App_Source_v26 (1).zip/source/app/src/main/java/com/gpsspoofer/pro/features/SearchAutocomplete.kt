package com.gpsspoofer.pro.features

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.URLEncoder
import java.net.HttpURLConnection
import java.net.URL

/**
 * Search autocomplete using Nominatim (OpenStreetMap) API.
 * Provides location suggestions as the user types.
 */
object SearchAutocomplete {

    data class Suggestion(
        val displayName: String,
        val lat: Double,
        val lon: Double
    )

    /**
     * Fetch location suggestions from Nominatim API.
     * @param query The search text
     * @param limit Maximum number of results (default 5)
     */
    suspend fun getSuggestions(query: String, limit: Int = 5): List<Suggestion> {
        if (query.length < 2) return emptyList()

        return withContext(Dispatchers.IO) {
            try {
                val encoded = URLEncoder.encode(query, "UTF-8")
                val urlStr = "https://nominatim.openstreetmap.org/search?format=json&q=$encoded&limit=$limit&addressdetails=0"
                val url = URL(urlStr)
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                conn.setRequestProperty("User-Agent", "GPSSpooferPRO/1.2.10")
                conn.connectTimeout = 5000
                conn.readTimeout = 5000

                if (conn.responseCode == 200) {
                    val response = conn.inputStream.bufferedReader().readText()
                    val jsonArray = JSONArray(response)
                    val suggestions = mutableListOf<Suggestion>()

                    for (i in 0 until jsonArray.length()) {
                        val obj = jsonArray.getJSONObject(i)
                        suggestions.add(
                            Suggestion(
                                displayName = obj.optString("display_name", ""),
                                lat = obj.optString("lat", "0").toDoubleOrNull() ?: 0.0,
                                lon = obj.optString("lon", "0").toDoubleOrNull() ?: 0.0
                            )
                        )
                    }
                    suggestions
                } else {
                    emptyList()
                }
            } catch (e: Exception) {
                emptyList()
            }
        }
    }
}
