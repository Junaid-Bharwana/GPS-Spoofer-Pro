package com.gpsspoofer.pro.features

import java.io.File

/**
 * Detects root access and Magisk on the device.
 * When root is detected, suggests using LSPosed mode for better spoofing.
 */
object RootDetector {

    data class RootStatus(
        val isRooted: Boolean,
        val hasMagisk: Boolean,
        val hasLSPosed: Boolean,
        val hasSu: Boolean,
        val details: String
    )

    /**
     * Perform a comprehensive root detection check.
     */
    fun detect(): RootStatus {
        val hasSu = checkSuBinary()
        val hasMagisk = checkMagisk()
        val hasLSPosed = checkLSPosed()
        val isRooted = hasSu || hasMagisk

        val details = buildString {
            if (hasSu) append("su binary found. ")
            if (hasMagisk) append("Magisk detected. ")
            if (hasLSPosed) append("LSPosed detected. ")
            if (!isRooted) append("No root detected.")
        }

        return RootStatus(isRooted, hasMagisk, hasLSPosed, hasSu, details.trim())
    }

    /**
     * Get a recommendation message based on the root status.
     */
    fun getRecommendation(status: RootStatus): String {
        return when {
            status.hasLSPosed -> "LSPosed detected! Use LSPosed mode for the best undetectable spoofing experience."
            status.hasMagisk && !status.hasLSPosed -> "Magisk detected but LSPosed not found. Install LSPosed (Zygisk) module in Magisk for the best experience.\n\nFor now, you can use Mock Location mode."
            status.isRooted && !status.hasMagisk -> "Root detected but Magisk not found. Install Magisk + LSPosed for the best experience.\n\nFor now, you can use Mock Location mode."
            else -> "No root detected. Using Mock Location mode.\n\nFor undetectable spoofing, consider rooting with Magisk + LSPosed."
        }
    }

    private fun checkSuBinary(): Boolean {
        val paths = arrayOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su",
            "/data/local/xbin/su", "/data/local/bin/su",
            "/system/sd/xbin/su", "/system/bin/failsafe/su",
            "/data/local/su", "/su/bin/su"
        )
        return paths.any { File(it).exists() }
    }

    private fun checkMagisk(): Boolean {
        val magiskPaths = arrayOf(
            "/sbin/.magisk", "/data/adb/magisk",
            "/data/adb/magisk.db", "/data/adb/modules"
        )
        if (magiskPaths.any { File(it).exists() }) return true

        // Check for Magisk Manager package
        return try {
            Runtime.getRuntime().exec("pm list packages com.topjohnwu.magisk")
                .inputStream.bufferedReader().readLine()?.contains("com.topjohnwu.magisk") == true
        } catch (e: Exception) {
            false
        }
    }

    private fun checkLSPosed(): Boolean {
        val lsposedPaths = arrayOf(
            "/data/adb/lspd", "/data/adb/modules/zygisk_lsposed",
            "/data/adb/modules/riru_lsposed"
        )
        if (lsposedPaths.any { File(it).exists() }) return true

        return try {
            Runtime.getRuntime().exec("pm list packages org.lsposed.manager")
                .inputStream.bufferedReader().readLine()?.contains("org.lsposed.manager") == true
        } catch (e: Exception) {
            false
        }
    }
}
