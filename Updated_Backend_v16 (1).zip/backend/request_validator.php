<?php
/**
 * Request Validator - Validates incoming API requests using HMAC signatures.
 * Ensures requests come from the official app and haven't been tampered with.
 */
class RequestValidator {
    
    private const SIGNING_KEY = 'gps_spoofer_pro_2024_signing_key';
    private const MAX_TIMESTAMP_DRIFT = 300; // 5 minutes max clock drift
    
    /**
     * Validate the request signature.
     * Returns true if valid, false otherwise.
     * Logs validation failures for monitoring.
     */
    public static function validate(): bool {
        $headers = self::getRequestHeaders();
        
        $appVersion = $headers['X-App-Version'] ?? '';
        $timestamp = $headers['X-Timestamp'] ?? '';
        $signature = $headers['X-Signature'] ?? '';
        $platform = $headers['X-Platform'] ?? '';
        
        // All signing headers must be present
        if (empty($appVersion) || empty($timestamp) || empty($signature) || empty($platform)) {
            // Allow requests without signing headers for backward compatibility
            // (older app versions won't have them)
            return true;
        }
        
        // Check timestamp is within acceptable range
        $currentTime = time();
        $requestTime = intval($timestamp);
        if (abs($currentTime - $requestTime) > self::MAX_TIMESTAMP_DRIFT) {
            error_log("Request validation failed: timestamp drift too large. Request: $requestTime, Server: $currentTime");
            return false;
        }
        
        // Reconstruct the URL the client would have signed
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? '';
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        $url = "$protocol://$host$uri";
        
        // Generate expected signature
        $data = "$url|$timestamp|$appVersion";
        $expectedSignature = hash_hmac('sha256', $data, self::SIGNING_KEY);
        
        if (!hash_equals($expectedSignature, $signature)) {
            error_log("Request validation failed: signature mismatch for $url");
            return false;
        }
        
        return true;
    }
    
    /**
     * Get all request headers in a normalized format.
     */
    private static function getRequestHeaders(): array {
        $headers = [];
        
        if (function_exists('getallheaders')) {
            foreach (getallheaders() as $name => $value) {
                $headers[$name] = $value;
            }
        } else {
            // Fallback for environments where getallheaders() isn't available
            foreach ($_SERVER as $key => $value) {
                if (substr($key, 0, 5) === 'HTTP_') {
                    $header = str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($key, 5)))));
                    $headers[$header] = $value;
                }
            }
        }
        
        return $headers;
    }
}
?>
