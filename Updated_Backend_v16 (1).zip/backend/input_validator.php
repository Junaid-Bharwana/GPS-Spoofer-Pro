<?php
/**
 * Input Validation Helper
 * Provides consistent input validation and sanitization for all API endpoints.
 */
class InputValidator {

    /**
     * Validate and sanitize a string input.
     * @param mixed $value The input value
     * @param int $maxLength Maximum allowed length
     * @param bool $required Whether the field is required
     * @return array ['valid' => bool, 'value' => string, 'error' => string|null]
     */
    public static function validateString($value, $maxLength = 255, $required = false) {
        if ($value === null || $value === '') {
            if ($required) {
                return ['valid' => false, 'value' => '', 'error' => 'This field is required.'];
            }
            return ['valid' => true, 'value' => '', 'error' => null];
        }

        $value = trim((string)$value);

        if (strlen($value) > $maxLength) {
            return ['valid' => false, 'value' => $value, 'error' => "Value exceeds maximum length of $maxLength characters."];
        }

        return ['valid' => true, 'value' => $value, 'error' => null];
    }

    /**
     * Validate an integer input.
     * @param mixed $value The input value
     * @param int $min Minimum allowed value
     * @param int $max Maximum allowed value
     * @param bool $required Whether the field is required
     * @return array ['valid' => bool, 'value' => int, 'error' => string|null]
     */
    public static function validateInt($value, $min = 0, $max = PHP_INT_MAX, $required = false) {
        if ($value === null || $value === '') {
            if ($required) {
                return ['valid' => false, 'value' => 0, 'error' => 'This field is required.'];
            }
            return ['valid' => true, 'value' => 0, 'error' => null];
        }

        if (!is_numeric($value)) {
            return ['valid' => false, 'value' => 0, 'error' => 'Must be a valid number.'];
        }

        $intVal = intval($value);
        if ($intVal < $min || $intVal > $max) {
            return ['valid' => false, 'value' => $intVal, 'error' => "Value must be between $min and $max."];
        }

        return ['valid' => true, 'value' => $intVal, 'error' => null];
    }

    /**
     * Validate an email address.
     * @param mixed $value The email input
     * @param bool $required Whether the field is required
     * @return array ['valid' => bool, 'value' => string, 'error' => string|null]
     */
    public static function validateEmail($value, $required = false) {
        if ($value === null || $value === '') {
            if ($required) {
                return ['valid' => false, 'value' => '', 'error' => 'Email is required.'];
            }
            return ['valid' => true, 'value' => '', 'error' => null];
        }

        $value = trim((string)$value);
        if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
            return ['valid' => false, 'value' => $value, 'error' => 'Invalid email address.'];
        }

        if (strlen($value) > 320) {
            return ['valid' => false, 'value' => $value, 'error' => 'Email address too long.'];
        }

        return ['valid' => true, 'value' => $value, 'error' => null];
    }

    /**
     * Validate a username (alphanumeric + underscores, 3-50 chars).
     * @param mixed $value The username input
     * @param bool $required Whether the field is required
     * @return array ['valid' => bool, 'value' => string, 'error' => string|null]
     */
    public static function validateUsername($value, $required = false) {
        if ($value === null || $value === '') {
            if ($required) {
                return ['valid' => false, 'value' => '', 'error' => 'Username is required.'];
            }
            return ['valid' => true, 'value' => '', 'error' => null];
        }

        $value = trim((string)$value);

        if (strlen($value) < 3) {
            return ['valid' => false, 'value' => $value, 'error' => 'Username must be at least 3 characters.'];
        }

        if (strlen($value) > 50) {
            return ['valid' => false, 'value' => $value, 'error' => 'Username must be 50 characters or less.'];
        }

        if (!preg_match('/^[a-zA-Z0-9_]+$/', $value)) {
            return ['valid' => false, 'value' => $value, 'error' => 'Username can only contain letters, numbers, and underscores.'];
        }

        return ['valid' => true, 'value' => $value, 'error' => null];
    }

    /**
     * Validate a password (minimum 6 chars).
     * @param mixed $value The password input
     * @param bool $required Whether the field is required
     * @return array ['valid' => bool, 'value' => string, 'error' => string|null]
     */
    public static function validatePassword($value, $required = false) {
        if ($value === null || $value === '') {
            if ($required) {
                return ['valid' => false, 'value' => '', 'error' => 'Password is required.'];
            }
            return ['valid' => true, 'value' => '', 'error' => null];
        }

        if (strlen($value) < 6) {
            return ['valid' => false, 'value' => $value, 'error' => 'Password must be at least 6 characters.'];
        }

        if (strlen($value) > 255) {
            return ['valid' => false, 'value' => $value, 'error' => 'Password too long.'];
        }

        return ['valid' => true, 'value' => $value, 'error' => null];
    }

    /**
     * Validate a device token (64 char hex for SHA-256, or 36 char UUID for legacy).
     * @param mixed $value The device token
     * @param bool $required Whether the field is required
     * @return array ['valid' => bool, 'value' => string, 'error' => string|null]
     */
    public static function validateDeviceToken($value, $required = false) {
        if ($value === null || $value === '') {
            if ($required) {
                return ['valid' => false, 'value' => '', 'error' => 'Device token is required.'];
            }
            return ['valid' => true, 'value' => '', 'error' => null];
        }

        $value = trim((string)$value);

        // Accept SHA-256 hex (64 chars) or legacy UUID (36 chars)
        if (strlen($value) > 64) {
            return ['valid' => false, 'value' => $value, 'error' => 'Invalid device token format.'];
        }

        // Only allow hex chars and dashes (for UUID)
        if (!preg_match('/^[a-fA-F0-9\-]+$/', $value)) {
            return ['valid' => false, 'value' => $value, 'error' => 'Invalid device token characters.'];
        }

        return ['valid' => true, 'value' => $value, 'error' => null];
    }

    /**
     * Validate a date string (YYYY-MM-DD format).
     * @param mixed $value The date input
     * @param bool $required Whether the field is required
     * @return array ['valid' => bool, 'value' => string, 'error' => string|null]
     */
    public static function validateDate($value, $required = false) {
        if ($value === null || $value === '') {
            if ($required) {
                return ['valid' => false, 'value' => '', 'error' => 'Date is required.'];
            }
            return ['valid' => true, 'value' => '', 'error' => null];
        }

        $value = trim((string)$value);

        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
            return ['valid' => false, 'value' => $value, 'error' => 'Date must be in YYYY-MM-DD format.'];
        }

        $parts = explode('-', $value);
        if (!checkdate((int)$parts[1], (int)$parts[2], (int)$parts[0])) {
            return ['valid' => false, 'value' => $value, 'error' => 'Invalid date.'];
        }

        return ['valid' => true, 'value' => $value, 'error' => null];
    }
}
?>
