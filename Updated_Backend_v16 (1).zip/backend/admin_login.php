<?php
session_start();
include 'db_connect.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $message = 'Username and password are required.';
    } else {
        $stmt = $conn->prepare("SELECT id, password FROM admins WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id, $hashed_password);
            $stmt->fetch();

            // Support both bcrypt and legacy SHA1 passwords
            $password_valid = false;
            if (password_verify($password, $hashed_password)) {
                $password_valid = true;
            } elseif (SHA1($password) === $hashed_password) {
                $password_valid = true;
                // Migrate legacy SHA1 hash to bcrypt
                $bcrypt_hash = password_hash($password, PASSWORD_BCRYPT);
                $migrateStmt = $conn->prepare("UPDATE admins SET password = ? WHERE id = ?");
                if ($migrateStmt) {
                    $migrateStmt->bind_param("si", $bcrypt_hash, $id);
                    $migrateStmt->execute();
                    $migrateStmt->close();
                }
            }

            if ($password_valid) {
                session_regenerate_id(true);
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_id'] = $id;
                $_SESSION['admin_username'] = $username;
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                header('Location: dashboard.php');
                exit();
            } else {
                $message = 'Invalid credentials.';
            }
        } else {
            $message = 'Invalid credentials.';
        }
        $stmt->close();
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - GS-SYS</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: radial-gradient(circle at center, #1b1b1b 0%, #0a0a0a 100%);
        }
        .login-card {
            width: 100%;
            max-width: 400px;
            padding: 2.5rem;
            border-top: 4px solid var(--primary-color);
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
        }
        .login-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        .login-header i {
            font-size: 3rem;
            color: var(--primary-color);
            text-shadow: 0 0 20px var(--primary-glow);
            margin-bottom: 1rem;
        }
        .login-header h2 {
            letter-spacing: 4px;
            text-transform: uppercase;
            font-size: 1.5rem;
        }
    </style>
</head>
<body>
    <div class="card login-card">
        <div class="login-header">
            <i class="fas fa-user-secret"></i>
            <h2>GS-SYSTEM</h2>
            <p style="color: var(--text-muted); font-size: 0.8rem; margin-top: 5px;">SECURE ACCESS PORTAL</p>
        </div>

        <?php if ($message): ?>
            <div style="background: rgba(255, 62, 62, 0.1); color: var(--error-color); padding: 10px; border-radius: 8px; border: 1px solid var(--error-color); margin-bottom: 1.5rem; text-align: center; font-size: 0.9rem;">
                <i class="fas fa-exclamation-circle"></i> <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form action="admin_login.php" method="post">
            <div class="form-group">
                <label><i class="fas fa-user"></i> USERNAME</label>
                <input type="text" name="username" placeholder="Digital Identity" required autofocus>
            </div>
            <div class="form-group">
                <label><i class="fas fa-key"></i> PASSWORD</label>
                <input type="password" name="password" placeholder="Access Cipher" required>
            </div>
            <div style="margin-top: 2rem;">
                <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center; padding: 15px;">
                    ESTABLISH CONNECTION <i class="fas fa-arrow-right"></i>
                </button>
            </div>
        </form>
        
        <div style="margin-top: 2rem; text-align: center; color: var(--text-muted); font-size: 0.7rem;">
            &copy; <?php echo date('Y'); ?> ANTIGRAVITY SECURITY. ALL RIGHTS RESERVED.
        </div>
    </div>
</body>
</html>
