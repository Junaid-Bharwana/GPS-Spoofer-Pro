<?php
// Ultra-Safe Admin Dashboard - Version 4
session_start();
error_reporting(0);
ini_set('display_errors', 0); // Hide errors from the user to prevent 500 crashes

// 1. Basic Database Connection
require_once 'db_connect.php';
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// 2. Auth Guard
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit();
}

// CSRF token generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

// CSRF validation helper
function verify_csrf($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

$page_title = 'Users Management';
$active_page = 'users';
$message = '';

// 3. Robust Feature Detection (Check if columns/tables exist)
$has_plan_id = false;
$check_col = $conn->query("SHOW COLUMNS FROM `users` LIKE 'plan_id'");
if ($check_col && $check_col->num_rows > 0) {
    $has_plan_id = true;
}

$has_plans_table = false;
$check_table = $conn->query("SHOW TABLES LIKE 'plans'");
if ($check_table && $check_table->num_rows > 0) {
    $has_plans_table = true;
}

$has_device_token = false;
$check_dt = $conn->query("SHOW COLUMNS FROM `users` LIKE 'device_token'");
if ($check_dt && $check_dt->num_rows > 0) {
    $has_device_token = true;
}

// 4. Handle POST Actions (Add/Edit/Reset Device/Delete)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // CSRF validation for all POST actions
    $submitted_token = $_POST['csrf_token'] ?? '';
    if (!verify_csrf($submitted_token)) {
        $message = 'Security error: Invalid CSRF token. Please try again.';
    } else {

    $action = $_POST['action'] ?? '';
    $user_id = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;

    // Bulk operations
    if ($action == 'bulk_action') {
        $bulk_ids = $_POST['bulk_ids'] ?? '';
        $bulk_operation = $_POST['bulk_operation'] ?? '';
        if (!empty($bulk_ids) && !empty($bulk_operation)) {
            $ids = array_map('intval', explode(',', $bulk_ids));
            $ids = array_filter($ids, function($id) { return $id > 0; });
            if (!empty($ids)) {
                $placeholders = implode(',', array_fill(0, count($ids), '?'));
                $types = str_repeat('i', count($ids));
                $count = 0;
                if ($bulk_operation === 'activate') {
                    $stmt = $conn->prepare("UPDATE users SET subscription_status = 'active' WHERE id IN ($placeholders)");
                    $stmt->bind_param($types, ...$ids);
                    $stmt->execute();
                    $count = $stmt->affected_rows;
                    $stmt->close();
                    $message = "$count users activated.";
                } elseif ($bulk_operation === 'deactivate') {
                    $stmt = $conn->prepare("UPDATE users SET subscription_status = 'inactive' WHERE id IN ($placeholders)");
                    $stmt->bind_param($types, ...$ids);
                    $stmt->execute();
                    $count = $stmt->affected_rows;
                    $stmt->close();
                    $message = "$count users deactivated.";
                } elseif ($bulk_operation === 'reset_devices') {
                    if ($has_device_token) {
                        $stmt = $conn->prepare("UPDATE users SET device_token = NULL WHERE id IN ($placeholders)");
                        $stmt->bind_param($types, ...$ids);
                        $stmt->execute();
                        $count = $stmt->affected_rows;
                        $stmt->close();
                    }
                    $message = "$count device tokens reset.";
                } elseif ($bulk_operation === 'delete') {
                    $stmt = $conn->prepare("DELETE FROM users WHERE id IN ($placeholders)");
                    $stmt->bind_param($types, ...$ids);
                    $stmt->execute();
                    $count = $stmt->affected_rows;
                    $stmt->close();
                    $message = "$count users deleted.";
                }
                $admin_user = $_SESSION['admin_username'] ?? 'unknown';
                @$conn->query("INSERT INTO audit_log (admin_user, action, target, details) VALUES ('" . $conn->real_escape_string($admin_user) . "', 'bulk_$bulk_operation', 'users', 'Bulk operation on " . count($ids) . " users')");
            }
        }
    } elseif ($action == 'delete' && $user_id > 0) {
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        if ($stmt->execute()) {
            // Audit log
            $admin_user = $_SESSION['admin_username'] ?? 'unknown';
            @$conn->query("INSERT INTO audit_log (admin_user, action, target, details) VALUES ('" . $conn->real_escape_string($admin_user) . "', 'delete_user', 'user_$user_id', 'Deleted user ID $user_id')");
            $message = 'User deleted successfully.';
        } else {
            $message = 'Error deleting user: ' . $conn->error;
        }
        $stmt->close();
    } elseif ($action == 'reset_device' && $user_id > 0 && $has_device_token) {
        $stmt = $conn->prepare("UPDATE users SET device_token = NULL WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        if ($stmt->execute()) {
            $admin_user = $_SESSION['admin_username'] ?? 'unknown';
            @$conn->query("INSERT INTO audit_log (admin_user, action, target, details) VALUES ('" . $conn->real_escape_string($admin_user) . "', 'reset_device', 'user_$user_id', 'Reset device token for user ID $user_id')");
            $message = "Device ID reset successfully. The user can now login from any device.";
        } else {
            $message = "Error resetting device: " . $conn->error;
        }
        $stmt->close();
    } else {
    $username = mysqli_real_escape_string($conn, $_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $email = mysqli_real_escape_string($conn, $_POST['email'] ?? '');
    $status = mysqli_real_escape_string($conn, $_POST['subscription_status'] ?? 'inactive');
    $exp_date = !empty($_POST['expiration_date']) ? mysqli_real_escape_string($conn, $_POST['expiration_date']) : null;
    $plan_id = (isset($_POST['plan_id']) && $has_plan_id) ? (int)$_POST['plan_id'] : null;

    if ($action == 'add' && !empty($username) && !empty($password)) {
        $hashed = password_hash($password, PASSWORD_BCRYPT);
        if ($has_plan_id) {
            $sql = "INSERT INTO users (username, password, email, subscription_status, expiration_date, plan_id) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssi", $username, $hashed, $email, $status, $exp_date, $plan_id);
        } else {
            $sql = "INSERT INTO users (username, password, email, subscription_status, expiration_date) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssss", $username, $hashed, $email, $status, $exp_date);
        }
        if ($stmt && $stmt->execute()) {
            $admin_user = $_SESSION['admin_username'] ?? 'unknown';
            @$conn->query("INSERT INTO audit_log (admin_user, action, target, details) VALUES ('" . $conn->real_escape_string($admin_user) . "', 'add_user', '" . $conn->real_escape_string($username) . "', 'Added new user')");
            $message = "User added successfully.";
        }
        else $message = "Error: " . $conn->error;
    } 
    elseif ($action == 'edit' && $user_id > 0) {
        if (!empty($password)) {
            $hashed = password_hash($password, PASSWORD_BCRYPT);
            if ($has_plan_id) {
                $sql = "UPDATE users SET username=?, password=?, email=?, subscription_status=?, expiration_date=?, plan_id=? WHERE id=?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("sssssii", $username, $hashed, $email, $status, $exp_date, $plan_id, $user_id);
            } else {
                $sql = "UPDATE users SET username=?, password=?, email=?, subscription_status=?, expiration_date=? WHERE id=?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("sssssi", $username, $hashed, $email, $status, $exp_date, $user_id);
            }
        } else {
            if ($has_plan_id) {
                $sql = "UPDATE users SET username=?, email=?, subscription_status=?, expiration_date=?, plan_id=? WHERE id=?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssii", $username, $email, $status, $exp_date, $plan_id, $user_id);
            } else {
                $sql = "UPDATE users SET username=?, email=?, subscription_status=?, expiration_date=? WHERE id=?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssi", $username, $email, $status, $exp_date, $user_id);
            }
        }
        if ($stmt && $stmt->execute()) {
            $admin_user = $_SESSION['admin_username'] ?? 'unknown';
            @$conn->query("INSERT INTO audit_log (admin_user, action, target, details) VALUES ('" . $conn->real_escape_string($admin_user) . "', 'edit_user', 'user_$user_id', 'Updated user ID $user_id')");
            $message = "User updated successfully.";
        }
        else $message = "Error: " . $conn->error;
    }
    } // end else (not reset_device/delete)

    } // end CSRF check
}

// Auto-expiry: mark expired accounts automatically
@$conn->query("UPDATE users SET subscription_status = 'expired' WHERE subscription_status = 'active' AND expiration_date IS NOT NULL AND expiration_date < CURDATE()");

// 5. Delete now handled via POST above (no more GET-based delete)

// Auto-create audit_log table if not exists
@$conn->query("CREATE TABLE IF NOT EXISTS `audit_log` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `admin_user` varchar(100) NOT NULL,
    `action` varchar(50) NOT NULL,
    `target` varchar(255) DEFAULT '',
    `details` text,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 6. Fetch Data with parameterized search (SQL injection fix)
$search = $_GET['search'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 20;
$offset = ($page - 1) * $per_page;

$users = [];
$select_cols = "u.*";
$join = "";
if ($has_plan_id && $has_plans_table) {
    $select_cols = "u.*, p.name as plan_name";
    $join = "LEFT JOIN plans p ON u.plan_id = p.id";
}

// Count total for pagination (use escaped string for broad hosting compatibility)
$search_escaped = $conn->real_escape_string($search);
$search_like = "%" . $search_escaped . "%";
$countRes = $conn->query("SELECT COUNT(*) as total FROM users u WHERE u.username LIKE '" . $search_like . "' OR u.email LIKE '" . $search_like . "'");
$total_users_count = $countRes ? $countRes->fetch_assoc()['total'] : 0;
$total_pages = max(1, ceil($total_users_count / $per_page));

// Data query with escaped search (compatible with all PHP/MySQL configs)
$per_page_int = (int)$per_page;
$offset_int = (int)$offset;
$res = $conn->query("SELECT $select_cols FROM users u $join WHERE u.username LIKE '" . $search_like . "' OR u.email LIKE '" . $search_like . "' ORDER BY u.id DESC LIMIT $per_page_int OFFSET $offset_int");
if ($res) {
    while ($row = $res->fetch_assoc()) $users[] = $row;
}

$plans = [];
if ($has_plans_table) {
    $pres = $conn->query("SELECT * FROM plans ORDER BY duration_months ASC");
    if ($pres) {
        while ($prow = $pres->fetch_assoc()) $plans[] = $prow;
    }
}

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<style>
.alert-box { padding:12px 16px; margin-bottom:20px; background:rgba(0,255,157,0.1); border-left:4px solid var(--primary-color); border-radius:8px; color:var(--text-color); font-size:0.9rem; }
.search-bar { margin-bottom:20px; padding:12px 16px; }
.search-form { display:flex; gap:10px; }
.search-form input { flex:1; min-width:0; }
.device-badge { display:inline-flex; align-items:center; gap:5px; padding:4px 10px; border-radius:20px; font-size:0.75rem; font-weight:600; white-space:nowrap; }
.device-linked { background:rgba(33,150,243,0.15); color:#42a5f5; }
.device-none { background:rgba(136,136,136,0.15); color:var(--text-muted); }
.action-buttons { white-space:nowrap; }
.action-buttons .btn { margin:2px; }
.btn-sm { padding:6px 10px; font-size:0.8rem; border-radius:6px; }
.btn-edit { background:rgba(33,150,243,0.15); color:#42a5f5; border:none; cursor:pointer; }
.btn-edit:hover { background:rgba(33,150,243,0.3); }
.btn-reset { background:rgba(255,152,0,0.15); color:#ffa726; border:none; cursor:pointer; }
.btn-reset:hover { background:rgba(255,152,0,0.3); }
.btn-danger { text-decoration:none; }
.btn-cancel { background:var(--hover-bg); color:var(--text-color); }
.modal-overlay { display:none; position:fixed; z-index:9999; left:0; top:0; width:100%; height:100%; background:rgba(0,0,0,0.6); overflow-y:auto; -webkit-overflow-scrolling:touch; }
.modal-overlay.active { display:flex; align-items:flex-start; justify-content:center; padding:20px; }
.modal-content { width:100%; max-width:500px; margin:20px auto; padding:24px; border-radius:12px; }
.modal-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; }
.modal-header h3 { color:var(--primary-color); font-size:1.2rem; }
.modal-close { background:none; border:none; color:var(--text-muted); font-size:1.5rem; cursor:pointer; padding:0 5px; }
.form-hint { color:var(--text-muted); font-size:0.8rem; margin-top:4px; }
.form-row { display:grid; grid-template-columns:1fr 1fr; gap:15px; }
.form-actions { display:flex; gap:10px; margin-top:20px; }
.form-actions .btn { flex:1; justify-content:center; }
.desktop-only { display:block; }
.mobile-only { display:none; }
.user-card { margin-bottom:12px; padding:16px; }
.user-card-header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:12px; }
.user-card-info { display:flex; flex-direction:column; gap:2px; min-width:0; }
.user-card-info strong { font-size:1rem; word-break:break-word; }
.user-card-info small { color:var(--text-muted); font-size:0.8rem; word-break:break-all; }
.user-card-details { border-top:1px solid var(--border-color); padding-top:10px; margin-bottom:12px; }
.user-card-row { display:flex; justify-content:space-between; align-items:center; padding:6px 0; }
.user-card-label { color:var(--text-muted); font-size:0.85rem; }
.user-card-actions { display:flex; gap:8px; flex-wrap:wrap; border-top:1px solid var(--border-color); padding-top:12px; }
.user-card-actions .btn { flex:1; min-width:0; justify-content:center; text-align:center; font-size:0.8rem; white-space:nowrap; }
@media (max-width:768px) {
    .desktop-only { display:none !important; }
    .mobile-only { display:block !important; }
    .form-row { grid-template-columns:1fr; gap:0; }
    .modal-content { margin:10px; padding:16px; }
    .search-form { flex-direction:column; }
    .search-form .btn { width:100%; justify-content:center; }
}
</style>

<div class="container">
    <?php if (isset($_GET['msg']) || $message): ?>
        <div class="alert-box"><?php echo htmlspecialchars($_GET['msg'] ?? $message); ?></div>
    <?php endif; ?>

    <!-- Analytics Summary -->
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(150px, 1fr)); gap:12px; margin-bottom:20px;">
        <?php
        $totalRes = @$conn->query("SELECT COUNT(*) as c FROM users");
        $totalCount = $totalRes ? $totalRes->fetch_assoc()['c'] : 0;
        $activeRes = @$conn->query("SELECT COUNT(*) as c FROM users WHERE subscription_status='active'");
        $activeCount = $activeRes ? $activeRes->fetch_assoc()['c'] : 0;
        $expiredRes = @$conn->query("SELECT COUNT(*) as c FROM users WHERE subscription_status='expired'");
        $expiredCount = $expiredRes ? $expiredRes->fetch_assoc()['c'] : 0;
        $inactiveRes = @$conn->query("SELECT COUNT(*) as c FROM users WHERE subscription_status='inactive'");
        $inactiveCount = $inactiveRes ? $inactiveRes->fetch_assoc()['c'] : 0;
        $deviceLinkedRes = $has_device_token ? @$conn->query("SELECT COUNT(*) as c FROM users WHERE device_token IS NOT NULL AND device_token != ''") : null;
        $deviceLinkedCount = $deviceLinkedRes ? $deviceLinkedRes->fetch_assoc()['c'] : 0;
        ?>
        <div class="card" style="padding:16px; text-align:center;">
            <div style="font-size:1.8rem; font-weight:bold; color:var(--primary-color);"><?php echo $totalCount; ?></div>
            <div style="color:var(--text-muted); font-size:0.85rem;">Total Users</div>
        </div>
        <div class="card" style="padding:16px; text-align:center;">
            <div style="font-size:1.8rem; font-weight:bold; color:#4caf50;"><?php echo $activeCount; ?></div>
            <div style="color:var(--text-muted); font-size:0.85rem;">Active</div>
        </div>
        <div class="card" style="padding:16px; text-align:center;">
            <div style="font-size:1.8rem; font-weight:bold; color:#ff9800;"><?php echo $expiredCount; ?></div>
            <div style="color:var(--text-muted); font-size:0.85rem;">Expired</div>
        </div>
        <div class="card" style="padding:16px; text-align:center;">
            <div style="font-size:1.8rem; font-weight:bold; color:#f44336;"><?php echo $inactiveCount; ?></div>
            <div style="color:var(--text-muted); font-size:0.85rem;">Inactive</div>
        </div>
        <?php if ($has_device_token): ?>
        <div class="card" style="padding:16px; text-align:center;">
            <div style="font-size:1.8rem; font-weight:bold; color:#2196f3;"><?php echo $deviceLinkedCount; ?></div>
            <div style="color:var(--text-muted); font-size:0.85rem;">Devices Linked</div>
        </div>
        <?php endif; ?>
    </div>

    <div class="search-bar card">
        <form method="GET" class="search-form">
            <input type="text" name="search" placeholder="Search users..." value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit" class="btn btn-primary">Search</button>
        </form>
    </div>

    <!-- Bulk Operations Bar -->
    <div id="bulkBar" class="card" style="display:none; padding:12px 16px; margin-bottom:16px; background:rgba(33,150,243,0.1); border-left:4px solid #2196f3;">
        <form id="bulkForm" method="POST" style="display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
            <input type="hidden" name="action" value="bulk_action">
            <input type="hidden" name="bulk_ids" id="bulk_ids_input">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
            <span id="bulkCount" style="font-size:0.9rem; color:var(--text-color);">0 selected</span>
            <select name="bulk_operation" style="padding:6px 10px; border-radius:6px; font-size:0.85rem;">
                <option value="activate">Activate</option>
                <option value="deactivate">Deactivate</option>
                <?php if ($has_device_token): ?><option value="reset_devices">Reset Devices</option><?php endif; ?>
                <option value="delete">Delete</option>
            </select>
            <button type="submit" class="btn btn-sm btn-primary" onclick="return confirm('Apply bulk action to selected users?')">Apply</button>
            <button type="button" class="btn btn-sm btn-cancel" onclick="clearBulkSelection()">Clear</button>
        </form>
    </div>

    <!-- Desktop Table -->
    <div class="table-container card desktop-only" style="overflow-x:auto;">
        <table>
            <thead>
                <tr>
                    <th style="width:30px;"><input type="checkbox" id="selectAll" onchange="toggleSelectAll(this)"></th>
                    <th>User</th>
                    <?php if ($has_device_token): ?><th>Device</th><?php endif; ?>
                    <th>Plan</th>
                    <th>Status</th>
                    <th>Expiration</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($users)): ?>
                    <tr><td colspan="<?php echo $has_device_token ? 7 : 6; ?>" style="text-align:center;padding:2rem;">No users found</td></tr>
                <?php else: ?>
                    <?php foreach ($users as $u): ?>
                    <tr>
                        <td><input type="checkbox" class="bulk-check" value="<?php echo $u['id']; ?>" onchange="updateBulkBar()"></td>
                        <td>
                            <strong><?php echo htmlspecialchars($u['username']); ?></strong><br>
                            <small style="color:var(--text-muted);"><?php echo htmlspecialchars($u['email'] ?: 'No email'); ?></small>
                        </td>
                        <?php if ($has_device_token): ?>
                        <td>
                            <?php if (!empty($u['device_token'])): ?>
                                <span class="device-badge device-linked"><i class="fas fa-mobile-alt"></i> Linked</span>
                            <?php else: ?>
                                <span class="device-badge device-none"><i class="fas fa-mobile-alt"></i> None</span>
                            <?php endif; ?>
                        </td>
                        <?php endif; ?>
                        <td><?php echo htmlspecialchars($u['plan_name'] ?? 'None'); ?></td>
                        <td><span class="status-pill status-<?php echo $u['subscription_status']; ?>"><?php echo ucfirst($u['subscription_status']); ?></span></td>
                        <td><?php echo $u['expiration_date'] ?: 'Never'; ?></td>
                        <td class="action-buttons">
                            <button class="btn btn-sm btn-edit" onclick="editUser(<?php echo htmlspecialchars(json_encode($u)); ?>)" title="Edit"><i class="fas fa-edit"></i></button>
                            <?php if ($has_device_token && !empty($u['device_token'])): ?>
                                <button class="btn btn-sm btn-reset" onclick="resetDevice(<?php echo $u['id']; ?>, '<?php echo htmlspecialchars($u['username']); ?>')" title="Reset Device ID"><i class="fas fa-undo"></i></button>
                            <?php endif; ?>
                            <button class="btn btn-sm btn-danger" onclick="deleteUser(<?php echo $u['id']; ?>, '<?php echo htmlspecialchars($u['username'], ENT_QUOTES); ?>')" title="Delete"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Mobile Cards -->
    <div class="mobile-only">
        <?php if (empty($users)): ?>
            <div class="card" style="text-align:center;padding:2rem;">No users found</div>
        <?php else: ?>
            <?php foreach ($users as $u): ?>
            <div class="user-card card">
                <div class="user-card-header">
                    <div class="user-card-info">
                        <strong><?php echo htmlspecialchars($u['username']); ?></strong>
                        <small><?php echo htmlspecialchars($u['email'] ?: 'No email'); ?></small>
                    </div>
                    <span class="status-pill status-<?php echo $u['subscription_status']; ?>"><?php echo ucfirst($u['subscription_status']); ?></span>
                </div>
                <div class="user-card-details">
                    <div class="user-card-row">
                        <span class="user-card-label">Plan</span>
                        <span><?php echo htmlspecialchars($u['plan_name'] ?? 'None'); ?></span>
                    </div>
                    <div class="user-card-row">
                        <span class="user-card-label">Expires</span>
                        <span><?php echo $u['expiration_date'] ?: 'Never'; ?></span>
                    </div>
                    <?php if ($has_device_token): ?>
                    <div class="user-card-row">
                        <span class="user-card-label">Device</span>
                        <?php if (!empty($u['device_token'])): ?>
                            <span class="device-badge device-linked"><i class="fas fa-mobile-alt"></i> Linked</span>
                        <?php else: ?>
                            <span class="device-badge device-none"><i class="fas fa-mobile-alt"></i> None</span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="user-card-actions">
                    <button class="btn btn-sm btn-edit" onclick="editUser(<?php echo htmlspecialchars(json_encode($u)); ?>)"><i class="fas fa-edit"></i> Edit</button>
                    <?php if ($has_device_token && !empty($u['device_token'])): ?>
                        <button class="btn btn-sm btn-reset" onclick="resetDevice(<?php echo $u['id']; ?>, '<?php echo htmlspecialchars($u['username']); ?>')"><i class="fas fa-undo"></i> Reset Device</button>
                    <?php endif; ?>
                    <button class="btn btn-sm btn-danger" onclick="deleteUser(<?php echo $u['id']; ?>, '<?php echo htmlspecialchars($u['username'], ENT_QUOTES); ?>')"><i class="fas fa-trash"></i> Del</button>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<button class="fab" onclick="showAddModal()"><i class="fas fa-plus"></i></button>

<!-- Pagination -->
<?php if ($total_pages > 1): ?>
<div class="card" style="margin-top:20px; padding:16px; display:flex; justify-content:center; align-items:center; gap:8px; flex-wrap:wrap;">
    <?php if ($page > 1): ?>
        <a href="?page=<?php echo $page-1; ?>&search=<?php echo urlencode($search); ?>" class="btn btn-sm btn-edit"><i class="fas fa-chevron-left"></i> Prev</a>
    <?php endif; ?>
    <span style="color:var(--text-muted); font-size:0.85rem;">Page <?php echo $page; ?> of <?php echo $total_pages; ?> (<?php echo $total_users_count; ?> users)</span>
    <?php if ($page < $total_pages): ?>
        <a href="?page=<?php echo $page+1; ?>&search=<?php echo urlencode($search); ?>" class="btn btn-sm btn-edit">Next <i class="fas fa-chevron-right"></i></a>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- Reset Device Form -->
<form id="resetDeviceForm" method="POST" style="display:none;">
    <input type="hidden" name="action" value="reset_device">
    <input type="hidden" name="user_id" id="reset_user_id">
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
</form>

<!-- Delete User Form -->
<form id="deleteUserForm" method="POST" style="display:none;">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="user_id" id="delete_user_id">
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
</form>

<!-- User Modal -->
<div id="userModal" class="modal-overlay">
    <div class="modal-content card">
        <div class="modal-header">
            <h3 id="modalTitle">Add User</h3>
            <button type="button" class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" id="form_action" value="add">
            <input type="hidden" name="user_id" id="form_user_id">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" id="form_username" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" id="form_password">
                <small id="passHint" class="form-hint" style="display:none;">Leave blank to keep current</small>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" id="form_email">
            </div>
            <?php if ($has_plans_table): ?>
            <div class="form-group">
                <label>Select Plan</label>
                <select name="plan_id" id="form_plan_id" onchange="autoFillDate()">
                    <option value="">-- Manual Selection --</option>
                    <?php foreach($plans as $p): ?>
                        <option value="<?php echo $p['id']; ?>" data-months="<?php echo $p['duration_months']; ?>"><?php echo htmlspecialchars($p['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
            <div class="form-row">
                <div class="form-group">
                    <label>Status</label>
                    <select name="subscription_status" id="form_status">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                        <option value="expired">Expired</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Expiration Date</label>
                    <input type="date" name="expiration_date" id="form_expiration">
                </div>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Save</button>
                <button type="button" class="btn btn-cancel" onclick="closeModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
function showAddModal() {
    document.getElementById('modalTitle').innerText = 'Add User';
    document.getElementById('form_action').value = 'add';
    document.getElementById('form_user_id').value = '';
    document.getElementById('form_username').value = '';
    document.getElementById('form_password').value = '';
    document.getElementById('form_email').value = '';
    document.getElementById('form_status').value = 'active';
    document.getElementById('form_expiration').value = '';
    document.getElementById('form_password').required = true;
    document.getElementById('passHint').style.display = 'none';
    if (document.getElementById('form_plan_id')) document.getElementById('form_plan_id').value = '';
    document.getElementById('userModal').classList.add('active');
}

function editUser(u) {
    document.getElementById('modalTitle').innerText = 'Edit User';
    document.getElementById('form_action').value = 'edit';
    document.getElementById('form_user_id').value = u.id;
    document.getElementById('form_username').value = u.username;
    document.getElementById('form_email').value = u.email || '';
    document.getElementById('form_status').value = u.subscription_status;
    document.getElementById('form_expiration').value = u.expiration_date || '';
    if (document.getElementById('form_plan_id')) document.getElementById('form_plan_id').value = u.plan_id || '';
    document.getElementById('form_password').value = '';
    document.getElementById('form_password').required = false;
    document.getElementById('passHint').style.display = 'block';
    document.getElementById('userModal').classList.add('active');
}

function resetDevice(userId, username) {
    if (confirm('Reset device ID for "' + username + '"?\n\nThis will allow the user to login from any new device.')) {
        document.getElementById('reset_user_id').value = userId;
        document.getElementById('resetDeviceForm').submit();
    }
}

function deleteUser(userId, username) {
    if (confirm('Delete user "' + username + '"?\n\nThis action cannot be undone.')) {
        document.getElementById('delete_user_id').value = userId;
        document.getElementById('deleteUserForm').submit();
    }
}

function autoFillDate() {
    var select = document.getElementById('form_plan_id');
    if (!select) return;
    var months = select.options[select.selectedIndex].getAttribute('data-months');
    if (!months) return;
    var d = new Date();
    d.setMonth(d.getMonth() + parseInt(months));
    document.getElementById('form_expiration').value = d.toISOString().split('T')[0];
    document.getElementById('form_status').value = 'active';
}

function closeModal() {
    document.getElementById('userModal').classList.remove('active');
}

// Bulk selection
var selectedIds = new Set();
function toggleSelectAll(cb) {
    document.querySelectorAll('.bulk-check').forEach(function(c) {
        c.checked = cb.checked;
        if (cb.checked) selectedIds.add(c.value);
        else selectedIds.delete(c.value);
    });
    updateBulkBar();
}
function updateBulkBar() {
    selectedIds = new Set();
    document.querySelectorAll('.bulk-check:checked').forEach(function(c) { selectedIds.add(c.value); });
    var bar = document.getElementById('bulkBar');
    var count = document.getElementById('bulkCount');
    if (selectedIds.size > 0) {
        bar.style.display = 'block';
        count.textContent = selectedIds.size + ' selected';
        document.getElementById('bulk_ids_input').value = Array.from(selectedIds).join(',');
    } else {
        bar.style.display = 'none';
    }
}
function clearBulkSelection() {
    document.querySelectorAll('.bulk-check').forEach(function(c) { c.checked = false; });
    var sa = document.getElementById('selectAll');
    if (sa) sa.checked = false;
    selectedIds = new Set();
    updateBulkBar();
}

document.getElementById('userModal').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});
</script>

<?php include 'includes/footer.php'; ?>
