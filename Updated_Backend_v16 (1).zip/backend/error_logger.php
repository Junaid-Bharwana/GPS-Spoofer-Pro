<?php
/**
 * Comprehensive Error Logger
 * Logs errors, warnings, and info messages to a log file with timestamps.
 */
class ErrorLogger {

    private static $logFile = null;

    /**
     * Get the log file path.
     */
    private static function getLogFile() {
        if (self::$logFile === null) {
            self::$logFile = __DIR__ . '/logs/app.log';
            $logDir = dirname(self::$logFile);
            if (!is_dir($logDir)) {
                @mkdir($logDir, 0755, true);
            }
        }
        return self::$logFile;
    }

    /**
     * Log an error message.
     */
    public static function error($message, $context = []) {
        self::log('ERROR', $message, $context);
    }

    /**
     * Log a warning message.
     */
    public static function warning($message, $context = []) {
        self::log('WARNING', $message, $context);
    }

    /**
     * Log an info message.
     */
    public static function info($message, $context = []) {
        self::log('INFO', $message, $context);
    }

    /**
     * Log an API request.
     */
    public static function logRequest($endpoint, $method, $params = []) {
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
        self::log('REQUEST', "$method $endpoint from $ip", [
            'user_agent' => substr($ua, 0, 200),
            'params' => array_map(function($v) {
                // Mask sensitive values
                return is_string($v) && strlen($v) > 20 ? substr($v, 0, 5) . '***' : $v;
            }, $params)
        ]);
    }

    /**
     * Log an API response.
     */
    public static function logResponse($endpoint, $status, $message = '') {
        self::log('RESPONSE', "$endpoint: $status - $message");
    }

    /**
     * Core log method.
     */
    private static function log($level, $message, $context = []) {
        try {
            $timestamp = date('Y-m-d H:i:s');
            $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'cli';
            $contextStr = !empty($context) ? ' | ' . json_encode($context) : '';
            $line = "[$timestamp] [$level] [$ip] $message$contextStr\n";

            @file_put_contents(self::getLogFile(), $line, FILE_APPEND | LOCK_EX);
        } catch (\Throwable $e) {
            // Silently fail - logging should never crash the app
        }
    }

    /**
     * Log an exception/throwable.
     */
    public static function logException(\Throwable $e) {
        self::error($e->getMessage(), [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => substr($e->getTraceAsString(), 0, 500)
        ]);
    }
}
?>
