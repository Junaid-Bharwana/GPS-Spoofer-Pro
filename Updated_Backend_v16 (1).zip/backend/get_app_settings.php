<?php
error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json');
http_response_code(200);

try {
    require_once 'db_connect.php';

    if (!isset($conn) || $conn->connect_error) {
        echo json_encode(['status' => 'error', 'message' => 'Database connection failed.']);
        exit();
    }

    $contact_support_url = "";
    $settingsRes = @$conn->query("SELECT setting_value FROM app_settings WHERE setting_key = 'contact_support_url'");
    if ($settingsRes && $settingsRes->num_rows > 0) {
        $settingsRow = $settingsRes->fetch_assoc();
        $contact_support_url = $settingsRow['setting_value'];
    }

    $maintenance_enabled = false;
    $maintenance_title = "";
    $maintenance_message = "";

    $res = @$conn->query("SELECT setting_value FROM app_settings WHERE setting_key = 'maintenance_enabled'");
    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $maintenance_enabled = ($row['setting_value'] === '1');
    }

    $res = @$conn->query("SELECT setting_value FROM app_settings WHERE setting_key = 'maintenance_title'");
    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $maintenance_title = $row['setting_value'];
    }

    $res = @$conn->query("SELECT setting_value FROM app_settings WHERE setting_key = 'maintenance_message'");
    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $maintenance_message = $row['setting_value'];
    }

    echo json_encode([
        'status' => 'success',
        'contact_support_url' => $contact_support_url,
        'maintenance_enabled' => $maintenance_enabled,
        'maintenance_title' => $maintenance_title,
        'maintenance_message' => $maintenance_message
    ]);
    $conn->close();

} catch (\Throwable $th) {
    http_response_code(200);
    echo json_encode(['status' => 'error', 'message' => 'Server error.']);
}
?>
