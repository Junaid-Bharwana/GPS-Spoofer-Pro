<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit();
}

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$page_title = 'Subscription Plans';
$active_page = 'plans';
$message = '';

// Handle Add/Edit/Delete Plan
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // CSRF validation
    $submitted_token = $_POST['csrf_token'] ?? '';
    if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $submitted_token)) {
        $message = 'Error: Invalid security token. Please try again.';
    } else {
    $action = $_POST['action'] ?? '';
    $name = $_POST['name'] ?? '';
    $duration_months = $_POST['duration_months'] ?? 0;
    $price = $_POST['price'] ?? 0.00;
    $plan_id = $_POST['plan_id'] ?? null;

    // Handle delete via POST
    if ($action == 'delete') {
        $delete_id = (int)($plan_id ?? 0);
        if ($delete_id > 0) {
            $stmt = $conn->prepare("DELETE FROM plans WHERE id = ?");
            $stmt->bind_param("i", $delete_id);
            if ($stmt->execute()) {
                $message = 'Plan deleted successfully.';
            } else {
                $message = 'Error deleting plan: ' . $conn->error;
            }
            $stmt->close();
        }
    } elseif (empty($name)) {
        $message = 'Error: Plan name is required.';
    } else {
        if ($action == 'add') {
            $stmt = $conn->prepare("INSERT INTO plans (name, duration_months, price) VALUES (?, ?, ?)");
            $stmt->bind_param("sid", $name, $duration_months, $price);
            if ($stmt->execute()) {
                $message = 'Plan added successfully.';
            } else {
                $message = 'Error adding plan: ' . $conn->error;
            }
            $stmt->close();
        } elseif ($action == 'edit') {
            $stmt = $conn->prepare("UPDATE plans SET name = ?, duration_months = ?, price = ? WHERE id = ?");
            $stmt->bind_param("sidi", $name, $duration_months, $price, $plan_id);
            if ($stmt->execute()) {
                $message = 'Plan updated successfully.';
            } else {
                $message = 'Error updating plan: ' . $conn->error;
            }
            $stmt->close();
        }
    }
    } // end CSRF check
}

if (isset($_GET['msg'])) {
    $message = $_GET['msg'];
}

// Fetch all plans
$plans = [];
$sql = "SELECT id, name, duration_months, price FROM plans ORDER BY duration_months ASC";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $plans[] = $row;
    }
}
$conn->close();

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<?php if ($message): ?>
    <div class="card" style="margin-bottom: 2rem; border-color: <?php echo (strpos($message, 'Error') !== false) ? 'var(--error-color)' : 'var(--success-color)'; ?>">
        <p style="color: <?php echo (strpos($message, 'Error') !== false) ? 'var(--error-color)' : 'var(--success-color)'; ?>">
            <i class="fas <?php echo (strpos($message, 'Error') !== false) ? 'fa-exclamation-triangle' : 'fa-check-circle'; ?>"></i> 
            <?php echo $message; ?>
        </p>
    </div>
<?php endif; ?>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Plan Name</th>
                <th>Duration (Months)</th>
                <th>Price</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($plans)): ?>
                <tr><td colspan="5" style="text-align: center;">No plans found.</td></tr>
            <?php else: ?>
                <?php foreach ($plans as $plan): ?>
                    <tr>
                        <td>#<?php echo $plan['id']; ?></td>
                        <td><strong><?php echo htmlspecialchars($plan['name']); ?></strong></td>
                        <td><?php echo $plan['duration_months']; ?> Months</td>
                        <td>$<?php echo number_format($plan['price'], 2); ?></td>
                        <td>
                            <button class="btn btn-primary" style="padding: 5px 10px;" onclick="editPlan(<?php echo $plan['id']; ?>, '<?php echo htmlspecialchars($plan['name'], ENT_QUOTES); ?>', <?php echo $plan['duration_months']; ?>, <?php echo $plan['price']; ?>)">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-danger" style="padding: 5px 10px;" onclick="deletePlan(<?php echo $plan['id']; ?>, '<?php echo htmlspecialchars($plan['name'], ENT_QUOTES); ?>')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<button class="fab" onclick="showAddModal()">
    <i class="fas fa-plus"></i>
</button>

<div id="planModal" style="display:none; position: fixed; z-index: 2000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); backdrop-filter: blur(5px); overflow-y: auto;">
    <div class="card" style="max-width: 500px; margin: 5% auto; padding: 2rem;">
        <h2 id="modalTitle" style="margin-bottom: 1.5rem; color: var(--primary-color)">Add New Plan</h2>
        <form action="admin_plans.php" method="post">
            <input type="hidden" name="action" id="form_action" value="add">
            <input type="hidden" name="plan_id" id="form_plan_id">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
            
            <div class="form-group">
                <label>Plan Name</label>
                <input type="text" name="name" id="form_name" required placeholder="e.g. 1 Month Plan">
            </div>
            
            <div class="form-group">
                <label>Duration (Months)</label>
                <input type="number" name="duration_months" id="form_duration" required min="1">
            </div>
            
            <div class="form-group">
                <label>Price ($)</label>
                <input type="number" name="price" id="form_price" required step="0.01" min="0">
            </div>
            
            <div style="display: flex; gap: 10px; margin-top: 2rem;">
                <button type="submit" class="btn btn-primary" style="flex: 1;">Save Plan</button>
                <button type="button" class="btn" style="background: var(--hover-bg); color: var(--text-color); flex: 1;" onclick="closeModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
    function showAddModal() {
        document.getElementById('modalTitle').innerText = 'Add New Plan';
        document.getElementById('form_action').value = 'add';
        document.getElementById('form_plan_id').value = '';
        document.getElementById('form_name').value = '';
        document.getElementById('form_duration').value = '';
        document.getElementById('form_price').value = '';
        document.getElementById('planModal').style.display = 'block';
    }

    function editPlan(id, name, duration, price) {
        document.getElementById('modalTitle').innerText = 'Edit Plan';
        document.getElementById('form_action').value = 'edit';
        document.getElementById('form_plan_id').value = id;
        document.getElementById('form_name').value = name;
        document.getElementById('form_duration').value = duration;
        document.getElementById('form_price').value = price;
        document.getElementById('planModal').style.display = 'block';
    }

    function closeModal() {
        document.getElementById('planModal').style.display = 'none';
    }

    function deletePlan(id, name) {
        if (confirm('Delete plan "' + name + '"? This cannot be undone.')) {
            document.getElementById('deletePlanId').value = id;
            document.getElementById('deletePlanForm').submit();
        }
    }
</script>

<!-- Delete Plan Form (POST-based) -->
<form id="deletePlanForm" method="POST" style="display:none;">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="plan_id" id="deletePlanId">
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
</form>

<?php include 'includes/footer.php'; ?>
