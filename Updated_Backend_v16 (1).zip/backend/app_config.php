<?php
// App Configuration
// Change these values anytime to update the app behavior

// Contact Support URL - Change this to your Telegram, WhatsApp, or any URL
// Examples:
//   Telegram: https://t.me/yourusername
//   WhatsApp: https://wa.me/1234567890
//   Website:  https://yourwebsite.com/support
$contact_support_url = "https://t.me/yourusername";
?>
