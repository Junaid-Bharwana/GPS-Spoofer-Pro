<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="sidebar-logo">
            <i class="fas fa-terminal"></i> GS-SYS
        </div>
    </div>
    
    <nav class="nav-links">
        <a href="dashboard.php" class="nav-link <?php echo ($active_page == 'dashboard') ? 'active' : ''; ?>">
            <i class="fas fa-chart-line"></i>
            <span>Dashboard</span>
        </a>
        <a href="admin_dashboard.php" class="nav-link <?php echo ($active_page == 'users') ? 'active' : ''; ?>">
            <i class="fas fa-users-cog"></i>
            <span>Users Management</span>
        </a>
        <a href="admin_plans.php" class="nav-link <?php echo ($active_page == 'plans') ? 'active' : ''; ?>">
            <i class="fas fa-tags"></i>
            <span>Plans Management</span>
        </a>
        <a href="admin_updates.php" class="nav-link <?php echo ($active_page == 'updates') ? 'active' : ''; ?>">
            <i class="fas fa-cloud-upload-alt"></i>
            <span>App Updates</span>
        </a>
        <a href="admin_settings.php" class="nav-link <?php echo ($active_page == 'settings') ? 'active' : ''; ?>">
            <i class="fas fa-cogs"></i>
            <span>App Settings</span>
        </a>
        <a href="admin_profile.php" class="nav-link <?php echo ($active_page == 'profile') ? 'active' : ''; ?>">
            <i class="fas fa-user-shield"></i>
            <span>Admin Profile</span>
        </a>
    </nav>
    
    <div class="sidebar-footer">
        <a href="#" onclick="toggleTheme()" class="nav-link">
            <i class="fas fa-adjust"></i>
            <span>Toggle Theme</span>
        </a>
        <a href="admin_logout.php" class="nav-link" style="color: var(--error-color)">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </div>
</aside>

<main class="main-content">
    <header class="top-bar">
        <div class="menu-toggle" onclick="toggleSidebar()">
            <i class="fas fa-bars fa-lg"></i>
        </div>
        <div class="page-title">
            <h1><?php echo $page_title ?? 'Dashboard'; ?></h1>
        </div>
        <div class="top-actions">
            <!-- Redacted welcome message -->
        </div>
    </header>
