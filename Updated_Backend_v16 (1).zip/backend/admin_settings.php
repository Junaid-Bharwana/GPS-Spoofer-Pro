<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once 'db_connect.php';
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Auth Guard
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit();
}

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$page_title = 'App Settings';
$active_page = 'settings';
$message = '';
$message_type = 'success';

// Auto-create app_settings table if it doesn't exist
$conn->query("CREATE TABLE IF NOT EXISTS `app_settings` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `setting_key` varchar(100) NOT NULL,
    `setting_value` text DEFAULT NULL,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Handle POST - Save Settings
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // CSRF validation
    $submitted_token = $_POST['csrf_token'] ?? '';
    if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $submitted_token)) {
        $message = 'Security error: Invalid CSRF token. Please try again.';
        $message_type = 'error';
    } else {
    $action = isset($_POST['action']) ? $_POST['action'] : 'save_support';
    
    if ($action == 'save_support') {
        $contact_support_url = isset($_POST['contact_support_url']) ? trim($_POST['contact_support_url']) : '';
        $stmt = $conn->prepare("INSERT INTO app_settings (setting_key, setting_value) VALUES ('contact_support_url', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        if ($stmt) {
            $stmt->bind_param("ss", $contact_support_url, $contact_support_url);
            if ($stmt->execute()) {
                $message = "Contact support settings saved successfully.";
                $message_type = 'success';
            } else {
                $message = "Error saving settings: " . $conn->error;
                $message_type = 'error';
            }
            $stmt->close();
        }
    } elseif ($action == 'save_maintenance') {
        $maintenance_enabled = isset($_POST['maintenance_enabled']) ? '1' : '0';
        $maintenance_title = isset($_POST['maintenance_title']) ? trim($_POST['maintenance_title']) : '';
        $maintenance_message = isset($_POST['maintenance_message']) ? trim($_POST['maintenance_message']) : '';
        
        $stmt = $conn->prepare("INSERT INTO app_settings (setting_key, setting_value) VALUES ('maintenance_enabled', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        if ($stmt) { $stmt->bind_param("ss", $maintenance_enabled, $maintenance_enabled); $stmt->execute(); $stmt->close(); }
        
        $stmt = $conn->prepare("INSERT INTO app_settings (setting_key, setting_value) VALUES ('maintenance_title', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        if ($stmt) { $stmt->bind_param("ss", $maintenance_title, $maintenance_title); $stmt->execute(); $stmt->close(); }
        
        $stmt = $conn->prepare("INSERT INTO app_settings (setting_key, setting_value) VALUES ('maintenance_message', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        if ($stmt) { $stmt->bind_param("ss", $maintenance_message, $maintenance_message); $stmt->execute(); $stmt->close(); }
        
        $message = $maintenance_enabled == '1' ? "Maintenance mode ACTIVATED. Users will see the maintenance screen." : "Maintenance mode DEACTIVATED. App is now accessible.";
        $message_type = 'success';
    }
    } // end CSRF check
}

// Load current settings
$contact_support_url = '';
$support_updated_at = '';
$res = $conn->query("SELECT setting_value, updated_at FROM app_settings WHERE setting_key = 'contact_support_url'");
if ($res && $res->num_rows > 0) { $row = $res->fetch_assoc(); $contact_support_url = $row['setting_value']; $support_updated_at = $row['updated_at']; }

$maintenance_enabled = '0';
$res = $conn->query("SELECT setting_value FROM app_settings WHERE setting_key = 'maintenance_enabled'");
if ($res && $res->num_rows > 0) { $row = $res->fetch_assoc(); $maintenance_enabled = $row['setting_value']; }

$maintenance_title = '';
$res = $conn->query("SELECT setting_value FROM app_settings WHERE setting_key = 'maintenance_title'");
if ($res && $res->num_rows > 0) { $row = $res->fetch_assoc(); $maintenance_title = $row['setting_value']; }

$maintenance_message = '';
$res = $conn->query("SELECT setting_value FROM app_settings WHERE setting_key = 'maintenance_message'");
if ($res && $res->num_rows > 0) { $row = $res->fetch_assoc(); $maintenance_message = $row['setting_value']; }

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<style>
.settings-card { padding:24px; margin-bottom:20px; }
.settings-card h3 { color:var(--primary-color); font-size:1.1rem; margin-bottom:16px; display:flex; align-items:center; gap:8px; }
.settings-card h3 i { font-size:1rem; }
.setting-group { margin-bottom:20px; }
.setting-group label { display:block; margin-bottom:6px; font-weight:600; color:var(--text-color); font-size:0.9rem; }
.setting-group input[type="text"], .setting-group textarea { width:100%; }
.setting-group textarea { min-height:80px; resize:vertical; padding:10px; font-family:inherit; font-size:0.9rem; border-radius:8px; border:1px solid var(--border-color); background:var(--hover-bg); color:var(--text-color); }
.setting-group .setting-hint { color:var(--text-muted); font-size:0.8rem; margin-top:6px; line-height:1.4; }
.setting-group .setting-hint code { background:var(--hover-bg); padding:2px 6px; border-radius:4px; font-size:0.8rem; }
.setting-examples { margin-top:8px; padding:12px; background:var(--hover-bg); border-radius:8px; }
.setting-examples p { margin:0 0 6px 0; font-size:0.8rem; color:var(--text-muted); font-weight:600; }
.setting-examples ul { margin:0; padding:0 0 0 16px; list-style:disc; }
.setting-examples li { font-size:0.8rem; color:var(--text-muted); margin-bottom:4px; }
.setting-examples li code { background:rgba(0,0,0,0.2); padding:1px 4px; border-radius:3px; }
.save-btn { margin-top:20px; }
.alert-box { padding:12px 16px; margin-bottom:20px; border-radius:8px; font-size:0.9rem; display:flex; align-items:center; gap:8px; }
.alert-success { background:rgba(0,255,157,0.1); border-left:4px solid var(--primary-color); color:var(--text-color); }
.alert-error { background:rgba(255,82,82,0.1); border-left:4px solid var(--error-color); color:var(--text-color); }
.last-updated { color:var(--text-muted); font-size:0.8rem; margin-top:8px; }
.preview-link { margin-top:10px; }
.preview-link a { color:var(--primary-color); text-decoration:none; font-size:0.85rem; display:inline-flex; align-items:center; gap:6px; }
.preview-link a:hover { text-decoration:underline; }
.maintenance-header { display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; }
.maintenance-header h3 { margin-bottom:0; }
.toggle-switch { position:relative; display:inline-block; width:56px; height:30px; }
.toggle-switch input { opacity:0; width:0; height:0; }
.toggle-slider { position:absolute; cursor:pointer; top:0; left:0; right:0; bottom:0; background:var(--hover-bg); border:2px solid var(--border-color); transition:0.3s; border-radius:30px; }
.toggle-slider:before { position:absolute; content:""; height:22px; width:22px; left:2px; bottom:2px; background:var(--text-muted); transition:0.3s; border-radius:50%; }
.toggle-switch input:checked + .toggle-slider { background:rgba(255,82,82,0.2); border-color:#ff5252; }
.toggle-switch input:checked + .toggle-slider:before { transform:translateX(26px); background:#ff5252; }
.status-badge { display:inline-flex; align-items:center; gap:6px; padding:6px 14px; border-radius:20px; font-size:0.8rem; font-weight:700; letter-spacing:0.5px; }
.status-active { background:rgba(255,82,82,0.15); color:#ff5252; }
.status-inactive { background:rgba(0,200,83,0.15); color:#00c853; }
.maintenance-preview { margin-top:16px; padding:20px; background:linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); border-radius:12px; text-align:center; color:#fff; }
.maintenance-preview .preview-icon { font-size:2.5rem; margin-bottom:10px; color:#ffa726; }
.maintenance-preview .preview-title { font-size:1.2rem; font-weight:700; margin-bottom:6px; color:#fff; }
.maintenance-preview .preview-msg { font-size:0.85rem; color:rgba(255,255,255,0.7); line-height:1.5; }
.maintenance-preview .preview-label { font-size:0.7rem; color:rgba(255,255,255,0.4); margin-bottom:12px; text-transform:uppercase; letter-spacing:1px; }
.section-divider { border:none; border-top:1px solid var(--border-color); margin:30px 0; }
</style>

<div class="container">
    <?php if ($message): ?>
        <div class="alert-box alert-<?php echo $message_type; ?>">
            <i class="fas fa-<?php echo $message_type == 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <!-- Maintenance Mode Section -->
    <form method="POST">
        <input type="hidden" name="action" value="save_maintenance">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
        <div class="card settings-card">
            <div class="maintenance-header">
                <h3><i class="fas fa-tools"></i> Maintenance Mode</h3>
                <div style="display:flex; align-items:center; gap:12px;">
                    <span class="status-badge <?php echo $maintenance_enabled == '1' ? 'status-active' : 'status-inactive'; ?>">
                        <i class="fas fa-<?php echo $maintenance_enabled == '1' ? 'exclamation-triangle' : 'check-circle'; ?>"></i>
                        <?php echo $maintenance_enabled == '1' ? 'ACTIVE' : 'INACTIVE'; ?>
                    </span>
                    <label class="toggle-switch">
                        <input type="checkbox" name="maintenance_enabled" value="1" <?php echo $maintenance_enabled == '1' ? 'checked' : ''; ?>>
                        <span class="toggle-slider"></span>
                    </label>
                </div>
            </div>
            
            <div class="setting-hint" style="margin-bottom:20px; margin-top:8px;">
                When enabled, users will see a maintenance screen instead of the login form. They won't be able to log in until you disable it.
            </div>

            <div class="setting-group">
                <label for="maintenance_title">Maintenance Title</label>
                <input type="text" id="maintenance_title" name="maintenance_title" 
                       value="<?php echo htmlspecialchars($maintenance_title); ?>" 
                       placeholder="Under Maintenance">
                <div class="setting-hint">Custom title shown on the maintenance screen. Leave empty for default: "Under Maintenance"</div>
            </div>

            <div class="setting-group">
                <label for="maintenance_message">Custom Message</label>
                <textarea id="maintenance_message" name="maintenance_message" 
                          placeholder="We're currently performing scheduled maintenance to improve your experience. Please check back shortly."><?php echo htmlspecialchars($maintenance_message); ?></textarea>
                <div class="setting-hint">Custom message shown below the title. Leave empty for default message. You can add estimated time, reason, etc.</div>
            </div>

            <!-- Live Preview -->
            <div class="maintenance-preview" id="maintenancePreview">
                <div class="preview-label">Preview</div>
                <div class="preview-icon"><i class="fas fa-cogs"></i></div>
                <div class="preview-title" id="previewTitle"><?php echo !empty($maintenance_title) ? htmlspecialchars($maintenance_title) : 'Under Maintenance'; ?></div>
                <div class="preview-msg" id="previewMsg"><?php echo !empty($maintenance_message) ? nl2br(htmlspecialchars($maintenance_message)) : "We're currently performing scheduled maintenance to improve your experience. Please check back shortly."; ?></div>
            </div>

            <button type="submit" class="btn btn-primary save-btn">
                <i class="fas fa-save"></i> Save Maintenance Settings
            </button>
        </div>
    </form>

    <hr class="section-divider">

    <!-- Contact Support Section -->
    <form method="POST">
        <input type="hidden" name="action" value="save_support">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
        <div class="card settings-card">
            <h3><i class="fas fa-headset"></i> Contact Support Settings</h3>
            
            <div class="setting-group">
                <label for="contact_support_url">Contact Support URL</label>
                <input type="text" id="contact_support_url" name="contact_support_url" 
                       value="<?php echo htmlspecialchars($contact_support_url); ?>" 
                       placeholder="https://t.me/yourusername">
                <div class="setting-hint">
                    This URL is shown to users on the Login and Subscription pages. 
                    When they tap "Contact Support", it opens this link.
                </div>
                
                <div class="setting-examples">
                    <p>Supported URL formats:</p>
                    <ul>
                        <li>Telegram: <code>https://t.me/yourusername</code></li>
                        <li>WhatsApp: <code>https://wa.me/1234567890</code></li>
                        <li>WhatsApp with message: <code>https://wa.me/1234567890?text=Hi</code></li>
                        <li>Website: <code>https://yoursite.com/support</code></li>
                        <li>Email: <code>mailto:support@example.com</code></li>
                    </ul>
                </div>

                <?php if (!empty($contact_support_url)): ?>
                <div class="preview-link">
                    <a href="<?php echo htmlspecialchars($contact_support_url); ?>" target="_blank">
                        <i class="fas fa-external-link-alt"></i> Preview Link
                    </a>
                </div>
                <?php endif; ?>

                <?php if (!empty($support_updated_at)): ?>
                <div class="last-updated">
                    <i class="fas fa-clock"></i> Last updated: <?php echo $support_updated_at; ?>
                </div>
                <?php endif; ?>
            </div>

            <button type="submit" class="btn btn-primary save-btn">
                <i class="fas fa-save"></i> Save Support Settings
            </button>
        </div>
    </form>
</div>

<script>
var titleInput = document.getElementById('maintenance_title');
var msgInput = document.getElementById('maintenance_message');
var previewTitle = document.getElementById('previewTitle');
var previewMsg = document.getElementById('previewMsg');

if (titleInput) {
    titleInput.addEventListener('input', function() {
        previewTitle.textContent = this.value || 'Under Maintenance';
    });
}
if (msgInput) {
    msgInput.addEventListener('input', function() {
        previewMsg.innerHTML = (this.value || "We're currently performing scheduled maintenance to improve your experience. Please check back shortly.").replace(/\n/g, '<br>');
    });
}
</script>

<?php include 'includes/footer.php'; ?>
