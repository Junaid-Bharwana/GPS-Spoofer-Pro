<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit();
}

$page_title = 'Dashboard';
$active_page = 'dashboard';

// Fetch stats
$total_users = 0;
$active_subs = 0;
$inactive_subs = 0;
$expiring_soon = 0;

$result = $conn->query("SELECT COUNT(*) as count FROM users");
if ($result) $total_users = $result->fetch_assoc()['count'];

$result = $conn->query("SELECT COUNT(*) as count FROM users WHERE subscription_status = 'active'");
if ($result) $active_subs = $result->fetch_assoc()['count'];

$result = $conn->query("SELECT COUNT(*) as count FROM users WHERE subscription_status = 'inactive'");
if ($result) $inactive_subs = $result->fetch_assoc()['count'];

// Expiring in next 7 days
$result = $conn->query("SELECT COUNT(*) as count FROM users WHERE subscription_status = 'active' AND expiration_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)");
if ($result) $expiring_soon = $result->fetch_assoc()['count'];

// Recent Activity (last 5 signups)
$recent_users = [];
$result = $conn->query("SELECT username, subscription_status, created_at FROM users ORDER BY created_at DESC LIMIT 5");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $recent_users[] = $row;
    }
}

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<div class="card-grid">
    <div class="card stat-card">
        <div class="label">Total Users</div>
        <div class="value"><?php echo $total_users; ?></div>
        <i class="fas fa-users" style="position: absolute; right: 20px; top: 20px; font-size: 2rem; opacity: 0.1;"></i>
    </div>
    <div class="card stat-card">
        <div class="label">Active Subscriptions</div>
        <div class="value" style="color: var(--success-color)"><?php echo $active_subs; ?></div>
        <i class="fas fa-check-circle" style="position: absolute; right: 20px; top: 20px; font-size: 2rem; opacity: 0.1; color: var(--success-color)"></i>
    </div>
    <div class="card stat-card">
        <div class="label">Inactive</div>
        <div class="value" style="color: var(--error-color)"><?php echo $inactive_subs; ?></div>
        <i class="fas fa-times-circle" style="position: absolute; right: 20px; top: 20px; font-size: 2rem; opacity: 0.1; color: var(--error-color)"></i>
    </div>
    <div class="card stat-card" style="border-color: #ffc107">
        <div class="label">Expiring Soon</div>
        <div class="value" style="color: #ffc107"><?php echo $expiring_soon; ?></div>
        <i class="fas fa-hourglass-half" style="position: absolute; right: 20px; top: 20px; font-size: 2rem; opacity: 0.1; color: #ffc107"></i>
    </div>
</div>

<div class="table-container">
    <div style="padding: 1.5rem; border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center;">
        <h3 style="color: var(--primary-color)">Recent Activity</h3>
        <a href="admin_dashboard.php" class="btn btn-primary" style="padding: 5px 15px; font-size: 0.8rem;">View All</a>
    </div>
    <table>
        <thead>
            <tr>
                <th>Username</th>
                <th>Status</th>
                <th>Joined At</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($recent_users)): ?>
                <tr><td colspan="3" style="text-align: center;">No recent activity</td></tr>
            <?php else: ?>
                <?php foreach ($recent_users as $user): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                        <td>
                            <span class="status-pill status-<?php echo $user['subscription_status']; ?>">
                                <?php echo ucfirst($user['subscription_status']); ?>
                            </span>
                        </td>
                        <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php
include 'includes/footer.php';
?>
