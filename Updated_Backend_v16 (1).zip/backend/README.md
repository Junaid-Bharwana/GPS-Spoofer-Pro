# GPS Spoofer PRO Backend Setup Instructions

This document outlines the steps to set up the PHP and MySQL backend for the GPS Spoofer PRO application. This backend handles user authentication, subscription management, and provides an admin panel for user administration.

## Prerequisites

Before you begin, ensure you have the following installed on your server or local development environment:

*   **Web Server**: Apache or Nginx
*   **PHP**: Version 7.4 or higher (with `mysqli` extension enabled)
*   **MySQL/MariaDB**: Database server
*   **phpMyAdmin** (Optional, but recommended for easy database management)

## Setup Steps

### 1. Database Setup

1.  **Access MySQL**: Log in to your MySQL server using a tool like phpMyAdmin or the MySQL command-line client.

    ```bash
    mysql -u root -p
    ```

2.  **Create Database and Tables**: Execute the SQL script provided in `database.sql` to create the database and necessary tables.

    ```bash
    SOURCE /path/to/gps_spoofer_backend/database.sql;
    ```

    Alternatively, if using phpMyAdmin:
    *   Create a new database named `gps_spoofer_db`.
    *   Select the `gps_spoofer_db` database.
    *   Go to the 
`SQL` tab and paste the content of `database.sql`, then execute.

    **Note**: The `database.sql` script includes a default admin user: `username: admin`, `password: adminpass`. **Change this immediately after setup for security reasons.**

3.  **Create MySQL User (Recommended)**: Create a dedicated MySQL user for the application with privileges only on the `gps_spoofer_db` database. Replace `your_username` and `your_password`.

    ```sql
    CREATE USER 'your_username'@'localhost' IDENTIFIED BY 'your_password';
    GRANT ALL PRIVILEGES ON gps_spoofer_db.* TO 'your_username'@'localhost';
    FLUSH PRIVILEGES;
    ```

### 2. Backend Files Deployment

1.  **Copy Files**: Upload all the PHP files (`db_connect.php`, `login.php`, `admin_login.php`, `admin_dashboard.php`, `admin_logout.php`) and `database.sql` to your web server's document root (e.g., `/var/www/html/gps_spoofer_backend/` or a subdirectory within it).

2.  **Configure `db_connect.php`**: Open `db_connect.php` and update the following lines with your database credentials:

    ```php
    $servername = "localhost";
    $username = "your_username"; // Your MySQL username
    $password = "your_password"; // Your MySQL password
    $dbname = "gps_spoofer_db";
    ```

### 3. Accessing the Admin Panel

1.  **Navigate to Admin Login**: Open your web browser and go to `http://your_server_ip_or_domain/gps_spoofer_backend/admin_login.php`.
2.  **Login**: Use the default admin credentials (`admin` / `adminpass`) to log in. **Remember to change this password immediately!**
3.  **Manage Users**: From the admin dashboard, you can add new users, edit their details (username, email, subscription status, expiration date), and delete users.

### 4. API Endpoints for Mobile App

*   **Login**: `http://your_server_ip_or_domain/gps_spoofer_backend/login.php` (POST request with `username` and `password`)

This completes the backend setup. The next step will be to integrate this into the Android application.
