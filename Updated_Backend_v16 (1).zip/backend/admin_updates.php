<?php
session_start();
error_reporting(0);
ini_set('display_errors', 0);

require_once 'db_connect.php';
if (!$conn) {
    die("Database connection failed");
}

// Auth Guard
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit();
}

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$page_title = 'App Updates';
$active_page = 'updates';
$message = '';
$message_type = 'success';

// Auto-create table
@$conn->query("CREATE TABLE IF NOT EXISTS `app_updates` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `version_code` int(11) NOT NULL,
    `version_name` varchar(20) NOT NULL,
    `changelog` text,
    `apk_filename` varchar(255) NOT NULL DEFAULT '',
    `file_size` bigint(20) DEFAULT 0,
    `force_update` tinyint(1) DEFAULT 0,
    `is_active` tinyint(1) DEFAULT 1,
    `download_count` int(11) DEFAULT 0,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Ensure uploads directory exists
$upload_dir = __DIR__ . '/uploads/apk/';
if (!is_dir($upload_dir)) {
    @mkdir($upload_dir, 0755, true);
}

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $submitted_token = isset($_POST['csrf_token']) ? $_POST['csrf_token'] : '';
    if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $submitted_token)) {
        $message = 'Security error: Invalid CSRF token.';
        $message_type = 'error';
    } else {
        $action = isset($_POST['action']) ? $_POST['action'] : '';

        if ($action == 'upload_update') {
            $version_name = isset($_POST['version_name']) ? trim($_POST['version_name']) : '';
            $version_code = isset($_POST['version_code']) ? (int)$_POST['version_code'] : 0;
            $changelog = isset($_POST['changelog']) ? trim($_POST['changelog']) : '';
            $force_update = isset($_POST['force_update']) ? 1 : 0;

            if (empty($version_name) || $version_code <= 0) {
                $message = 'Version name and valid version code are required.';
                $message_type = 'error';
            } elseif (!isset($_FILES['apk_file']) || $_FILES['apk_file']['error'] !== UPLOAD_ERR_OK) {
                $message = 'Please select a valid APK file to upload.';
                $message_type = 'error';
            } else {
                $file = $_FILES['apk_file'];
                $file_size = $file['size'];
                $max_size = 100 * 1024 * 1024; // 100MB

                if ($file_size > $max_size) {
                    $message = 'APK file too large. Maximum size is 100MB.';
                    $message_type = 'error';
                } else {
                    // Generate safe filename
                    $safe_name = 'GPS_Spoofer_PRO_v' . preg_replace('/[^0-9.]/', '', $version_name) . '_' . time() . '.apk';
                    $dest = $upload_dir . $safe_name;

                    if (move_uploaded_file($file['tmp_name'], $dest)) {
                        // Deactivate all previous versions
                        $conn->query("UPDATE app_updates SET is_active = 0");

                        // Insert new version (using direct query for broad hosting compatibility)
                        $vc = (int)$version_code;
                        $vn = $conn->real_escape_string($version_name);
                        $cl = $conn->real_escape_string($changelog);
                        $fn = $conn->real_escape_string($safe_name);
                        $fs = (int)$file_size;
                        $fu = (int)$force_update;
                        $insert_sql = "INSERT INTO app_updates (version_code, version_name, changelog, apk_filename, file_size, force_update, is_active) VALUES ($vc, '$vn', '$cl', '$fn', $fs, $fu, 1)";
                        if ($conn->query($insert_sql)) {
                            $message = "Version $version_name (code $version_code) uploaded successfully!";
                            $message_type = 'success';
                        } else {
                            $message = 'Database error: ' . $conn->error;
                            $message_type = 'error';
                        }
                    } else {
                        $message = 'Failed to upload file. Check server permissions on uploads/apk/ directory.';
                        $message_type = 'error';
                    }
                }
            }
        } elseif ($action == 'toggle_active') {
            $update_id = isset($_POST['update_id']) ? (int)$_POST['update_id'] : 0;
            if ($update_id > 0) {
                // Deactivate all, then activate selected
                $conn->query("UPDATE app_updates SET is_active = 0");
                $conn->query("UPDATE app_updates SET is_active = 1 WHERE id = $update_id");
                $message = 'Active version updated.';
            }
        } elseif ($action == 'toggle_force') {
            $update_id = isset($_POST['update_id']) ? (int)$_POST['update_id'] : 0;
            $force_val = isset($_POST['force_val']) ? (int)$_POST['force_val'] : 0;
            if ($update_id > 0) {
                $conn->query("UPDATE app_updates SET force_update = $force_val WHERE id = $update_id");
                $message = $force_val ? 'Force update ENABLED.' : 'Force update disabled.';
            }
        } elseif ($action == 'delete_update') {
            $update_id = isset($_POST['update_id']) ? (int)$_POST['update_id'] : 0;
            if ($update_id > 0) {
                // Get filename to delete file
                $res = $conn->query("SELECT apk_filename FROM app_updates WHERE id = $update_id");
                if ($res && $res->num_rows > 0) {
                    $row = $res->fetch_assoc();
                    $filepath = $upload_dir . $row['apk_filename'];
                    if (file_exists($filepath)) {
                        @unlink($filepath);
                    }
                }
                $conn->query("DELETE FROM app_updates WHERE id = $update_id");
                $message = 'Version deleted.';
            }
        }
    }
}

// Fetch all updates
$updates = [];
$res = $conn->query("SELECT * FROM app_updates ORDER BY version_code DESC");
if ($res) {
    while ($row = $res->fetch_assoc()) $updates[] = $row;
}

// Get current active version
$active_update = null;
foreach ($updates as $u) {
    if ($u['is_active']) { $active_update = $u; break; }
}

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<style>
.upload-card { padding:24px; margin-bottom:20px; }
.upload-card h3 { color:var(--primary-color); font-size:1.1rem; margin-bottom:16px; display:flex; align-items:center; gap:8px; }
.form-row { display:flex; gap:16px; margin-bottom:16px; flex-wrap:wrap; }
.form-group { flex:1; min-width:200px; }
.form-group label { display:block; margin-bottom:6px; font-weight:600; color:var(--text-color); font-size:0.85rem; }
.form-group input, .form-group textarea, .form-group select { width:100%; padding:10px; border-radius:8px; border:1px solid var(--border-color); background:var(--hover-bg); color:var(--text-color); font-size:0.9rem; }
.form-group textarea { min-height:100px; resize:vertical; font-family:inherit; }
.form-group input[type="file"] { padding:8px; }
.form-hint { color:var(--text-muted); font-size:0.75rem; margin-top:4px; }
.active-version-card { padding:20px; margin-bottom:20px; border-left:4px solid var(--success-color); }
.active-version-card h3 { color:var(--success-color); margin-bottom:10px; font-size:1rem; }
.active-version-info { display:flex; gap:20px; flex-wrap:wrap; align-items:center; }
.active-version-info .ver-name { font-size:1.5rem; font-weight:700; color:var(--text-color); }
.active-version-info .ver-detail { color:var(--text-muted); font-size:0.85rem; }
.force-badge { display:inline-block; padding:3px 10px; border-radius:12px; font-size:0.7rem; font-weight:700; }
.force-on { background:rgba(255,82,82,0.15); color:#ff5252; }
.force-off { background:rgba(0,200,83,0.15); color:#00c853; }
.active-badge { background:rgba(0,255,157,0.15); color:var(--primary-color); padding:3px 10px; border-radius:12px; font-size:0.7rem; font-weight:700; }
.alert-box { padding:12px 16px; margin-bottom:20px; border-radius:8px; font-size:0.9rem; display:flex; align-items:center; gap:8px; }
.alert-success { background:rgba(0,255,157,0.1); border-left:4px solid var(--primary-color); color:var(--text-color); }
.alert-error { background:rgba(255,82,82,0.1); border-left:4px solid var(--error-color); color:var(--text-color); }
.update-actions { display:flex; gap:6px; flex-wrap:wrap; }
.update-actions form { display:inline; }
.btn-sm { padding:4px 10px; font-size:0.75rem; border-radius:6px; cursor:pointer; border:1px solid var(--border-color); }
.btn-activate { background:rgba(0,255,157,0.1); color:var(--primary-color); border-color:var(--primary-color); }
.btn-force { background:rgba(255,165,0,0.1); color:#ffa726; border-color:#ffa726; }
.btn-delete { background:rgba(255,82,82,0.1); color:var(--error-color); border-color:var(--error-color); }
.btn-sm:hover { opacity:0.8; }
.dl-count { color:var(--text-muted); font-size:0.8rem; }
</style>

<div class="container">
    <?php if ($message): ?>
        <div class="alert-box alert-<?php echo $message_type; ?>">
            <i class="fas fa-<?php echo $message_type == 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <!-- Current Active Version -->
    <?php if ($active_update): ?>
    <div class="card active-version-card">
        <h3><i class="fas fa-rocket"></i> Current Active Version</h3>
        <div class="active-version-info">
            <span class="ver-name">v<?php echo htmlspecialchars($active_update['version_name']); ?></span>
            <span class="ver-detail">Code: <?php echo $active_update['version_code']; ?></span>
            <span class="ver-detail">Size: <?php echo round($active_update['file_size'] / 1048576, 1); ?> MB</span>
            <span class="ver-detail">Downloads: <?php echo $active_update['download_count']; ?></span>
            <span class="force-badge <?php echo $active_update['force_update'] ? 'force-on' : 'force-off'; ?>">
                <?php echo $active_update['force_update'] ? 'FORCE UPDATE ON' : 'OPTIONAL'; ?>
            </span>
        </div>
    </div>
    <?php else: ?>
    <div class="card active-version-card" style="border-left-color:var(--text-muted);">
        <h3 style="color:var(--text-muted);"><i class="fas fa-info-circle"></i> No Active Version</h3>
        <p style="color:var(--text-muted); font-size:0.85rem;">Upload your first APK below to enable in-app updates.</p>
    </div>
    <?php endif; ?>

    <!-- Upload New Version -->
    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="upload_update">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
        <div class="card upload-card">
            <h3><i class="fas fa-cloud-upload-alt"></i> Upload New Version</h3>
            <div class="form-row">
                <div class="form-group">
                    <label>Version Name</label>
                    <input type="text" name="version_name" placeholder="1.3.0" required>
                    <div class="form-hint">e.g., 1.3.0</div>
                </div>
                <div class="form-group">
                    <label>Version Code</label>
                    <input type="number" name="version_code" placeholder="1300" min="1" required>
                    <div class="form-hint">Must be higher than current (<?php echo $active_update ? $active_update['version_code'] : '0'; ?>)</div>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Changelog / Release Notes</label>
                    <textarea name="changelog" placeholder="- Fixed bugs&#10;- Added new features&#10;- Performance improvements"></textarea>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>APK File</label>
                    <input type="file" name="apk_file" accept=".apk" required>
                    <div class="form-hint">Max 100MB. Upload the signed release APK.</div>
                </div>
                <div class="form-group" style="display:flex; align-items:center; gap:10px; padding-top:24px;">
                    <label style="display:flex; align-items:center; gap:8px; cursor:pointer; margin:0;">
                        <input type="checkbox" name="force_update" value="1">
                        <span style="font-weight:600; color:var(--error-color);">Force Update</span>
                    </label>
                    <div class="form-hint" style="margin:0;">Users must update to continue</div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-upload"></i> Upload & Publish
            </button>
        </div>
    </form>

    <!-- Version History -->
    <div class="table-container">
        <div style="padding:1.5rem; border-bottom:1px solid var(--border-color);">
            <h3 style="color:var(--primary-color);"><i class="fas fa-history"></i> Version History</h3>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Version</th>
                    <th>Code</th>
                    <th>Size</th>
                    <th>Force</th>
                    <th>Downloads</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($updates)): ?>
                    <tr><td colspan="8" style="text-align:center; padding:20px; color:var(--text-muted);">No versions uploaded yet</td></tr>
                <?php else: ?>
                    <?php foreach ($updates as $u): ?>
                    <tr>
                        <td><strong>v<?php echo htmlspecialchars($u['version_name']); ?></strong></td>
                        <td><?php echo $u['version_code']; ?></td>
                        <td><?php echo round($u['file_size'] / 1048576, 1); ?> MB</td>
                        <td>
                            <span class="force-badge <?php echo $u['force_update'] ? 'force-on' : 'force-off'; ?>">
                                <?php echo $u['force_update'] ? 'YES' : 'NO'; ?>
                            </span>
                        </td>
                        <td class="dl-count"><?php echo $u['download_count']; ?></td>
                        <td>
                            <?php if ($u['is_active']): ?>
                                <span class="active-badge">ACTIVE</span>
                            <?php else: ?>
                                <span style="color:var(--text-muted); font-size:0.8rem;">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td style="font-size:0.8rem; color:var(--text-muted);"><?php echo date('M d, Y', strtotime($u['created_at'])); ?></td>
                        <td>
                            <div class="update-actions">
                                <?php if (!$u['is_active']): ?>
                                <form method="POST">
                                    <input type="hidden" name="action" value="toggle_active">
                                    <input type="hidden" name="update_id" value="<?php echo $u['id']; ?>">
                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                    <button type="submit" class="btn-sm btn-activate" title="Set as active">
                                        <i class="fas fa-check"></i> Activate
                                    </button>
                                </form>
                                <?php endif; ?>
                                <form method="POST">
                                    <input type="hidden" name="action" value="toggle_force">
                                    <input type="hidden" name="update_id" value="<?php echo $u['id']; ?>">
                                    <input type="hidden" name="force_val" value="<?php echo $u['force_update'] ? 0 : 1; ?>">
                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                    <button type="submit" class="btn-sm btn-force" title="Toggle force update">
                                        <i class="fas fa-<?php echo $u['force_update'] ? 'unlock' : 'lock'; ?>"></i>
                                        <?php echo $u['force_update'] ? 'Unforce' : 'Force'; ?>
                                    </button>
                                </form>
                                <form method="POST" onsubmit="return confirm('Delete this version? This cannot be undone.')">
                                    <input type="hidden" name="action" value="delete_update">
                                    <input type="hidden" name="update_id" value="<?php echo $u['id']; ?>">
                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                    <button type="submit" class="btn-sm btn-delete" title="Delete version">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
