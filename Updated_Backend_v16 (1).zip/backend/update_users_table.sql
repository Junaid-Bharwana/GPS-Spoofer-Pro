-- Add plan_id column to users table and set up the foreign key
ALTER TABLE `users` ADD COLUMN `plan_id` INT NULL AFTER `expiration_date`;
ALTER TABLE `users` ADD CONSTRAINT `fk_user_plan` FOREIGN KEY (`plan_id`) REFERENCES `plans`(`id`) ON DELETE SET NULL;
