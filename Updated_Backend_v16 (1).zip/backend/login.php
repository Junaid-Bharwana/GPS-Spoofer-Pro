<?php
error_reporting(0);
header('Content-Type: application/json');

try {
    include 'db_connect.php';
    require_once 'rate_limiter.php';
    require_once 'request_validator.php';
    require_once 'input_validator.php';
    require_once 'error_logger.php';

    ErrorLogger::logRequest('login.php', $_SERVER['REQUEST_METHOD']);

    // Rate limiting: max 5 login attempts per minute per IP
    $limiter = new RateLimiter();
    if (!$limiter->isAllowed('login', 5, 60)) {
        echo json_encode(['status' => 'error', 'message' => 'Too many login attempts. Please wait a minute and try again.']);
        exit();
    }

    if (!isset($conn) || $conn->connect_error) {
        echo json_encode(['status' => 'error', 'message' => 'Database connection failed.']);
        exit();
    }

    // Load contact support URL from database
    $contact_support_url = "";
    $settingsRes = @$conn->query("SELECT setting_value FROM app_settings WHERE setting_key = 'contact_support_url'");
    if ($settingsRes && $settingsRes->num_rows > 0) {
        $settingsRow = $settingsRes->fetch_assoc();
        $contact_support_url = $settingsRow['setting_value'];
    }

    $response = array();
    $response['contact_support_url'] = $contact_support_url;

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        $device_token = $_POST['device_token'] ?? '';

        // Input validation
        $usernameCheck = InputValidator::validateString($username, 50, true);
        $passwordCheck = InputValidator::validateString($password, 255, true);
        $tokenCheck = InputValidator::validateDeviceToken($device_token, false);

        if (!$usernameCheck['valid']) {
            $response['status'] = 'error';
            $response['message'] = 'Invalid username: ' . $usernameCheck['error'];
            ErrorLogger::warning('Login validation failed: username', ['username' => $username]);
        } elseif (!$passwordCheck['valid']) {
            $response['status'] = 'error';
            $response['message'] = 'Invalid password: ' . $passwordCheck['error'];
        } elseif (!$tokenCheck['valid']) {
            $response['status'] = 'error';
            $response['message'] = 'Invalid device token.';
            ErrorLogger::warning('Login validation failed: device_token');
        } else {
            $username = $usernameCheck['value'];
            $device_token = $tokenCheck['value'];
            // Ensure device_token column exists (compatible with older MySQL versions)
            $checkCol = $conn->query("SHOW COLUMNS FROM users LIKE 'device_token'");
            if ($checkCol && $checkCol->num_rows == 0) {
                $conn->query("ALTER TABLE users ADD COLUMN device_token VARCHAR(255) DEFAULT NULL");
            }

            $stmt = $conn->prepare("SELECT id, password, subscription_status, expiration_date FROM users WHERE username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $stmt->bind_result($id, $hashed_password, $subscription_status, $expiration_date);
                $stmt->fetch();

                // Support both bcrypt and legacy SHA1 passwords
                $password_valid = false;
                if (password_verify($password, $hashed_password)) {
                    $password_valid = true;
                } elseif (SHA1($password) === $hashed_password) {
                    $password_valid = true;
                    // Migrate legacy SHA1 hash to bcrypt
                    $bcrypt_hash = password_hash($password, PASSWORD_BCRYPT);
                    $migrateStmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                    if ($migrateStmt) {
                        $migrateStmt->bind_param("si", $bcrypt_hash, $id);
                        $migrateStmt->execute();
                        $migrateStmt->close();
                    }
                }

                if ($password_valid) {
                    $current_date = date('Y-m-d');
                    if ($subscription_status == 'active' && $expiration_date >= $current_date) {
                        // Check if already logged in on another device
                        $existingToken = '';
                        $tokenStmt = $conn->prepare("SELECT device_token FROM users WHERE id = ?");
                        if ($tokenStmt) {
                            $tokenStmt->bind_param("i", $id);
                            $tokenStmt->execute();
                            $tokenStmt->store_result();
                            $tokenStmt->bind_result($existingToken);
                            $tokenStmt->fetch();
                            $tokenStmt->close();
                        }

                        // Device token conflict check:
                        // - If stored token is a hardware-based token (64 char hex = SHA-256), compare strictly
                        // - If stored token looks like old random UUID, allow migration to new hardware token
                        $is_old_uuid = (!empty($existingToken) && strlen($existingToken) == 36 && substr_count($existingToken, '-') == 4);
                        $is_hardware_token = (!empty($device_token) && strlen($device_token) == 64 && ctype_xdigit($device_token));

                        if (!empty($existingToken) && !empty($device_token) && $existingToken !== $device_token) {
                            // Allow migration from old UUID to new hardware-based token
                            if ($is_old_uuid && $is_hardware_token) {
                                // Old UUID token in DB, new hardware token from app — allow and update
                            } else {
                                $response['status'] = 'error';
                                $response['message'] = 'This account is already linked to another device. Please contact admin to reset device access.';
                                $response['error_code'] = 'DEVICE_CONFLICT';
                                $stmt->close();
                                $conn->close();
                                echo json_encode($response);
                                exit();
                            }
                        }

                        // Generate a new device token if app didn't send one
                        if (empty($device_token)) {
                            $device_token = bin2hex(random_bytes(32));
                        }

                        // Save device token to DB
                        $updateStmt = $conn->prepare("UPDATE users SET device_token = ? WHERE id = ?");
                        if ($updateStmt) {
                            $updateStmt->bind_param("si", $device_token, $id);
                            $updateStmt->execute();
                            $updateStmt->close();
                        }

                        $response['status'] = 'success';
                        $response['message'] = 'Login successful.';
                        $response['user_id'] = $id;
                        $response['subscription_status'] = $subscription_status;
                        $response['expiration_date'] = $expiration_date;
                        $response['device_token'] = $device_token;
                    } else {
                        $response['status'] = 'error';
                        $response['message'] = 'Account not active or expired. Please contact support.';
                    }
                } else {
                    $response['status'] = 'error';
                    $response['message'] = 'Invalid credentials.';
                }
            } else {
                $response['status'] = 'error';
                $response['message'] = 'Invalid credentials.';
            }
            $stmt->close();
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Invalid request method.';
    }

    $conn->close();
    echo json_encode($response);
} catch (\Throwable $th) {
    ErrorLogger::logException($th);
    http_response_code(200);
    echo json_encode(['status' => 'error', 'message' => 'Server error. Please try again later.']);
}
?>
