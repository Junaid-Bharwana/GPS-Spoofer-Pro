<?php
error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json');
http_response_code(200);

try {
    require_once 'db_connect.php';
    require_once 'rate_limiter.php';
    require_once 'request_validator.php';
    require_once 'input_validator.php';
    require_once 'error_logger.php';

    // Rate limiting: max 30 heartbeat requests per minute per IP
    $limiter = new RateLimiter();
    if (!$limiter->isAllowed('heartbeat', 30, 60)) {
        echo json_encode(['status' => 'error', 'message' => 'Too many requests. Please slow down.']);
        exit();
    }

    if (!isset($conn) || $conn->connect_error) {
        echo json_encode(['status' => 'error', 'message' => 'Database connection failed.']);
        exit();
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
        exit();
    }

    $rawInput = file_get_contents('php://input');
    $input = json_decode($rawInput, true);
    $userId = '';
    $deviceToken = '';

    if (is_array($input)) {
        $userId = isset($input['user_id']) ? $input['user_id'] : '';
        $deviceToken = isset($input['device_token']) ? $input['device_token'] : '';
    }
    if (empty($userId) && isset($_POST['user_id'])) {
        $userId = $_POST['user_id'];
    }
    if (empty($deviceToken) && isset($_POST['device_token'])) {
        $deviceToken = $_POST['device_token'];
    }

    if (empty($userId)) {
        echo json_encode(['status' => 'error', 'message' => 'User ID is required.']);
        exit();
    }

    // Check if device_token column exists
    $hasDeviceToken = false;
    $colCheck = @$conn->query("SHOW COLUMNS FROM users LIKE 'device_token'");
    if ($colCheck && $colCheck->num_rows > 0) {
        $hasDeviceToken = true;
    }

    if ($hasDeviceToken) {
        $stmt = @$conn->prepare("SELECT subscription_status, expiration_date, device_token FROM users WHERE id = ?");
    } else {
        $stmt = @$conn->prepare("SELECT subscription_status, expiration_date FROM users WHERE id = ?");
    }

    if (!$stmt) {
        echo json_encode(['status' => 'error', 'message' => 'Database query failed.']);
        exit();
    }

    $uid = intval($userId);
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 0) {
        echo json_encode(['status' => 'error', 'message' => 'User not found.', 'error_code' => 'USER_NOT_FOUND']);
        $stmt->close();
        $conn->close();
        exit();
    }

    $subscriptionStatus = '';
    $expirationDate = '';
    $storedDeviceToken = '';

    if ($hasDeviceToken) {
        $stmt->bind_result($subscriptionStatus, $expirationDate, $storedDeviceToken);
    } else {
        $stmt->bind_result($subscriptionStatus, $expirationDate);
    }
    $stmt->fetch();
    $stmt->close();

    if (empty($subscriptionStatus)) {
        $subscriptionStatus = 'inactive';
    }

    // Check device token - if mismatch, another device logged in
    if (!empty($deviceToken) && !empty($storedDeviceToken) && $deviceToken !== $storedDeviceToken) {
        echo json_encode([
            'status' => 'error',
            'message' => 'This account is linked to another device. Please contact admin to reset device access.',
            'error_code' => 'DEVICE_CONFLICT'
        ]);
        $conn->close();
        exit();
    }

    // Check if expired based on date
    $currentDate = date('Y-m-d');
    if ($subscriptionStatus == 'active' && !empty($expirationDate) && $expirationDate < $currentDate) {
        $subscriptionStatus = 'expired';
        $updateStmt = @$conn->prepare("UPDATE users SET subscription_status = 'expired' WHERE id = ?");
        if ($updateStmt) {
            $updateStmt->bind_param("i", $uid);
            $updateStmt->execute();
            $updateStmt->close();
        }
    }

    // Check maintenance mode
    $maintenance_enabled = false;
    $maintenance_title = '';
    $maintenance_message = '';
    $mRes = @$conn->query("SELECT setting_key, setting_value FROM app_settings WHERE setting_key IN ('maintenance_enabled', 'maintenance_title', 'maintenance_message')");
    if ($mRes) {
        while ($mRow = $mRes->fetch_assoc()) {
            if ($mRow['setting_key'] === 'maintenance_enabled') {
                $maintenance_enabled = ($mRow['setting_value'] === '1');
            } else if ($mRow['setting_key'] === 'maintenance_title') {
                $maintenance_title = $mRow['setting_value'];
            } else if ($mRow['setting_key'] === 'maintenance_message') {
                $maintenance_message = $mRow['setting_value'];
            }
        }
    }

    echo json_encode([
        'status' => 'success',
        'subscription_status' => $subscriptionStatus,
        'expiration_date' => $expirationDate,
        'maintenance_enabled' => $maintenance_enabled,
        'maintenance_title' => $maintenance_title,
        'maintenance_message' => $maintenance_message
    ]);
    $conn->close();

} catch (\Throwable $th) {
    ErrorLogger::logException($th);
    http_response_code(200);
    echo json_encode(['status' => 'error', 'message' => 'Server error. Please try again later.']);
}
?>
