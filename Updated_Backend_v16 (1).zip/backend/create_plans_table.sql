CREATE TABLE IF NOT EXISTS `plans` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL,
    `duration_months` INT NOT NULL,
    `price` DECIMAL(10, 2) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT IGNORE INTO `plans` (`name`, `duration_months`, `price`) VALUES 
('1 Month Plan', 1, 10.00),
('3 Months Plan', 3, 25.00),
('6 Months Plan', 6, 45.00),
('1 Year Plan', 12, 80.00);
