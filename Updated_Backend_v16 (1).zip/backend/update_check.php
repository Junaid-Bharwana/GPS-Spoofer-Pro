<?php
/**
 * App Update Check API
 * Called by the app on launch to check if a newer version is available.
 * GET /update_check.php?version_code=1210&platform=android
 */
error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json');

require_once 'db_connect.php';

if (!$conn) {
    echo json_encode(['status' => 'error', 'message' => 'Service unavailable']);
    exit();
}

// Auto-create table
@$conn->query("CREATE TABLE IF NOT EXISTS `app_updates` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `version_code` int(11) NOT NULL,
    `version_name` varchar(20) NOT NULL,
    `changelog` text,
    `apk_filename` varchar(255) NOT NULL DEFAULT '',
    `file_size` bigint(20) DEFAULT 0,
    `force_update` tinyint(1) DEFAULT 0,
    `is_active` tinyint(1) DEFAULT 1,
    `download_count` int(11) DEFAULT 0,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$current_version_code = isset($_GET['version_code']) ? (int)$_GET['version_code'] : 0;

if ($current_version_code <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid version code']);
    exit();
}

// Get the latest active update
$res = $conn->query("SELECT * FROM app_updates WHERE is_active = 1 ORDER BY version_code DESC LIMIT 1");

if (!$res || $res->num_rows == 0) {
    echo json_encode([
        'status' => 'ok',
        'update_available' => false
    ]);
    exit();
}

$update = $res->fetch_assoc();
$latest_version_code = (int)$update['version_code'];

if ($latest_version_code > $current_version_code) {
    // Increment download check count (not actual download)
    $uid = (int)$update['id'];
    @$conn->query("UPDATE app_updates SET download_count = download_count + 1 WHERE id = $uid");

    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'app.hostverra.com';
    $base_url = $protocol . '://' . $host;
    $download_url = $base_url . '/uploads/apk/' . $update['apk_filename'];

    echo json_encode([
        'status' => 'ok',
        'update_available' => true,
        'version_code' => $latest_version_code,
        'version_name' => $update['version_name'],
        'changelog' => $update['changelog'],
        'download_url' => $download_url,
        'file_size' => (int)$update['file_size'],
        'force_update' => (bool)$update['force_update'],
        'published_at' => $update['created_at']
    ]);
} else {
    echo json_encode([
        'status' => 'ok',
        'update_available' => false
    ]);
}
?>
