<?php
error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json');
http_response_code(200);

try {
    require_once 'db_connect.php';
    require_once 'request_validator.php';
    require_once 'input_validator.php';
    require_once 'error_logger.php';

    if (!isset($conn) || $conn->connect_error) {
        echo json_encode(['status' => 'error', 'message' => 'Database connection failed.']);
        exit();
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
        exit();
    }

    $userId = isset($_POST['user_id']) ? $_POST['user_id'] : '';
    $deviceToken = isset($_POST['device_token']) ? $_POST['device_token'] : '';

    if (empty($userId)) {
        echo json_encode(['status' => 'error', 'message' => 'User ID is required.']);
        exit();
    }

    $uid = intval($userId);

    // Device token is NOT cleared on logout - only admin can reset it
    // This ensures the account stays locked to the original device
    echo json_encode(['status' => 'success', 'message' => 'Logged out successfully.']);
    $conn->close();

} catch (\Throwable $th) {
    ErrorLogger::logException($th);
    http_response_code(200);
    echo json_encode(['status' => 'error', 'message' => 'Server error. Please try again later.']);
}
?>
