-- Add device_token column to users table for single-device login enforcement
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `device_token` VARCHAR(255) DEFAULT NULL AFTER `expiration_date`;
