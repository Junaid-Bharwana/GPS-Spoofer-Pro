<?php
/**
 * Simple file-based rate limiter for API endpoints.
 * Limits requests per IP address within a time window.
 */
class RateLimiter {
    private $storage_dir;
    
    public function __construct() {
        $this->storage_dir = sys_get_temp_dir() . '/rate_limits';
        if (!is_dir($this->storage_dir)) {
            @mkdir($this->storage_dir, 0755, true);
        }
    }
    
    /**
     * Check if a request should be rate limited.
     * @param string $endpoint Endpoint identifier (e.g., 'login', 'heartbeat')
     * @param int $max_requests Maximum requests allowed in the window
     * @param int $window_seconds Time window in seconds
     * @return bool True if request is allowed, false if rate limited
     */
    public function isAllowed($endpoint, $max_requests = 10, $window_seconds = 60) {
        $ip = $this->getClientIP();
        $key = md5($ip . '_' . $endpoint);
        $file = $this->storage_dir . '/' . $key . '.json';
        
        $now = time();
        $data = ['requests' => [], 'blocked_until' => 0];
        
        if (file_exists($file)) {
            $content = @file_get_contents($file);
            if ($content) {
                $data = json_decode($content, true) ?: $data;
            }
        }
        
        // Check if currently blocked
        if ($data['blocked_until'] > $now) {
            return false;
        }
        
        // Clean old requests outside the window
        $data['requests'] = array_filter($data['requests'], function($timestamp) use ($now, $window_seconds) {
            return ($now - $timestamp) < $window_seconds;
        });
        $data['requests'] = array_values($data['requests']);
        
        // Check if over limit
        if (count($data['requests']) >= $max_requests) {
            // Block for the remaining window time
            $data['blocked_until'] = $now + $window_seconds;
            @file_put_contents($file, json_encode($data));
            return false;
        }
        
        // Add current request
        $data['requests'][] = $now;
        @file_put_contents($file, json_encode($data));
        
        return true;
    }
    
    /**
     * Get remaining requests before rate limit.
     */
    public function getRemaining($endpoint, $max_requests = 10, $window_seconds = 60) {
        $ip = $this->getClientIP();
        $key = md5($ip . '_' . $endpoint);
        $file = $this->storage_dir . '/' . $key . '.json';
        
        if (!file_exists($file)) return $max_requests;
        
        $content = @file_get_contents($file);
        if (!$content) return $max_requests;
        
        $data = json_decode($content, true);
        if (!$data) return $max_requests;
        
        $now = time();
        $recent = array_filter($data['requests'] ?? [], function($t) use ($now, $window_seconds) {
            return ($now - $t) < $window_seconds;
        });
        
        return max(0, $max_requests - count($recent));
    }
    
    private function getClientIP() {
        // Check common proxy headers
        $headers = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];
                // X-Forwarded-For can contain multiple IPs, take the first
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
    
    /**
     * Clean up old rate limit files (call periodically).
     */
    public function cleanup($max_age_seconds = 3600) {
        if (!is_dir($this->storage_dir)) return;
        $now = time();
        foreach (glob($this->storage_dir . '/*.json') as $file) {
            if (($now - filemtime($file)) > $max_age_seconds) {
                @unlink($file);
            }
        }
    }
}
?>
