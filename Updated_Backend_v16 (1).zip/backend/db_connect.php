<?php
// Disable mysqli exception throwing (PHP 8.1+ defaults to strict mode)
mysqli_report(MYSQLI_REPORT_OFF);

$servername = "localhost";
$username = "hostverr_app";
$password = "hostverr_app";
$dbname = "hostverr_app";

$conn = @new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    header('Content-Type: application/json');
    http_response_code(200);
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed.']);
    exit();
}
?>
