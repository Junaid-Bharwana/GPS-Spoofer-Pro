<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit();
}

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$page_title = 'Admin Profile';
$active_page = 'profile';
$message = '';
$admin_id = $_SESSION['admin_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // CSRF validation
    $submitted_token = $_POST['csrf_token'] ?? '';
    if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $submitted_token)) {
        $message = 'Error: Invalid security token. Please try again.';
    } else {
    $username = $_POST['username'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (empty($username)) {
        $message = 'Error: Username cannot be empty.';
    } else {
        // Update username
        $stmt = $conn->prepare("UPDATE admins SET username = ? WHERE id = ?");
        $stmt->bind_param("si", $username, $admin_id);
        if ($stmt->execute()) {
            $_SESSION['admin_username'] = $username;
            $message = 'Profile updated successfully.';
            
            // Update password if provided
            if (!empty($new_password)) {
                if ($new_password === $confirm_password) {
                    $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
                    $stmt_pass = $conn->prepare("UPDATE admins SET password = ? WHERE id = ?");
                    $stmt_pass->bind_param("si", $hashed_password, $admin_id);
                    if ($stmt_pass->execute()) {
                        $message = 'Profile and password updated successfully.';
                    } else {
                        $message = 'Error updating password: ' . $conn->error;
                    }
                    $stmt_pass->close();
                } else {
                    $message = 'Error: Passwords do not match.';
                }
            }
        } else {
            $message = 'Error updating username: ' . $conn->error;
        }
        $stmt->close();
    }
    } // end CSRF check
}

// Fetch current admin data
$stmt = $conn->prepare("SELECT username FROM admins WHERE id = ?");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$stmt->bind_result($current_username);
$stmt->fetch();
$admin = ['username' => $current_username];
$stmt->close();
$conn->close();

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<div class="card" style="max-width: 600px; margin: 0 auto;">
    <?php if ($message): ?>
        <div style="margin-bottom: 2rem; padding: 1rem; border-radius: 8px; background: <?php echo (strpos($message, 'Error') !== false) ? 'rgba(255, 62, 62, 0.1)' : 'rgba(0, 255, 157, 0.1)'; ?>; color: <?php echo (strpos($message, 'Error') !== false) ? 'var(--error-color)' : 'var(--success-color)'; ?>; border: 1px solid currentColor;">
            <i class="fas <?php echo (strpos($message, 'Error') !== false) ? 'fa-exclamation-triangle' : 'fa-check-circle'; ?>"></i> 
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <h2 style="margin-bottom: 2rem; color: var(--primary-color)">Manage Your Profile</h2>
    
    <form action="admin_profile.php" method="post">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
        <div class="form-group">
            <label><i class="fas fa-user"></i> Admin Username</label>
            <input type="text" name="username" value="<?php echo htmlspecialchars($admin['username']); ?>" required>
        </div>
        
        <hr style="border: 0; border-top: 1px solid var(--border-color); margin: 2rem 0;">
        
        <h3 style="margin-bottom: 1rem; font-size: 1.1rem;">Change Password</h3>
        
        <div class="form-group">
            <label><i class="fas fa-lock"></i> New Password</label>
            <input type="password" name="new_password" placeholder="Leave blank to keep current">
        </div>
        
        <div class="form-group">
            <label><i class="fas fa-shield-alt"></i> Confirm New Password</label>
            <input type="password" name="confirm_password" placeholder="Confirm your new password">
        </div>
        
        <div style="margin-top: 2rem;">
            <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center;">
                <i class="fas fa-save"></i> Update Profile
            </button>
        </div>
    </form>
</div>

<?php
include 'includes/footer.php';
?>
