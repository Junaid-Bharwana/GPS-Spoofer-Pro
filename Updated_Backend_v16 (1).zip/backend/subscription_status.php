<?php
error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json');
http_response_code(200);

try {
    require_once 'db_connect.php';
    require_once 'request_validator.php';
    require_once 'input_validator.php';
    require_once 'error_logger.php';
    
    // Load contact support URL from database
    $contact_support_url = "";
    $settingsRes = @$conn->query("SELECT setting_value FROM app_settings WHERE setting_key = 'contact_support_url'");
    if ($settingsRes && $settingsRes->num_rows > 0) {
        $settingsRow = $settingsRes->fetch_assoc();
        $contact_support_url = $settingsRow['setting_value'];
    }

    if (!isset($conn) || $conn->connect_error) {
        echo json_encode(['status' => 'error', 'message' => 'Database connection failed.']);
        exit();
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
        exit();
    }

    $userId = isset($_POST['user_id']) ? $_POST['user_id'] : '';

    if (empty($userId)) {
        echo json_encode(['status' => 'error', 'message' => 'User ID is required.']);
        exit();
    }

    $stmt = @$conn->prepare("SELECT username, subscription_status, expiration_date FROM users WHERE id = ?");
    if (!$stmt) {
        echo json_encode(['status' => 'error', 'message' => 'Database query failed.']);
        exit();
    }

    $uid = intval($userId);
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 0) {
        echo json_encode(['status' => 'error', 'message' => 'User not found.']);
        $stmt->close();
        $conn->close();
        exit();
    }

    $fetchedUsername = '';
    $subscriptionStatus = '';
    $expirationDate = '';
    $stmt->bind_result($fetchedUsername, $subscriptionStatus, $expirationDate);
    $stmt->fetch();
    $stmt->close();

    if (empty($subscriptionStatus)) {
        $subscriptionStatus = 'inactive';
    }
    $currentDate = date('Y-m-d');

    // Check for expiration
    if ($subscriptionStatus == 'active' && !empty($expirationDate) && $expirationDate < $currentDate) {
        $subscriptionStatus = 'expired';
        $updateStmt = @$conn->prepare("UPDATE users SET subscription_status = 'expired' WHERE id = ?");
        if ($updateStmt) {
            $updateStmt->bind_param("i", $uid);
            $updateStmt->execute();
            $updateStmt->close();
        }
    }

    // Calculate remaining days
    $remainingDays = 0;
    if ($subscriptionStatus == 'active' && !empty($expirationDate)) {
        $exp = new DateTime($expirationDate);
        $now = new DateTime($currentDate);
        if ($exp > $now) {
            $diff = $now->diff($exp);
            $remainingDays = intval($diff->format('%a'));
        }
    }

    echo json_encode([
        'status' => 'success',
        'username' => !empty($fetchedUsername) ? $fetchedUsername : 'Unknown',
        'subscription_status' => $subscriptionStatus,
        'expiration_date' => !empty($expirationDate) ? $expirationDate : 'Never',
        'remaining_days' => intval($remainingDays),
        'contact_support_url' => isset($contact_support_url) ? $contact_support_url : ''
    ]);
    $conn->close();

} catch (\Throwable $th) {
    ErrorLogger::logException($th);
    http_response_code(200);
    echo json_encode(['status' => 'error', 'message' => 'Server error. Please try again later.']);
}
?>
